"""components/tradingview.py — TradingView widget (free OANDA symbols)"""
import streamlit as st
import streamlit.components.v1 as components
from config import TV_SYMBOLS

def render_tradingview_chart(symbol="OANDA:BCOUSD", interval="D", height=520, studies=None):
    if studies is None:
        studies = ["RSI@tv-basicstudies","MACD@tv-basicstudies","BB@tv-basicstudies"]
    studies_json = str(studies).replace("'",'"')
    html = f"""
<div style="width:100%;height:{height}px;">
  <div class="tradingview-widget-container" style="height:100%;width:100%">
    <div id="tv_chart" style="height:calc(100% - 28px);width:100%"></div>
    <div style="font-size:11px;color:#666;margin-top:4px;">
      <a href="https://www.tradingview.com/" target="_blank" style="color:#378ADD;">Chart powered by TradingView</a>
    </div>
  </div>
</div>
<script type="text/javascript" src="https://s3.tradingview.com/tv.js"></script>
<script type="text/javascript">
new TradingView.widget({{
  "autosize": true, "symbol": "{symbol}", "interval": "{interval}",
  "timezone": "Etc/UTC", "theme": "dark", "style": "1", "locale": "en",
  "toolbar_bg": "#161b27", "enable_publishing": false,
  "allow_symbol_change": true, "container_id": "tv_chart",
  "studies": {studies_json}, "show_popup_button": true,
  "backgroundColor": "#161b27", "gridColor": "rgba(45,55,72,0.5)",
  "watchlist": ["OANDA:BCOUSD","OANDA:WTICOUSD","OANDA:NATGASUSD","TVC:DXY","CBOE:VIX","OANDA:XAUUSD"],
}});
</script>"""
    components.html(html, height=height+10, scrolling=False)

def tradingview_symbol_selector():
    c1,c2 = st.columns([2,2])
    with c1:
        name = st.selectbox("Instrument", list(TV_SYMBOLS.keys()), index=0,
                            key="tv_symbol_select", label_visibility="collapsed")
    with c2:
        interval = st.selectbox("Timeframe",
                                options=["1","5","15","30","60","240","D","W"], index=6,
                                key="tv_interval_select", label_visibility="collapsed",
                                format_func=lambda x:{"1":"1m","5":"5m","15":"15m","30":"30m",
                                    "60":"1h","240":"4h","D":"1D","W":"1W"}.get(x,x))
    return TV_SYMBOLS[name], interval

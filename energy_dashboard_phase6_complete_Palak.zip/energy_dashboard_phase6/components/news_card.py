"""
components/news_card.py — Phase 2: FinBERT-powered news cards
Clickable headlines, sentiment badges, impact scores, FinBERT indicator.
"""

import streamlit as st
from datetime import datetime, timezone
from config import COLORS

CAT_COLORS = {
    "supply":       ("#EF9F27", "#633806"),
    "demand":       ("#5DCAA5", "#085041"),
    "macro":        ("#7F77DD", "#3C3489"),
    "geopolitical": ("#E24B4A", "#791F1F"),
}
SENT_COLORS = {
    "positive": ("#1D9E75", "BULLISH"),
    "negative": ("#E24B4A", "BEARISH"),
    "neutral":  ("#888780", "NEUTRAL"),
}


def render_news_feed(news_items: list, scored_items: list = None,
                     max_display: int = 20) -> None:
    items = (scored_items if scored_items else news_items)[:max_display]
    if not items:
        st.caption("No energy news available.")
        return

    # FinBERT status badge
    uses_finbert = any(i.get("finbert", False) for i in items)
    model_badge  = ("🤖 FinBERT" if uses_finbert else "🔤 Keyword")
    model_color  = "#1D9E75" if uses_finbert else "#EF9F27"
    st.markdown(
        f'<div style="text-align:right;font-size:10px;color:{model_color};'
        f'margin-bottom:6px;">Sentiment engine: <strong>{model_badge}</strong></div>',
        unsafe_allow_html=True)

    for item in items:
        headline  = item.get("headline", "")
        url       = item.get("url", "#")
        source    = item.get("source", "")
        category  = item.get("category", "macro")
        pub_ago   = item.get("time_ago", "")
        sentiment = item.get("sentiment", "neutral")
        impact    = item.get("impact", None)
        confidence= item.get("confidence", None)

        cat_bg, _        = CAT_COLORS.get(category, ("#888780", "#2C2C2A"))
        sent_col, sent_lb= SENT_COLORS.get(sentiment, ("#888780", "NEUTRAL"))

        impact_html = ""
        if impact is not None:
            impact_html = (
                f'<span style="font-size:10px;font-weight:600;color:{sent_col};">'
                f'⬥ {impact:.1f}/10</span>')

        conf_html = ""
        if confidence is not None:
            bar_w = int(confidence * 100)
            conf_html = (
                f'<div style="margin-top:4px;">'
                f'<div style="height:2px;background:#2d3748;border-radius:1px;">'
                f'<div style="width:{bar_w}%;height:2px;background:{sent_col};'
                f'border-radius:1px;"></div></div></div>')

        st.markdown(f"""
<div style="background:#1a2035;border:.5px solid #2d3748;
     border-left:3px solid {sent_col};border-radius:8px;
     padding:10px 12px;margin-bottom:6px;">
  <a href="{url}" target="_blank" rel="noopener noreferrer"
     style="font-size:12.5px;font-weight:500;color:#e8e8e8;
            text-decoration:none;line-height:1.4;display:block;margin-bottom:5px;">
    {headline}
  </a>
  <div style="display:flex;align-items:center;gap:6px;flex-wrap:wrap;">
    <span style="font-size:10px;font-weight:500;background:{cat_bg}33;color:{cat_bg};
          padding:1px 7px;border-radius:8px;">{category.upper()}</span>
    <span style="font-size:10px;color:#a0aec0;">{source}</span>
    <span style="font-size:10px;color:#555;">{pub_ago}</span>
    {impact_html}
    <span style="margin-left:auto;font-size:10px;font-weight:600;
          color:{sent_col};background:{sent_col}22;
          padding:1px 7px;border-radius:8px;">{sent_lb}</span>
  </div>
  {conf_html}
</div>""", unsafe_allow_html=True)


def render_sentiment_gauge(gauge: dict) -> None:
    """Render composite sentiment gauge from aggregate_sentiment() output."""
    if not gauge:
        return

    overall    = gauge.get("overall", "NEUTRAL")
    bull_pct   = gauge.get("bull_pct", 33)
    bear_pct   = gauge.get("bear_pct", 33)
    neut_pct   = gauge.get("neut_pct", 34)
    w_score    = gauge.get("weighted_score", 0.0)
    signal     = gauge.get("signal", "–")

    oc = (COLORS["bullish"] if "BULLISH" in overall else
          COLORS["bearish"] if "BEARISH" in overall else COLORS["neutral"])

    st.markdown(f"""
<div style="background:#1a2035;border:.5px solid #2d3748;border-radius:8px;
     padding:10px 14px;margin-bottom:10px;">
  <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:6px;">
    <span style="font-size:11px;color:#a0aec0;">Market sentiment</span>
    <span style="font-size:13px;font-weight:700;color:{oc};">{overall}</span>
  </div>
  <div style="display:flex;height:10px;border-radius:5px;overflow:hidden;gap:1px;margin-bottom:6px;">
    <div style="width:{bull_pct}%;background:#1D9E75;border-radius:4px 0 0 4px;"></div>
    <div style="width:{neut_pct}%;background:#888780;"></div>
    <div style="width:{bear_pct}%;background:#E24B4A;border-radius:0 4px 4px 0;"></div>
  </div>
  <div style="display:flex;justify-content:space-between;margin-bottom:6px;">
    <span style="font-size:10px;color:#1D9E75;">Bull {bull_pct}%</span>
    <span style="font-size:10px;color:#888780;">Neutral {neut_pct}%</span>
    <span style="font-size:10px;color:#E24B4A;">Bear {bear_pct}%</span>
  </div>
  <div style="display:flex;justify-content:space-between;align-items:center;">
    <span style="font-size:10px;color:#666;">Weighted score: <strong style="color:{oc};">{w_score:+.3f}</strong></span>
    <span style="font-size:10px;color:#a0aec0;">{signal}</span>
  </div>
</div>""", unsafe_allow_html=True)


def render_sentiment_breakdown(scored_items: list) -> None:
    """Category-level sentiment breakdown chart."""
    if not scored_items:
        return

    from collections import defaultdict
    import plotly.graph_objects as go

    cat_stats = defaultdict(lambda: {"positive":0,"negative":0,"neutral":0,"count":0})
    for item in scored_items:
        cat  = item.get("category","macro")
        sent = item.get("sentiment","neutral")
        cat_stats[cat][sent] += 1
        cat_stats[cat]["count"] += 1

    cats = list(cat_stats.keys())
    bull = [cat_stats[c]["positive"] for c in cats]
    neut = [cat_stats[c]["neutral"]  for c in cats]
    bear = [cat_stats[c]["negative"] for c in cats]

    fig = go.Figure()
    fig.add_trace(go.Bar(name="Bullish",  x=cats, y=bull,
                         marker_color="#1D9E75", text=bull, textposition="auto"))
    fig.add_trace(go.Bar(name="Neutral",  x=cats, y=neut,
                         marker_color="#888780", text=neut, textposition="auto"))
    fig.add_trace(go.Bar(name="Bearish",  x=cats, y=bear,
                         marker_color="#E24B4A", text=bear, textposition="auto"))

    fig.update_layout(
        barmode="stack",
        paper_bgcolor="rgba(0,0,0,0)", plot_bgcolor="rgba(0,0,0,0)",
        font=dict(color="#e8e8e8",size=11),
        height=220, margin=dict(l=10,r=10,t=10,b=30),
        legend=dict(orientation="h", y=1.1, bgcolor="rgba(0,0,0,0)"),
        xaxis=dict(gridcolor="#2d3748"),
        yaxis=dict(gridcolor="#2d3748"),
    )
    st.plotly_chart(fig, use_container_width=True, config={"displayModeBar":False}, key="news_card_21")

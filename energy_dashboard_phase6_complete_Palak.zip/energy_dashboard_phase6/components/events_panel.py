"""components/events_panel.py — fixed HTML rendering"""
import streamlit as st
from data.calendar import get_upcoming_events, IMPORTANCE_COLORS, get_next_eia_release

def render_events_calendar(compact: bool = False) -> None:
    try:
        df = get_upcoming_events(days_ahead=30)
    except Exception:
        st.caption("Events calendar unavailable.")
        return

    eia = get_next_eia_release()
    st.markdown(f"""<div style="background:#1a2035;border:.5px solid #EF9F27;border-radius:8px;
padding:8px 12px;margin-bottom:10px;display:flex;justify-content:space-between;align-items:center;">
<div><div style="font-size:11px;color:#a0aec0;">Next EIA report</div>
<div style="font-size:12px;font-weight:600;color:#e8e8e8;">{eia['name']}</div></div>
<div style="text-align:right;"><div style="font-size:11px;color:#a0aec0;">In</div>
<div style="font-size:18px;font-weight:700;color:#EF9F27;">{eia['countdown']}</div></div>
</div>""", unsafe_allow_html=True)

    if df is None or df.empty:
        st.caption("Loading calendar..."); return

    limit = 6 if compact else 15
    for _, row in df.head(limit).iterrows():
        try:
            imp   = str(row.get("importance","LOW"))
            color = IMPORTANCE_COLORS.get(imp, "#888780")
            name  = str(row.get("name",""))
            cat   = str(row.get("category",""))
            cd    = str(row.get("countdown","–"))
            vol   = str(row.get("vol_impact","–"))
            act   = str(row.get("actual","–"))
            fore  = str(row.get("forecast","–"))
            act_h  = f'<span style="font-size:10px;color:#1D9E75;margin-left:5px;">✓ {act}</span>' if act and act!="–" else ""
            fore_h = f'<span style="font-size:10px;color:#888780;">Est: {fore}</span>' if fore and fore!="–" else ""
            st.markdown(f"""<div style="background:#1a2035;border:.5px solid #2d3748;
border-left:3px solid {color};border-radius:7px;padding:8px 11px;margin-bottom:5px;">
<div style="display:flex;justify-content:space-between;align-items:flex-start;">
<div style="flex:1;">
<div style="font-size:12px;font-weight:600;color:#e8e8e8;margin-bottom:3px;">
<span style="display:inline-block;width:7px;height:7px;border-radius:50%;background:{color};margin-right:5px;vertical-align:middle;"></span>{name}</div>
<div style="display:flex;gap:5px;flex-wrap:wrap;align-items:center;">
<span style="font-size:10px;background:{color}22;color:{color};padding:1px 6px;border-radius:5px;">{imp}</span>
<span style="font-size:10px;color:#555;">{cat}</span>{fore_h}{act_h}</div></div>
<div style="text-align:right;min-width:55px;">
<div style="font-size:13px;font-weight:600;color:{color};">{cd}</div>
<div style="font-size:10px;color:#444;">{vol}</div></div></div></div>""",
                unsafe_allow_html=True)
        except Exception:
            continue

def render_event_impact_legend() -> None:
    cols = st.columns(4)
    for col,(imp,color,desc) in zip(cols,[
        ("CRITICAL","#E24B4A","OPEC, geo events"),
        ("HIGH","#EF9F27","EIA, Fed decisions"),
        ("MEDIUM","#378ADD","COT, Rig count"),
        ("LOW","#888780","Minor releases"),
    ]):
        with col:
            st.markdown(f"""<div style="text-align:center;padding:4px;">
<span style="display:inline-block;width:9px;height:9px;border-radius:50%;background:{color};"></span>
<span style="font-size:11px;color:{color};font-weight:600;margin-left:3px;">{imp}</span>
<div style="font-size:10px;color:#555;margin-top:2px;">{desc}</div>
</div>""", unsafe_allow_html=True)

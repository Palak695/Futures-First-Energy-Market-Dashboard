"""
components/bias_panel.py — Phase 3: ML ensemble bias panel renderer
Shows XGBoost signal, HMM regime, technicals breakdown, SHAP-style feature bars
"""
import streamlit as st
import plotly.graph_objects as go
from config import COLORS


def _apply(fig, h=200, m=None):
    m = m or dict(l=10, r=10, t=20, b=20)
    fig.update_layout(
        paper_bgcolor="rgba(0,0,0,0)", plot_bgcolor="rgba(0,0,0,0)",
        font=dict(color="#e8e8e8", size=11),
        height=h, margin=m,
        xaxis=dict(gridcolor="#2d3748", linecolor="#2d3748", zeroline=True,
                   zerolinecolor="#555", zerolinewidth=1),
        yaxis=dict(gridcolor="#2d3748", linecolor="#2d3748"),
        hoverlabel=dict(bgcolor="#1e2738", font_color="#e8e8e8"),
    )


def render_bias_panel(bias_data: dict) -> None:
    """Full ML bias panel with ensemble signal + SHAP-style breakdown."""
    if not bias_data:
        st.caption("Loading ML signals...")
        return

    bias       = bias_data.get("bias", "NEUTRAL")
    confidence = bias_data.get("confidence", 50)
    bull_prob  = bias_data.get("bull_prob", 0.5)
    bc         = (COLORS["bullish"] if bias == "BULLISH" else
                  COLORS["bearish"] if bias == "BEARISH" else COLORS["neutral"])

    # ── Main bias card ─────────────────────────────────────────────────────────
    st.markdown(f"""
<div style="background:#1a2035;border:1.5px solid {bc};border-radius:10px;
     padding:14px 18px;margin-bottom:12px;">
  <div style="display:flex;justify-content:space-between;align-items:center;">
    <div>
      <div style="font-size:11px;color:#a0aec0;text-transform:uppercase;
                  letter-spacing:.08em;margin-bottom:2px;">ML Ensemble Bias</div>
      <div style="font-size:26px;font-weight:800;color:{bc};letter-spacing:.02em;">{bias}</div>
    </div>
    <div style="text-align:right;">
      <div style="font-size:11px;color:#a0aec0;">Conviction</div>
      <div style="font-size:24px;font-weight:700;color:{bc};">{confidence}%</div>
      <div style="font-size:11px;color:#666;">Bull prob: {bull_prob:.1%}</div>
    </div>
  </div>
  <div style="margin-top:10px;height:6px;background:#2d3748;border-radius:3px;overflow:hidden;">
    <div style="width:{int(bull_prob*100)}%;height:6px;background:{bc};
                border-radius:3px;transition:width .5s;"></div>
  </div>
</div>""", unsafe_allow_html=True)

    # ── Signal breakdown ───────────────────────────────────────────────────────
    signals = bias_data.get("signals", [])
    if signals:
        st.markdown('<div style="font-size:12px;color:#a0aec0;margin-bottom:6px;">Signal breakdown</div>',
                    unsafe_allow_html=True)
        for sig_name, sig_val, sig_weight in signals:
            sig_pct = int(sig_val * 100)
            sig_col = (COLORS["bullish"] if sig_val > 0.55 else
                       COLORS["bearish"] if sig_val < 0.45 else COLORS["neutral"])
            sig_dir = "↑ BULL" if sig_val > 0.55 else "↓ BEAR" if sig_val < 0.45 else "→ NEUT"
            wt_pct  = int(sig_weight * 100)
            st.markdown(f"""
<div style="display:flex;align-items:center;gap:8px;margin-bottom:5px;">
  <div style="font-size:11px;color:#a0aec0;width:90px;flex-shrink:0;">{sig_name}</div>
  <div style="flex:1;height:6px;background:#2d3748;border-radius:3px;overflow:hidden;">
    <div style="width:{sig_pct}%;height:6px;background:{sig_col};border-radius:3px;"></div>
  </div>
  <div style="font-size:11px;color:{sig_col};font-weight:600;width:55px;text-align:right;">{sig_dir}</div>
  <div style="font-size:10px;color:#444;width:30px;text-align:right;">×{sig_weight:.0%}</div>
</div>""", unsafe_allow_html=True)

    # ── HMM Regime badge ───────────────────────────────────────────────────────
    hmm = bias_data.get("hmm", {})
    regime = hmm.get("regime", "UNKNOWN")
    regime_color = hmm.get("regime_color", COLORS["neutral"])
    state_probs  = hmm.get("state_probs", {})

    if regime != "UNKNOWN":
        prob_str = " · ".join([f"{k}: {v:.0%}" for k,v in state_probs.items()])
        st.markdown(f"""
<div style="background:#1a2035;border:.5px solid {regime_color};border-radius:8px;
     padding:8px 12px;margin-top:8px;">
  <div style="display:flex;justify-content:space-between;align-items:center;">
    <div>
      <div style="font-size:10px;color:#a0aec0;">HMM Market Regime</div>
      <div style="font-size:15px;font-weight:700;color:{regime_color};">{regime}</div>
    </div>
    <div style="font-size:10px;color:#555;text-align:right;">{prob_str}</div>
  </div>
</div>""", unsafe_allow_html=True)

    # ── XGBoost top features ───────────────────────────────────────────────────
    xgb  = bias_data.get("xgb", {})
    top_f = xgb.get("top_features", [])
    if top_f:
        st.markdown('<div style="font-size:12px;color:#a0aec0;margin-top:10px;margin-bottom:4px;">Top predictors (XGBoost)</div>',
                    unsafe_allow_html=True)
        max_imp = max(v for _,v in top_f) if top_f else 1
        for feat_name, importance in top_f[:4]:
            bar_w = int(importance / max_imp * 100)
            clean = feat_name.replace("_"," ").title()
            st.markdown(f"""
<div style="display:flex;align-items:center;gap:8px;margin-bottom:4px;">
  <div style="font-size:11px;color:#a0aec0;width:100px;flex-shrink:0;overflow:hidden;
              white-space:nowrap;text-overflow:ellipsis;">{clean}</div>
  <div style="flex:1;height:5px;background:#2d3748;border-radius:3px;overflow:hidden;">
    <div style="width:{bar_w}%;height:5px;background:#378ADD;border-radius:3px;"></div>
  </div>
  <div style="font-size:10px;color:#378ADD;width:35px;text-align:right;">{importance:.3f}</div>
</div>""", unsafe_allow_html=True)


def render_alerts_panel(alerts: list) -> None:
    """Render live alerts with severity coloring."""
    if not alerts:
        st.markdown("""
<div style="background:#1a2035;border:.5px solid #2d3748;border-radius:8px;
     padding:12px 14px;text-align:center;">
  <div style="font-size:13px;color:#1D9E75;">✓ No anomalies detected</div>
  <div style="font-size:11px;color:#666;margin-top:3px;">Markets within normal ranges</div>
</div>""", unsafe_allow_html=True)
        return

    sev_colors = {"HIGH": "#E24B4A", "MEDIUM": "#EF9F27", "LOW": "#888780"}
    for alert in alerts[:8]:
        sev   = alert.get("severity", "LOW")
        color = sev_colors.get(sev, "#888780")
        atype = alert.get("type", "")
        msg   = alert.get("message", "")
        val   = alert.get("value", "")
        time  = alert.get("time", "")
        asset = alert.get("asset", "")

        st.markdown(f"""
<div style="background:#1a2035;border:.5px solid #2d3748;border-left:3px solid {color};
     border-radius:7px;padding:8px 12px;margin-bottom:5px;">
  <div style="display:flex;justify-content:space-between;align-items:flex-start;">
    <div style="flex:1;">
      <div style="font-size:12px;font-weight:600;color:#e8e8e8;margin-bottom:2px;">{asset} — {atype}</div>
      <div style="font-size:11px;color:#a0aec0;line-height:1.4;">{msg}</div>
    </div>
    <div style="text-align:right;min-width:60px;">
      <div style="font-size:13px;font-weight:700;color:{color};">{val}</div>
      <div style="font-size:10px;color:#444;">{time}</div>
    </div>
  </div>
</div>""", unsafe_allow_html=True)

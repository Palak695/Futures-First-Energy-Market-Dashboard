"""
data/tankers.py — Phase 4: Tanker map with MarineTraffic API + DBSCAN clustering
Free tier: 500 credits/day. Falls back to static key route display if API unavailable.
"""
import requests
import pandas as pd
import numpy as np
import streamlit as st
from config import get_secret

# Key tanker routes for display even without API
KEY_ROUTES = {
    "TD3C": {"name":"Middle East → China","from_lat":26.0,"from_lon":56.0,"to_lat":22.0,"to_lon":113.0,"color":"#378ADD"},
    "TD20": {"name":"West Africa → Europe","from_lat":5.0,"from_lon":2.0,"to_lat":51.0,"to_lon":3.0,"color":"#EF9F27"},
    "TD25": {"name":"US Gulf → Europe","from_lat":28.0,"from_lon":-90.0,"to_lat":51.0,"to_lon":3.0,"color":"#1D9E75"},
    "TD7":  {"name":"North Sea → Continent","from_lat":60.0,"from_lon":2.0,"to_lat":51.5,"to_lon":4.0,"color":"#7F77DD"},
}

# Key maritime chokepoints
CHOKEPOINTS = [
    {"name":"Strait of Hormuz","lat":26.6,"lon":56.5,"risk":"HIGH"},
    {"name":"Suez Canal","lat":30.7,"lon":32.3,"risk":"ELEVATED"},
    {"name":"Strait of Malacca","lat":1.3,"lon":103.8,"risk":"MEDIUM"},
    {"name":"Bab el-Mandeb","lat":12.6,"lon":43.3,"risk":"HIGH"},
    {"name":"Turkish Straits","lat":41.1,"lon":29.0,"risk":"MEDIUM"},
    {"name":"Cape of Good Hope","lat":-34.4,"lon":18.5,"risk":"LOW"},
]


@st.cache_data(ttl=7200, show_spinner=False)
def fetch_tanker_positions() -> pd.DataFrame:
    """
    Fetch live tanker positions from MarineTraffic API.
    Returns DataFrame with vessel info. Falls back to empty if no API key.
    """
    api_key = get_secret("MARINE_TRAFFIC_KEY")
    if not api_key:
        return pd.DataFrame()

    try:
        url = "https://services.marinetraffic.com/api/exportVessels/v:8"
        params = {
            "v":       8,
            "apikey":  api_key,
            "typecode":"80,81,82,83,84",  # tanker types
            "protocol":"jsono",
            "msgtype": "simple",
        }
        resp = requests.get(url, params=params, timeout=15)
        if resp.status_code != 200:
            return pd.DataFrame()
        data = resp.json()
        vessels = []
        for v in data:
            try:
                vessels.append({
                    "mmsi":        v.get("MMSI",""),
                    "name":        v.get("SHIPNAME","Unknown"),
                    "lat":         float(v.get("LAT",0)),
                    "lon":         float(v.get("LON",0)),
                    "speed":       float(v.get("SPEED",0)),
                    "course":      float(v.get("COURSE",0)),
                    "destination": v.get("DESTINATION",""),
                    "vessel_type": _classify_vessel(v.get("SHIPTYPE","80")),
                    "dwt":         float(v.get("DRAUGHT",0)),
                })
            except Exception:
                continue
        return pd.DataFrame(vessels) if vessels else pd.DataFrame()
    except Exception:
        return pd.DataFrame()


def _classify_vessel(ship_type) -> str:
    t = int(str(ship_type)[:2]) if str(ship_type).isdigit() else 80
    if t in [81, 82]:   return "VLCC"
    if t in [83, 84]:   return "Suezmax"
    return "Aframax"


def dbscan_route_clusters(df: pd.DataFrame) -> pd.DataFrame:
    """Apply DBSCAN to identify shipping lane clusters."""
    if df.empty or len(df) < 5:
        return df
    try:
        from sklearn.cluster import DBSCAN
        coords = df[["lat","lon"]].values
        model  = DBSCAN(eps=3.0, min_samples=3, metric="euclidean")
        labels = model.fit_predict(coords)
        df     = df.copy()
        df["cluster"]  = labels
        df["anomalous"]= labels == -1  # off-lane vessels
        return df
    except Exception:
        df["cluster"]   = 0
        df["anomalous"] = False
        return df


def get_chokepoint_risk_summary() -> list:
    """Return chokepoints with current risk levels."""
    return CHOKEPOINTS


def get_route_display_data() -> dict:
    """Return key routes for map display."""
    return KEY_ROUTES

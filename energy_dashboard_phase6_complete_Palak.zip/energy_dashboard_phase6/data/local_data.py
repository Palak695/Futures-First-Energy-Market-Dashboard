"""data/local_data.py — all parquet loaders including curve parquets"""
import pandas as pd
import streamlit as st
import os
from config import PARQUET_PATHS


def _load(path: str, ts_col: str = "date") -> pd.DataFrame:
    if not os.path.exists(path):
        return pd.DataFrame()
    try:
        df = pd.read_parquet(path)
        for col in [ts_col, "date", "Date", "timestamp", "Timestamp"]:
            if col in df.columns:
                df = df.rename(columns={col: ts_col})
                df[ts_col] = pd.to_datetime(df[ts_col], errors="coerce")
                try:
                    if df[ts_col].dt.tz is not None:
                        df[ts_col] = df[ts_col].dt.tz_convert(None)
                except Exception:
                    pass
                break
        return df
    except Exception:
        return pd.DataFrame()


@st.cache_resource(show_spinner=False)
def load_lco_settle() -> pd.DataFrame:
    return _load(PARQUET_PATHS["lco_settle"], "date")

@st.cache_resource(show_spinner=False)
def load_wtcl_spread() -> pd.DataFrame:
    return _load(PARQUET_PATHS["wtcl_spread"], "date")

@st.cache_resource(show_spinner=False)
def load_lco_daily() -> pd.DataFrame:
    return _load("data_files/lco_daily.parquet", "timestamp")

@st.cache_resource(show_spinner=False)
def load_cl_daily() -> pd.DataFrame:
    for p in ["data_files/cl_merged_daily.parquet", "data_files/cl_daily.parquet"]:
        if os.path.exists(p):
            return _load(p, "timestamp")
    return pd.DataFrame()

@st.cache_resource(show_spinner=False)
def load_ho_monthly() -> pd.DataFrame:
    return _load("data_files/ho_monthly.parquet", "timestamp")

@st.cache_resource(show_spinner=False)
def load_lgo_monthly() -> pd.DataFrame:
    return _load("data_files/lgo_monthly.parquet", "timestamp")

# ── Curve parquets (new — from updated converter) ──────────────────────────────
@st.cache_resource(show_spinner=False)
def load_cl_curve() -> pd.DataFrame:
    """WTI term structure: CLc1..CLc10 daily closing prices."""
    for p in ["data_files/cl_curve_daily.parquet",
              "data_files/cl_out_curve_daily.parquet"]:
        if os.path.exists(p):
            return _load(p, "timestamp")
    return pd.DataFrame()

@st.cache_resource(show_spinner=False)
def load_ho_curve() -> pd.DataFrame:
    """Heating Oil term structure: HOc1..HOc10 daily closing prices."""
    return _load("data_files/ho_curve_daily.parquet", "timestamp")

@st.cache_resource(show_spinner=False)
def load_lgo_curve() -> pd.DataFrame:
    """ICE Gasoil term structure: LGOc1..LGOc10 daily closing prices."""
    return _load("data_files/lgo_curve_daily.parquet", "timestamp")

@st.cache_resource(show_spinner=False)
def load_lco_curve() -> pd.DataFrame:
    """Brent 1-min derived term structure (supplementary to LCOSettle)."""
    return _load("data_files/lco_curve_daily.parquet", "timestamp")


def dataset_status() -> dict:
    files = {
        "lco_settle":   PARQUET_PATHS["lco_settle"],
        "wtcl_spread":  PARQUET_PATHS["wtcl_spread"],
        "cl_daily":     "data_files/cl_daily.parquet",
        "ho_monthly":   "data_files/ho_monthly.parquet",
        "lgo_monthly":  "data_files/lgo_monthly.parquet",
        "cl_curve":     "data_files/cl_curve_daily.parquet",
        "ho_curve":     "data_files/ho_curve_daily.parquet",
        "lgo_curve":    "data_files/lgo_curve_daily.parquet",
    }
    return {name: os.path.exists(path) for name, path in files.items()}

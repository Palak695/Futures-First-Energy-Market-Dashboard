"""
data/eia.py — Phase 5 fixed
EIA API → fredapi library (uses different HTTP transport) → FRED REST → empty.
fredapi library bypasses the IP blocklist that FRED direct CSV hits.
"""
import requests
import pandas as pd
import numpy as np
import streamlit as st
from datetime import datetime, timedelta
from config import EIA_BASE_URL, EIA_SERIES, get_secret

SEASONALITY_SERIES = {
    "Gasoil / Distillates": "PET.WDIRPUS2.W",
    "Heating Oil":           "PET.WDISFPUS2.W",
    "RBOB Gasoline":         "PET.WGTUPUS2.W",
}

# FRED mirror codes for EIA data
FRED_CODES = {
    "crude_inventory":      "WCRSTUS1",
    "gasoline_inventory":   "WGTSTUS1",
    "distillate_inventory": "WDISTUS1",
    "spr":                  "WCSSTUS1",
    "go_supplied":          "WDIRPUS2",
    "rbob_supplied":        "WRBUPUS2",
    "crude_production":     "WCRFPUS2",
    "refinery_util":        "WPULEUS3",
}

INVENTORY_PRODUCTS = {
    "Crude Oil":   ("crude_inventory",   "WCRSTUS1"),
    "Gasoline":    ("gasoline_inventory","WGTSTUS1"),
    "Distillates": ("distillate_inventory","WDISTUS1"),
    "SPR":         ("spr",               "WCSSTUS1"),
}


@st.cache_resource(show_spinner=False)
def _get_fred_client():
    """Get fredapi Fred instance — cached for session."""
    key = get_secret("FRED_KEY")
    if not key:
        return None
    try:
        from fredapi import Fred
        return Fred(api_key=key)
    except Exception:
        return None


def _fetch_fred_series(fred_code: str, limit: int = 260) -> pd.DataFrame:
    """Fetch via fredapi library first, then FRED REST as backup."""
    fred = _get_fred_client()
    if fred is not None:
        try:
            s = fred.get_series(fred_code)
            s = s.dropna().tail(limit)
            if not s.empty:
                # Strip timezone from index
                idx = s.index
                if hasattr(idx, 'tz') and idx.tz is not None:
                    idx = idx.tz_localize(None)
                df = pd.DataFrame({"date": idx, "value": s.values})
                df["date"]  = pd.to_datetime(df["date"], errors="coerce")
                df["value"] = pd.to_numeric(df["value"], errors="coerce")
                return df.dropna().sort_values("date").reset_index(drop=True)
        except Exception:
            pass

    # FRED REST fallback
    fred_key = get_secret("FRED_KEY")
    if fred_key:
        try:
            url = (f"https://api.stlouisfed.org/fred/series/observations"
                   f"?series_id={fred_code}&api_key={fred_key}"
                   f"&file_type=json&sort_order=desc&limit={limit}")
            r = requests.get(url, timeout=15)
            if r.status_code == 200:
                obs = r.json().get("observations", [])
                if obs:
                    df = pd.DataFrame(obs)[["date","value"]]
                    df["date"]  = pd.to_datetime(df["date"], errors="coerce")
                    df["value"] = pd.to_numeric(df["value"], errors="coerce")
                    return df.dropna().sort_values("date").reset_index(drop=True)
        except Exception:
            pass

    return pd.DataFrame(columns=["date","value"])


@st.cache_data(ttl=3600, show_spinner=False)
def fetch_eia_series(series_id: str, length: int = 104) -> pd.DataFrame:
    """EIA API first, then FRED mirror."""
    eia_key = get_secret("EIA_KEY")

    # Try EIA v2
    if eia_key:
        for url, params in [
            (f"{EIA_BASE_URL}/seriesid/{series_id}",
             {"api_key":eia_key,"frequency":"weekly","data[]":"value",
              "sort[0][column]":"period","sort[0][direction]":"desc","length":length}),
        ]:
            try:
                r = requests.get(url, params=params, timeout=12)
                if r.status_code == 200:
                    rows = r.json().get("response",{}).get("data",[])
                    if rows:
                        df = pd.DataFrame(rows).rename(columns={"period":"date"})
                        df["date"]  = pd.to_datetime(df["date"], errors="coerce")
                        df["value"] = pd.to_numeric(df["value"], errors="coerce")
                        df = df[["date","value"]].dropna().sort_values("date").reset_index(drop=True)
                        if not df.empty:
                            return df
            except Exception:
                pass

    # Map EIA series ID to FRED code
    short_id = series_id.replace("PET.","").replace(".W","")
    fred_code = next(
        (v for k,v in FRED_CODES.items() if EIA_SERIES.get(k,"") == series_id),
        short_id
    )
    return _fetch_fred_series(fred_code, limit=length)


@st.cache_data(ttl=3600, show_spinner=False)
def fetch_inventory_data() -> dict:
    result = {}
    for name, (series_key, fred_code) in INVENTORY_PRODUCTS.items():
        # Try EIA series first
        eia_sid = EIA_SERIES.get(series_key,"")
        df = fetch_eia_series(eia_sid, length=260) if eia_sid else pd.DataFrame()

        # Direct FRED fallback
        if df.empty:
            df = _fetch_fred_series(fred_code, limit=260)

        if df.empty:
            result[name] = {"current":None,"prev_week":None,"change":None,
                            "change_pct":None,"yoy":None,"avg_5yr":None,
                            "unit":"Mbbl","date":"N/A","history":pd.DataFrame()}
            continue

        current   = float(df["value"].iloc[-1])
        prev_week = float(df["value"].iloc[-2]) if len(df)>1 else None
        change    = round(current - prev_week,1) if prev_week else None
        chg_pct   = round(change/prev_week*100,2) if prev_week else None
        yoy_val   = float(df["value"].iloc[-53]) if len(df)>52 else None
        yoy_chg   = round(current - yoy_val,1) if yoy_val else None
        avg_5yr   = round(df["value"].tail(260).mean(),1)

        result[name] = {
            "current":    round(current,1),
            "prev_week":  round(prev_week,1) if prev_week else None,
            "change":     change, "change_pct": chg_pct,
            "yoy": yoy_chg, "avg_5yr": avg_5yr,
            "unit": "Mbbl",
            "date": df["date"].iloc[-1].strftime("%b %d, %Y"),
            "history": df.tail(104),
        }
    return result


@st.cache_data(ttl=86400, show_spinner=False)
def fetch_seasonality_product(product_name: str) -> pd.DataFrame:
    sid = SEASONALITY_SERIES.get(product_name)
    if not sid:
        return pd.DataFrame()

    # Try EIA series
    df = fetch_eia_series(sid, length=572)
    if not df.empty:
        df["year"]    = df["date"].dt.year
        df["quarter"] = df["date"].dt.quarter
        df["week"]    = df["date"].dt.isocalendar().week.astype(int)
        df["month"]   = df["date"].dt.month
        return df

    # FRED fallback for seasonality
    short = sid.replace("PET.","").replace(".W","")
    df2 = _fetch_fred_series(short, limit=572)
    if not df2.empty:
        df2["year"]    = df2["date"].dt.year
        df2["quarter"] = df2["date"].dt.quarter
        df2["week"]    = df2["date"].dt.isocalendar().week.astype(int)
        df2["month"]   = df2["date"].dt.month
        return df2

    return _yfinance_seasonality(product_name)


def _yfinance_seasonality(product_name: str) -> pd.DataFrame:
    import yfinance as yf
    ticker_map = {
        "Gasoil / Distillates": "CL=F",
        "Heating Oil":           "HO=F",
        "RBOB Gasoline":         "RB=F",
    }
    try:
        ticker = ticker_map.get(product_name, "CL=F")
        df = yf.Ticker(ticker).history(period="10y", auto_adjust=True)
        if df.empty: return pd.DataFrame()
        idx = df.index.tz_convert(None) if df.index.tz else df.index
        result = pd.DataFrame({"date": idx, "value": df["Close"].values})
        result["date"]    = pd.to_datetime(result["date"], errors="coerce")
        result["value"]   = pd.to_numeric(result["value"], errors="coerce")
        result = result.dropna()
        result["year"]    = result["date"].dt.year
        result["quarter"] = result["date"].dt.quarter
        result["week"]    = result["date"].dt.isocalendar().week.astype(int)
        result["month"]   = result["date"].dt.month
        return result.reset_index(drop=True)
    except Exception:
        return pd.DataFrame()


@st.cache_data(ttl=86400, show_spinner=False)
def fetch_seasonality_data() -> dict:
    return {name: fetch_seasonality_product(name) for name in SEASONALITY_SERIES}

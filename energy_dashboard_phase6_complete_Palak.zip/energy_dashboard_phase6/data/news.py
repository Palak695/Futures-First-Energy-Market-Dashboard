"""
data/news.py — Phase 6: shorter TTL, better deduplication, more RSS feeds
News TTL reduced to 120s so headlines refresh every 2 minutes.
"""
import feedparser
import requests
import streamlit as st
import hashlib
from datetime import datetime, timezone
from config import get_secret, NEWS_CATEGORIES

# Expanded RSS feeds including more real-time sources
RSS_FEEDS = {
    "EIA":          "https://www.eia.gov/rss/news.xml",
    "OilPrice":     "https://oilprice.com/rss/main",
    "Rigzone":      "https://www.rigzone.com/news/rss/rigzone_latest.aspx",
    "Reuters Biz":  "https://feeds.reuters.com/reuters/businessNews",
    "S&P Global":   "https://www.spglobal.com/commodityinsights/en/rss-feed/oil",
}

ENERGY_KW = [
    "crude","oil","brent","wti","opec","petroleum","gasoline","diesel",
    "refinery","pipeline","lng","natural gas","energy","barrel","rig",
    "shale","offshore","tanker","nymex","inventory","production","iea",
    "saudi","iran","iraq","russia","ceraweek","upstream","downstream",
    "fuel","feedstock","crack","spread","hedge","derivatives",
]


def _is_energy(text: str) -> bool:
    t = text.lower()
    return any(k in t for k in ENERGY_KW)


def _cat(text: str) -> str:
    t = text.lower()
    scores = {c: sum(1 for kw in kws if kw in t)
              for c, kws in NEWS_CATEGORIES.items()}
    best = max(scores, key=scores.get)
    return best if scores[best] > 0 else "macro"


def _dedup(headline: str) -> str:
    return hashlib.md5(headline.lower().strip()[:80].encode()).hexdigest()


def _parse_rss(name: str, url: str) -> list:
    items = []
    try:
        feed = feedparser.parse(url)
        for entry in feed.entries[:25]:
            title = (entry.get("title") or "").strip()
            link  = entry.get("link","")
            if not title or not _is_energy(title):
                continue
            try:
                dt = datetime(*entry.published_parsed[:6], tzinfo=timezone.utc)
            except Exception:
                dt = datetime.now(timezone.utc)
            items.append({
                "headline":  title, "url": link, "source": name,
                "published": dt, "category": _cat(title),
                "dedup_key": _dedup(title),
            })
    except Exception:
        pass
    return items


@st.cache_data(ttl=120, show_spinner=False)   # 2 min cache instead of 5
def fetch_news(max_items: int = 30) -> list:
    all_items = []
    seen      = set()

    # NewsAPI (most current headlines)
    news_key = get_secret("NEWS_API_KEY")
    if news_key:
        try:
            from newsapi import NewsApiClient
            client = NewsApiClient(api_key=news_key)
            resp   = client.get_everything(
                q='crude oil OR brent OR WTI OR OPEC OR petroleum OR "natural gas"',
                language='en', sort_by='publishedAt', page_size=30)
            for art in (resp.get("articles") or []):
                title = (art.get("title") or "").strip()
                if not title or title == "[Removed]":
                    continue
                dk = _dedup(title)
                if dk in seen: continue
                seen.add(dk)
                try:
                    dt = datetime.fromisoformat(
                        art["publishedAt"].replace("Z","+00:00"))
                except Exception:
                    dt = datetime.now(timezone.utc)
                all_items.append({
                    "headline":  title,
                    "url":       art.get("url",""),
                    "source":    art.get("source",{}).get("name","NewsAPI"),
                    "published": dt,
                    "category":  _cat(title),
                    "dedup_key": dk,
                })
        except Exception:
            pass

    # RSS feeds (supplementary, more current for some sources)
    for feed_name, feed_url in RSS_FEEDS.items():
        for item in _parse_rss(feed_name, feed_url):
            if item["dedup_key"] not in seen:
                seen.add(item["dedup_key"])
                all_items.append(item)

    # Sort by recency
    all_items.sort(key=lambda x: x["published"], reverse=True)
    return all_items[:max_items]


def time_ago(dt: datetime) -> str:
    try:
        if dt.tzinfo is None:
            dt = dt.replace(tzinfo=timezone.utc)
        delta = datetime.now(timezone.utc) - dt
        secs  = int(delta.total_seconds())
        if secs < 60:    return f"{secs}s ago"
        if secs < 3600:  return f"{secs//60}m ago"
        if secs < 86400: return f"{secs//3600}h {(secs%3600)//60}m ago"
        return f"{secs//86400}d ago"
    except Exception:
        return "–"

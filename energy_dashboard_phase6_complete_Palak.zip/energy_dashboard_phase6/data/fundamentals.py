"""
data/fundamentals.py
Fundamentals data: Macro (GDP/PMI), Supply (US prod/OPEC/spare cap), Trade (BDI proxy/CPB).
Sources: FRED, World Bank REST API, EIA STEO Excel, CPB CSV, yFinance.
All free-tier, no additional API keys beyond existing FRED_KEY.
"""
import requests
import pandas as pd
import numpy as np
import streamlit as st
import io
from config import get_secret


# ── WORLD BANK ─────────────────────────────────────────────────────────────────
WB_BASE = "https://api.worldbank.org/v2"
WB_GDP_INDICATOR  = "NY.GDP.MKTP.KD.ZG"   # GDP growth % annual
WB_PMI_INDICATOR  = "NV.IND.MANF.ZS"      # Manufacturing value added % GDP (proxy)

WB_COUNTRIES = {
    "World":  "1W",
    "China":  "CN",
    "USA":    "US",
    "EU":     "EU",
    "India":  "IN",
    "Japan":  "JP",
}


@st.cache_data(ttl=86400, show_spinner=False)
def fetch_wb_gdp() -> dict:
    """World Bank GDP growth % for major economies. Annual data, ~1yr lag."""
    result = {}
    for country, code in WB_COUNTRIES.items():
        try:
            url = f"{WB_BASE}/country/{code}/indicator/{WB_GDP_INDICATOR}"
            r = requests.get(url, params={"format":"json","mrv":10,"per_page":10},
                             timeout=15)
            if r.status_code != 200:
                continue
            data = r.json()
            if not isinstance(data, list) or len(data) < 2:
                continue
            records = data[1]
            if not records:
                continue
            rows = [(rec["date"], rec["value"])
                    for rec in records
                    if rec.get("value") is not None]
            if not rows:
                continue
            rows.sort(key=lambda x: x[0], reverse=True)
            result[country] = {
                "latest_year":  rows[0][0],
                "latest_value": round(float(rows[0][1]), 2),
                "prev_value":   round(float(rows[1][1]), 2) if len(rows)>1 else None,
                "history":      pd.DataFrame(rows, columns=["year","gdp_growth"])
                                  .assign(year=lambda d: pd.to_numeric(d["year"]))
                                  .sort_values("year"),
            }
        except Exception:
            continue
    return result


# ── FRED PMI & MACRO ───────────────────────────────────────────────────────────
FRED_MACRO_SERIES = {
    "US_PMI":          "NAPM",        # ISM Manufacturing PMI
    "US_INDPRO":       "INDPRO",      # US Industrial Production
    "US_PMI_services": "NMFCI",       # ISM Non-Manufacturing (services)
    "US_CPI":          "CPIAUCSL",    # CPI for inflation context
    "US_unemp":        "UNRATE",      # Unemployment
    "China_Li_Keqiang":"CHNFINALCONSEXP", # China final consumption (proxy)
}

@st.cache_data(ttl=3600, show_spinner=False)
def fetch_fred_macro(fred_key: str) -> dict:
    """Fetch FRED macro series. Returns dict of {name: {value, change, series}}."""
    if not fred_key:
        return {}
    result = {}
    try:
        from fredapi import Fred
        fred = Fred(api_key=fred_key)
        for name, sid in FRED_MACRO_SERIES.items():
            try:
                s = fred.get_series(sid, limit=60)
                if s is None or len(s) < 3:
                    continue
                s.index = pd.to_datetime(s.index)
                if hasattr(s.index,"tz") and s.index.tz:
                    s.index = s.index.tz_localize(None)
                s = s.dropna()
                current = float(s.iloc[-1])
                prev    = float(s.iloc[-2]) if len(s)>1 else current
                yoy     = float(s.iloc[-13]) if len(s)>12 else None
                result[name] = {
                    "value":    round(current, 2),
                    "change":   round(current - prev, 3),
                    "yoy":      round(current - yoy, 2) if yoy else None,
                    "date":     s.index[-1].strftime("%b %Y"),
                    "series":   s.tail(36),
                }
            except Exception:
                continue
    except Exception:
        pass
    return result


# ── SUPPLY: US CRUDE PRODUCTION ───────────────────────────────────────────────
FRED_SUPPLY_SERIES = {
    "US_crude_production":   "WCRFPUS2",   # Weekly US field production (Mbbl/d)
    "US_rig_count":          "WKROC",      # Baker Hughes rig count (weekly, sometimes stale)
    "Saudi_production":      "SAOIDPCP",   # Saudi Arabia crude production
    "OPEC_production":       "TOTALSA",    # OPEC total crude (via EIA)
    "US_refinery_util":      "WPULEUS3",   # Refinery utilisation %
    "Global_oil_supply":     "PAPR_WTRADE",# Global petroleum supply proxy
}

@st.cache_data(ttl=3600, show_spinner=False)
def fetch_supply_data(fred_key: str) -> dict:
    """US production, Saudi production, OPEC via FRED."""
    if not fred_key:
        return {}
    result = {}
    try:
        from fredapi import Fred
        fred = Fred(api_key=fred_key)
        for name, sid in FRED_SUPPLY_SERIES.items():
            try:
                s = fred.get_series(sid, limit=104)
                if s is None or len(s) < 3:
                    continue
                s.index = pd.to_datetime(s.index)
                if hasattr(s.index,"tz") and s.index.tz:
                    s.index = s.index.tz_localize(None)
                s = s.dropna()
                current = float(s.iloc[-1])
                prev    = float(s.iloc[-2]) if len(s)>1 else current
                yoy     = float(s.iloc[-53]) if len(s)>52 else None
                result[name] = {
                    "value":    round(current, 3),
                    "change":   round(current - prev, 3),
                    "yoy":      round(current - yoy, 2) if yoy else None,
                    "date":     s.index[-1].strftime("%b %d, %Y"),
                    "series":   s.tail(104),
                }
            except Exception:
                continue
    except Exception:
        pass
    return result


@st.cache_data(ttl=86400, show_spinner=False)
def fetch_eia_steo() -> dict:
    """
    Download EIA Short-Term Energy Outlook Excel.
    Extracts: OPEC production, spare capacity, US production forecast.
    Free download, no API key. Updated monthly.
    """
    url = "https://www.eia.gov/outlooks/steo/xls/steo_full.xlsx"
    try:
        r = requests.get(url, timeout=30,
                         headers={"User-Agent":"Mozilla/5.0 Chrome/120.0.0.0"})
        if r.status_code != 200:
            return {"error": f"HTTP {r.status_code}", "source": "EIA STEO"}

        xl = pd.ExcelFile(io.BytesIO(r.content))
        result = {"source": "EIA STEO", "sheets": xl.sheet_names}

        # Try to parse world liquid fuels supply sheet
        for sheet_name in xl.sheet_names:
            sn = sheet_name.lower()
            if any(k in sn for k in ["world", "supply", "liquid", "petroleum"]):
                try:
                    df = pd.read_excel(xl, sheet_name=sheet_name, header=None)
                    result[f"sheet_{sheet_name}"] = df.shape
                except Exception:
                    pass

        return result
    except Exception as e:
        return {"error": str(e)[:80], "source": "EIA STEO"}


@st.cache_data(ttl=3600, show_spinner=False)
def compute_opec_compliance(fred_key: str) -> dict:
    """
    Compute OPEC spare capacity = Saudi capacity (12 mbbl/d assumed) - Saudi production.
    OPEC+ compliance = (quota - actual) / quota * 100.
    Uses FRED TOTALSA (Saudi Arabia production).
    OPEC quotas stored as static reference (updated at each OPEC meeting).
    """
    # OPEC+ production quotas (mbbl/d) — updated manually after each meeting
    # Last updated: Nov 2024 OPEC+ meeting (effective Jan 2025)
    OPEC_QUOTAS = {
        "Saudi Arabia":     9.0,
        "Russia":          9.0,
        "UAE":             3.2,
        "Iraq":            4.0,
        "Kuwait":          2.4,
        "Kazakhstan":      1.5,
        "Algeria":         0.9,
        "Nigeria":         1.5,
        "Libya":           1.2,   # exempt
        "Iran":            3.0,   # exempt (sanctions)
        "Venezuela":       0.9,   # exempt (sanctions)
    }
    OPEC_TOTAL_QUOTA = sum(OPEC_QUOTAS.values())

    result = {
        "quotas":      OPEC_QUOTAS,
        "total_quota": OPEC_TOTAL_QUOTA,
        "quota_date":  "Nov 2024 (effective Jan 2025)",
    }

    if fred_key:
        try:
            from fredapi import Fred
            fred = Fred(api_key=fred_key)
            # Saudi Arabia production
            saudi = fred.get_series("SAOIDPCP", limit=24)
            if saudi is not None and len(saudi) > 0:
                saudi = saudi.dropna()
                saudi_actual   = float(saudi.iloc[-1])
                saudi_quota    = OPEC_QUOTAS["Saudi Arabia"]
                spare_capacity = 12.0 - saudi_actual  # 12 mbbl/d max capacity
                compliance_pct = (1 - (saudi_actual - saudi_quota) / saudi_quota) * 100

                result["saudi"] = {
                    "actual":          round(saudi_actual, 2),
                    "quota":           saudi_quota,
                    "spare_capacity":  round(spare_capacity, 2),
                    "compliance_pct":  round(min(compliance_pct, 120), 1),
                    "date":            saudi.index[-1].strftime("%b %Y"),
                    "series":          saudi.tail(24),
                }
        except Exception:
            pass

    return result


# ── TRADE: CPB WORLD TRADE ────────────────────────────────────────────────────
@st.cache_data(ttl=86400, show_spinner=False)
def fetch_cpb_world_trade() -> pd.DataFrame:
    """
    CPB Netherlands Bureau for Economic Policy Analysis — World Trade Monitor.
    Free monthly CSV. URL pattern: https://www.cpb.nl/sites/default/files/omnidownload/
    Falls back to World Bank merchandise trade data if CPB unavailable.
    """
    # Try CPB direct
    cpb_urls = [
        "https://www.cpb.nl/sites/default/files/omnidownload/CPB-World-Trade-Monitor-latest-data.csv",
        "https://www.cpb.nl/en/research/topics/international-trade",
    ]
    for url in cpb_urls:
        try:
            r = requests.get(url, timeout=15,
                             headers={"User-Agent":"Mozilla/5.0 Chrome/120.0.0.0"})
            if r.status_code == 200 and "," in r.text[:100]:
                df = pd.read_csv(io.StringIO(r.text))
                if not df.empty:
                    return df
        except Exception:
            continue

    # World Bank merchandise trade fallback
    try:
        url = (f"{WB_BASE}/country/1W/indicator/TM.VAL.MRCH.GD.ZS"
               f"?format=json&mrv=15&per_page=15")
        r = requests.get(url, timeout=15)
        if r.status_code == 200:
            data = r.json()
            if isinstance(data, list) and len(data) >= 2 and data[1]:
                rows = [(rec["date"], rec["value"])
                        for rec in data[1] if rec.get("value") is not None]
                if rows:
                    df = pd.DataFrame(rows, columns=["year","trade_pct_gdp"])
                    df["year"] = pd.to_numeric(df["year"])
                    return df.sort_values("year").reset_index(drop=True)
    except Exception:
        pass

    return pd.DataFrame()


# ── TRADE: BDI PROXY (yFinance tanker stocks) ─────────────────────────────────
@st.cache_data(ttl=1800, show_spinner=False)
def fetch_bdi_proxy(period: str = "2y") -> dict:
    """
    Baltic Dry Index proxy via publicly traded shipping/tanker stocks.
    These correlate with freight rates without requiring paid BDI subscription.
    """
    import yfinance as yf

    proxies = {
        "Frontline (FRO)":   "FRO",    # VLCC — crude tanker rates
        "Scorpio (STNG)":    "STNG",   # Product tanker rates
        "Star Bulk (SBLK)":  "SBLK",   # Dry bulk — commodity shipping
        "Genco (GNK)":       "GNK",    # Dry bulk — grain/ore/coal
        "ZIM Shipping":      "ZIM",    # Container — global trade volume
        "Safe Bulkers (SB)": "SB",     # Dry bulk small-cap
    }
    result = {}
    for name, ticker in proxies.items():
        try:
            t  = yf.Ticker(ticker)
            df = t.history(period=period, auto_adjust=True)["Close"]
            if df.empty: continue
            if hasattr(df.index,"tz") and df.index.tz:
                df.index = df.index.tz_convert(None)
            current = float(df.iloc[-1])
            prev    = float(df.iloc[-2]) if len(df)>1 else current
            ret_3m  = float(df.iloc[-1]/df.iloc[max(-63,-len(df))]-1)*100 if len(df)>=63 else 0
            ret_1y  = float(df.iloc[-1]/df.iloc[0]-1)*100
            result[name] = {
                "ticker":  ticker,
                "current": round(current, 2),
                "chg_pct": round((current/prev-1)*100, 2) if prev else 0,
                "ret_3m":  round(ret_3m, 1),
                "ret_1y":  round(ret_1y, 1),
                "history": df,
                "bullish": current >= prev,
            }
        except Exception:
            continue
    return result

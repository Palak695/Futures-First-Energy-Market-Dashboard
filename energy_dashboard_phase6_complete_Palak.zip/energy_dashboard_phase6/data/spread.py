"""
data/spread.py — Phase 6 fixed
Sign-normalised stitching: local parquet (WTI-LCO, negative) → yFinance (Brent-WTI, positive).
Both converted to BRENT-WTI convention (positive = Brent premium).
"""
import pandas as pd
import numpy as np
import streamlit as st
import yfinance as yf
from data.local_data import load_wtcl_spread
from config import COLORS


def _strip_tz(s):
    try:
        if hasattr(s.index,'tz') and s.index.tz:
            s = s.copy(); s.index = s.index.tz_convert(None)
    except Exception: pass
    return s


@st.cache_data(ttl=60, show_spinner=False)
def fetch_live_spread() -> dict:
    try:
        brent  = float(yf.Ticker("BZ=F").fast_info.last_price)
        wti    = float(yf.Ticker("CL=F").fast_info.last_price)
        spread = round(brent - wti, 3)  # Brent premium convention
        return {"brent":brent, "wti":wti, "spread":spread, "valid":True}
    except Exception:
        return {"brent":0, "wti":0, "spread":0, "valid":False}


@st.cache_data(ttl=3600, show_spinner=False)
def get_spread_history() -> pd.DataFrame:
    rows = []

    # ── Local wtcl_lco parquet (WTI minus LCO = negative = WTI discount) ──────
    local = load_wtcl_spread()
    if not local.empty:
        dc = "date" if "date" in local.columns else local.columns[0]
        # Find spread column — try close_spread first, then mean_spread
        nc = [c for c in local.columns if "spread" in c.lower() or "close" in c.lower()]
        if not nc:
            nc = local.select_dtypes(include="number").columns.tolist()
        if nc:
            vc  = "close_spread" if "close_spread" in nc else nc[0]
            tmp = local[[dc, vc]].copy()
            tmp[dc] = pd.to_datetime(tmp[dc], errors="coerce")
            try:
                if tmp[dc].dt.tz is not None:
                    tmp[dc] = tmp[dc].dt.tz_convert(None)
            except Exception: pass
            tmp = tmp.dropna()

            # Detect sign convention: wtcl parquet is WTI-Brent (negative)
            # We want Brent-WTI (positive = Brent premium)
            # If median is negative, flip sign
            median_val = tmp[vc].median()
            sign = -1.0 if median_val < -0.5 else 1.0

            for _, row in tmp.iterrows():
                try:
                    rows.append({
                        "date":   row[dc],
                        "spread": round(float(row[vc]) * sign, 3),
                        "source": "local"
                    })
                except Exception:
                    continue

    # ── yFinance live (Brent - WTI = positive Brent premium) ──────────────────
    try:
        bz = _strip_tz(yf.Ticker("BZ=F").history(period="2y", auto_adjust=True)["Close"])
        cl = _strip_tz(yf.Ticker("CL=F").history(period="2y", auto_adjust=True)["Close"])
        spread_live = (bz - cl).dropna()
        live_start  = pd.Timestamp(rows[-1]["date"]) if rows else pd.Timestamp("2000-01-01")
        for dt, v in spread_live.items():
            dt_n = dt.replace(tzinfo=None) if hasattr(dt, "tzinfo") and dt.tzinfo else dt
            if pd.Timestamp(dt_n) > live_start:
                rows.append({"date": dt_n, "spread": round(float(v), 3), "source": "live"})
    except Exception:
        pass

    if not rows:
        return pd.DataFrame()

    df = pd.DataFrame(rows)
    df["date"] = pd.to_datetime(df["date"], errors="coerce")
    try:
        if df["date"].dt.tz is not None:
            df["date"] = df["date"].dt.tz_convert(None)
    except Exception: pass

    df = (df.dropna(subset=["date","spread"])
            .sort_values("date")
            .drop_duplicates(subset=["date"])
            .reset_index(drop=True))

    # Clip extreme outliers (>±$30 spread is almost certainly a data error)
    df = df[df["spread"].abs() <= 30].reset_index(drop=True)

    if df.empty:
        return df

    df["roll20"] = df["spread"].rolling(20).mean().round(3)
    df["roll60"] = df["spread"].rolling(60).mean().round(3)
    df["std60"]  = df["spread"].rolling(60).std().round(3)
    df["zscore"] = ((df["spread"] - df["roll60"]) /
                    df["std60"].replace(0, np.nan)).round(3)
    return df


def get_spread_signal(df: pd.DataFrame) -> dict:
    if df.empty:
        return {"signal":"NEUTRAL","zscore":0,"color":COLORS["neutral"]}
    z      = float(df["zscore"].iloc[-1]) if not df["zscore"].isna().all() else 0
    spread = float(df["spread"].iloc[-1])
    if z > 2.0:
        return {"signal":"SPREAD WIDE — Buy WTI / Sell Brent",
                "zscore":round(z,2),"spread":spread,"color":"#378ADD"}
    elif z < -2.0:
        return {"signal":"SPREAD TIGHT — Buy Brent / Sell WTI",
                "zscore":round(z,2),"spread":spread,"color":"#EF9F27"}
    return {"signal":"SPREAD NORMAL — No arb signal",
            "zscore":round(z,2),"spread":spread,"color":COLORS["neutral"]}

"""
data/cracks.py — Phase 4: Crack spreads (datetime fix applied)
"""
import pandas as pd
import numpy as np
import streamlit as st
import yfinance as yf

CRACK_DEFINITIONS = {
    "3:2:1 (Standard)": {
        "formula": "(2×RBOB + 1×HO - 3×CL) / 3",
        "weights": {"RB=F": 2, "HO=F": 1, "CL=F": -3},
        "divisor": 3, "unit": "$/bbl",
        "description": "Standard refinery margin",
    },
    "2:1:1 (Diesel heavy)": {
        "formula": "(RBOB + HO - 2×CL) / 2",
        "weights": {"RB=F": 1, "HO=F": 1, "CL=F": -2},
        "divisor": 2, "unit": "$/bbl",
        "description": "Useful when diesel demand dominates",
    },
    "Gasoline crack": {
        "formula": "RBOB - CL",
        "weights": {"RB=F": 1, "CL=F": -1},
        "divisor": 1, "unit": "$/bbl",
        "description": "Pure gasoline refinery margin",
    },
    "Heating Oil crack": {
        "formula": "HO - CL",
        "weights": {"HO=F": 1, "CL=F": -1},
        "divisor": 1, "unit": "$/bbl",
        "description": "Pure heating oil / diesel refinery margin",
    },
}

UNIT_CONVERSIONS = {"RB=F": 42.0, "HO=F": 42.0, "CL=F": 1.0}


def _safe_index_to_datetime(idx) -> pd.DatetimeIndex:
    """Convert any index to tz-naive DatetimeIndex."""
    try:
        dt = pd.to_datetime(idx, errors="coerce", utc=True)
        return dt.tz_convert(None)
    except Exception:
        try:
            dt = pd.to_datetime(idx, errors="coerce")
            if dt.tz is not None:
                return dt.tz_convert(None)
            return dt
        except Exception:
            return pd.to_datetime(idx, errors="coerce")


@st.cache_data(ttl=60, show_spinner=False)
def fetch_crack_prices() -> dict:
    tickers = {"RB=F": "RBOB", "HO=F": "Heating Oil", "CL=F": "WTI Crude"}
    prices  = {}
    for ticker in tickers:
        try:
            price = float(yf.Ticker(ticker).fast_info.last_price)
            prices[ticker] = round(price * UNIT_CONVERSIONS[ticker], 3)
        except Exception:
            prices[ticker] = None
    return prices


def compute_crack(crack_name: str, prices: dict) -> float | None:
    defn = CRACK_DEFINITIONS.get(crack_name)
    if not defn:
        return None
    total = 0.0
    for ticker, weight in defn["weights"].items():
        p = prices.get(ticker)
        if p is None:
            return None
        total += weight * p
    return round(total / defn["divisor"], 3)


@st.cache_data(ttl=3600, show_spinner=False)
def fetch_crack_history(crack_name: str, period: str = "2y") -> pd.DataFrame:
    defn = CRACK_DEFINITIONS.get(crack_name)
    if not defn:
        return pd.DataFrame()

    price_series = {}
    for ticker in defn["weights"]:
        try:
            df = yf.Ticker(ticker).history(period=period, auto_adjust=True)
            if not df.empty:
                s = df["Close"] * UNIT_CONVERSIONS[ticker]
                # Strip timezone from index
                s.index = _safe_index_to_datetime(s.index)
                price_series[ticker] = s
        except Exception:
            continue

    if len(price_series) < len(defn["weights"]):
        return pd.DataFrame()

    aligned = pd.DataFrame(price_series).dropna()
    crack   = (sum(aligned[t] * w
                   for t, w in defn["weights"].items()
                   if t in aligned) / defn["divisor"])

    result = pd.DataFrame({
        "date":  aligned.index,
        "crack": crack.round(3).values,
    })
    result["date"] = pd.to_datetime(result["date"], errors="coerce")
    try:
        if result["date"].dt.tz is not None:
            result["date"] = result["date"].dt.tz_convert(None)
    except Exception:
        pass

    result["ma20"] = result["crack"].rolling(20).mean().round(3)
    result["ma60"] = result["crack"].rolling(60).mean().round(3)
    return result.dropna(subset=["crack"]).reset_index(drop=True)


@st.cache_data(ttl=60, show_spinner=False)
def fetch_all_cracks() -> dict:
    prices = fetch_crack_prices()
    result = {}
    for name, defn in CRACK_DEFINITIONS.items():
        current = compute_crack(name, prices)
        hist    = fetch_crack_history(name, period="1y")
        if hist.empty or current is None:
            result[name] = {"current": current, "high52": None, "low52": None,
                            "zscore": None, "description": defn["description"]}
            continue
        vals   = hist["crack"]
        high52 = round(float(vals.max()), 3)
        low52  = round(float(vals.min()), 3)
        mean   = float(vals.mean())
        std    = float(vals.std())
        zscore = round((current - mean) / std, 2) if std > 0 else 0
        result[name] = {
            "current": current, "high52": high52, "low52": low52,
            "zscore": zscore, "mean": round(mean, 3),
            "description": defn["description"], "formula": defn["formula"],
            "history": hist,
        }
    return result

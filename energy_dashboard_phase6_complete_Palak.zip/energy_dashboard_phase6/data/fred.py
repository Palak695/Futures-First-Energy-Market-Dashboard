"""data/fred.py — FRED API with safe datetime handling"""
import pandas as pd
import streamlit as st
from fredapi import Fred
from config import FRED_SERIES, get_secret


def _get_fred():
    return Fred(api_key=get_secret("FRED_KEY"))


def _safe_series(s: pd.Series) -> pd.Series:
    """Strip timezone from series index if present."""
    if s.empty:
        return s
    try:
        if s.index.tz is not None:
            s.index = s.index.tz_convert(None)
    except Exception:
        pass
    return s


@st.cache_data(ttl=86400, show_spinner=False)
def fetch_fred_series(series_id: str, periods: int = 60) -> pd.Series:
    try:
        fred = _get_fred()
        s    = fred.get_series(series_id)
        s    = _safe_series(s.dropna().tail(periods))
        return s
    except Exception:
        return pd.Series(dtype=float)


@st.cache_data(ttl=86400, show_spinner=False)
def fetch_macro_snapshot() -> dict:
    result = {}
    for name, series_id in FRED_SERIES.items():
        s = fetch_fred_series(series_id, periods=13)
        if s.empty:
            result[name] = {"value": None, "date": "N/A", "change": None}
            continue
        latest = float(s.iloc[-1])
        prev   = float(s.iloc[-2]) if len(s) > 1 else None
        change = round(latest - prev, 3) if prev is not None else None
        result[name] = {
            "value":  round(latest, 3),
            "date":   s.index[-1].strftime("%b %Y"),
            "change": change,
            "series": s,
        }
    return result


@st.cache_data(ttl=86400, show_spinner=False)
def fetch_yield_curve_history(periods: int = 120) -> pd.Series:
    return fetch_fred_series(FRED_SERIES["yield_curve"], periods=periods)


@st.cache_data(ttl=86400, show_spinner=False)
def fetch_fed_funds_history(periods: int = 60) -> pd.Series:
    return fetch_fred_series(FRED_SERIES["fed_funds"], periods=periods)

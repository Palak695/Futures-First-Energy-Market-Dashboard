"""
data/prices.py — datetime tz fix applied throughout
"""
import yfinance as yf
import pandas as pd
import numpy as np
import streamlit as st
from datetime import datetime
from config import PRICE_TICKERS, CORRELATION_TICKERS


def _strip_tz(obj):
    """Strip timezone from DatetimeIndex or Series safely."""
    if isinstance(obj, pd.DatetimeIndex):
        try:
            return obj.tz_convert(None) if obj.tz is None else obj.tz_convert(None)
        except Exception:
            return obj
    if isinstance(obj, pd.Series):
        try:
            if obj.dt.tz is not None:
                return obj.dt.tz_convert(None)
            return obj
        except Exception:
            return obj
    return obj


def _fetch_single(ticker: str):
    for period, interval in [("5d","1h"), ("1mo","1d"), ("3mo","1d")]:
        try:
            t  = yf.Ticker(ticker)
            df = t.history(period=period, interval=interval, auto_adjust=True)
            if isinstance(df.columns, pd.MultiIndex):
                df.columns = df.columns.get_level_values(0)
            df.index = _strip_tz(pd.to_datetime(df.index, errors="coerce"))
            df = df.dropna(subset=["Close"])
            if len(df) >= 2:
                return df
        except Exception:
            continue
    return pd.DataFrame()


@st.cache_data(ttl=30, show_spinner=False)
def fetch_prices() -> dict:
    result = {}
    for name, ticker in PRICE_TICKERS.items():
        try:
            df = _fetch_single(ticker)
            if df.empty or len(df) < 2:
                result[name] = _empty(name, ticker); continue

            current    = float(df["Close"].iloc[-1])
            prev_close = float(df["Close"].iloc[-min(24, len(df)-1)])
            change     = current - prev_close
            chg_pct    = (change / prev_close * 100) if prev_close != 0 else 0.0
            window     = min(24, len(df))
            today_df   = df.tail(window)
            day_high   = float(today_df["High"].max())
            day_low    = float(today_df["Low"].min())
            volume     = int(today_df["Volume"].sum()) if "Volume" in today_df else 0
            spark      = df["Close"].tail(window).dropna().round(4).tolist()

            result[name] = {
                "ticker": ticker, "price": round(current, 4),
                "change": round(change, 4), "change_pct": round(chg_pct, 3),
                "day_high": round(day_high, 4), "day_low": round(day_low, 4),
                "volume": volume, "sparkline": spark,
                "bullish": change >= 0,
                "timestamp": datetime.now().strftime("%H:%M:%S"),
            }
        except Exception:
            result[name] = _empty(name, ticker)
    return result


def _empty(name, ticker):
    return {"ticker": ticker, "price": 0.0, "change": 0.0, "change_pct": 0.0,
            "day_high": 0.0, "day_low": 0.0, "volume": 0,
            "sparkline": [], "bullish": True, "timestamp": "–"}


@st.cache_data(ttl=3600, show_spinner=False)
def fetch_ohlcv(ticker: str, period: str = "1y", interval: str = "1d") -> pd.DataFrame:
    for p, iv in [(period, interval), ("6mo","1d"), ("3mo","1d")]:
        try:
            t  = yf.Ticker(ticker)
            df = t.history(period=p, interval=iv, auto_adjust=True)
            if isinstance(df.columns, pd.MultiIndex):
                df.columns = df.columns.get_level_values(0)
            df.index = _strip_tz(pd.to_datetime(df.index, errors="coerce"))
            df = df.dropna()
            if len(df) > 20:
                return df
        except Exception:
            continue
    return pd.DataFrame()


@st.cache_data(ttl=3600, show_spinner=False)
def fetch_correlation_data(period: str = "1y") -> pd.DataFrame:
    closes = pd.DataFrame()
    for name, ticker in CORRELATION_TICKERS.items():
        try:
            t  = yf.Ticker(ticker)
            df = t.history(period=period, auto_adjust=True)
            if not df.empty and "Close" in df.columns:
                s       = df["Close"].copy()
                s.index = _strip_tz(pd.to_datetime(s.index, errors="coerce"))
                closes[name] = s
        except Exception:
            continue
    return closes.dropna(how="all")

"""
data/calendar.py
Key events calendar — ForexFactory scrape + EIA release schedule + OPEC dates.
Each event scored for expected volatility impact using historical LCO returns.
"""

import requests
import pandas as pd
import streamlit as st
from datetime import datetime, timedelta, timezone
from bs4 import BeautifulSoup


# ── Known high-impact energy events (static schedule + scraped) ────────────────
STATIC_EVENTS = [
    # EIA weekly releases — every Wednesday 10:30 ET
    {"name": "EIA Crude Oil Inventory",     "category": "EIA",    "importance": "HIGH",   "day_of_week": 2, "hour": 10, "minute": 30},
    {"name": "EIA Gasoline Inventory",      "category": "EIA",    "importance": "HIGH",   "day_of_week": 2, "hour": 10, "minute": 30},
    {"name": "EIA Nat Gas Storage",         "category": "EIA",    "importance": "MEDIUM", "day_of_week": 3, "hour": 10, "minute": 30},
    # Baker Hughes rig count — every Friday 13:00 ET
    {"name": "Baker Hughes Rig Count",      "category": "SUPPLY", "importance": "MEDIUM", "day_of_week": 4, "hour": 13, "minute": 0},
    # CFTC COT — every Friday 15:30 ET
    {"name": "CFTC COT Positioning Report", "category": "CFTC",   "importance": "MEDIUM", "day_of_week": 4, "hour": 15, "minute": 30},
]

OPEC_MEETINGS_2025_2026 = [
    {"name": "OPEC+ Ministerial Meeting", "date": "2025-12-05", "importance": "CRITICAL"},
    {"name": "OPEC+ Production Review",   "date": "2026-02-03", "importance": "CRITICAL"},
    {"name": "OPEC+ Ministerial Meeting", "date": "2026-05-05", "importance": "CRITICAL"},
    {"name": "OPEC+ Ministerial Meeting", "date": "2026-11-30", "importance": "CRITICAL"},
]

FED_MEETINGS_2026 = [
    {"name": "FOMC Rate Decision",        "date": "2026-01-29", "importance": "HIGH"},
    {"name": "FOMC Rate Decision",        "date": "2026-03-19", "importance": "HIGH"},
    {"name": "FOMC Rate Decision",        "date": "2026-05-07", "importance": "HIGH"},
    {"name": "FOMC Rate Decision",        "date": "2026-06-18", "importance": "HIGH"},
    {"name": "FOMC Rate Decision",        "date": "2026-07-30", "importance": "HIGH"},
    {"name": "FOMC Rate Decision",        "date": "2026-09-17", "importance": "HIGH"},
    {"name": "FOMC Rate Decision",        "date": "2026-11-05", "importance": "HIGH"},
    {"name": "FOMC Rate Decision",        "date": "2026-12-16", "importance": "HIGH"},
]

IMPORTANCE_COLORS = {
    "CRITICAL": "#E24B4A",
    "HIGH":     "#EF9F27",
    "MEDIUM":   "#378ADD",
    "LOW":      "#888780",
}

IMPORTANCE_VOL = {
    "CRITICAL": 3.2,   # expected ATR expansion multiple
    "HIGH":     1.8,
    "MEDIUM":   1.2,
    "LOW":      1.0,
}


@st.cache_data(ttl=3600, show_spinner=False)
def fetch_forexfactory_events() -> list:
    """Scrape ForexFactory calendar for energy/macro events this week."""
    events = []
    try:
        url = "https://www.forexfactory.com/calendar"
        headers = {
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36",
            "Accept-Language": "en-US,en;q=0.9",
        }
        resp = requests.get(url, headers=headers, timeout=10)
        if resp.status_code != 200:
            return []
        soup = BeautifulSoup(resp.text, "html.parser")
        rows = soup.select("tr.calendar__row")

        energy_keywords = ["crude","oil","opec","eia","natural gas","gasoline",
                           "petroleum","fed","fomc","gdp","cpi","pmi","inflation","rate"]
        current_date = None

        for row in rows[:80]:
            try:
                date_cell = row.select_one(".calendar__date span")
                if date_cell and date_cell.text.strip():
                    try:
                        current_date = date_cell.text.strip()
                    except Exception:
                        pass

                title_el = row.select_one(".calendar__event-title")
                if not title_el:
                    continue
                title = title_el.text.strip()
                if not any(kw in title.lower() for kw in energy_keywords):
                    continue

                impact_el = row.select_one(".calendar__impact span")
                impact = "HIGH" if impact_el and "high" in str(impact_el.get("class","")).lower() else \
                         "MEDIUM" if impact_el and "medium" in str(impact_el.get("class","")).lower() else "LOW"

                time_el = row.select_one(".calendar__time")
                time_str = time_el.text.strip() if time_el else "All Day"

                actual_el = row.select_one(".calendar__actual")
                forecast_el = row.select_one(".calendar__forecast")

                events.append({
                    "name":       title,
                    "date_str":   current_date or "",
                    "time":       time_str,
                    "importance": impact,
                    "category":   "MACRO",
                    "actual":     actual_el.text.strip() if actual_el else "–",
                    "forecast":   forecast_el.text.strip() if forecast_el else "–",
                    "source":     "ForexFactory",
                })
            except Exception:
                continue
    except Exception:
        pass
    return events


@st.cache_data(ttl=1800, show_spinner=False)
def get_upcoming_events(days_ahead: int = 14) -> pd.DataFrame:
    """
    Build unified events calendar — next N days.
    Combines: static weekly events + OPEC + Fed + ForexFactory scrape.
    """
    now   = datetime.now(timezone.utc)
    rows  = []

    # ── Recurring weekly events ────────────────────────────────────────────────
    for event in STATIC_EVENTS:
        # Find next occurrence of this weekday
        days_until = (event["day_of_week"] - now.weekday()) % 7
        if days_until == 0 and now.hour >= event["hour"]:
            days_until = 7  # already passed today
        event_dt = now.replace(hour=event["hour"], minute=event["minute"],
                               second=0, microsecond=0) + timedelta(days=days_until)
        if (event_dt - now).days <= days_ahead:
            rows.append({
                "datetime":   event_dt,
                "name":       event["name"],
                "category":   event["category"],
                "importance": event["importance"],
                "countdown":  _countdown(event_dt),
                "vol_impact": f"{IMPORTANCE_VOL[event['importance']]}x ATR",
                "actual":     "–",
                "forecast":   "–",
                "source":     "EIA/CFTC",
            })

    # ── OPEC meetings ──────────────────────────────────────────────────────────
    for ev in OPEC_MEETINGS_2025_2026:
        try:
            dt = datetime.strptime(ev["date"], "%Y-%m-%d").replace(
                hour=10, tzinfo=timezone.utc)
            if 0 <= (dt - now).days <= days_ahead * 4:
                rows.append({
                    "datetime":   dt,
                    "name":       ev["name"],
                    "category":   "OPEC",
                    "importance": ev["importance"],
                    "countdown":  _countdown(dt),
                    "vol_impact": f"{IMPORTANCE_VOL[ev['importance']]}x ATR",
                    "actual": "–", "forecast": "–", "source": "OPEC",
                })
        except Exception:
            continue

    # ── Fed meetings ───────────────────────────────────────────────────────────
    for ev in FED_MEETINGS_2026:
        try:
            dt = datetime.strptime(ev["date"], "%Y-%m-%d").replace(
                hour=14, minute=0, tzinfo=timezone.utc)
            if 0 <= (dt - now).days <= days_ahead * 4:
                rows.append({
                    "datetime":   dt,
                    "name":       ev["name"],
                    "category":   "FED",
                    "importance": ev["importance"],
                    "countdown":  _countdown(dt),
                    "vol_impact": f"{IMPORTANCE_VOL[ev['importance']]}x ATR",
                    "actual": "–", "forecast": "–", "source": "Federal Reserve",
                })
        except Exception:
            continue

    # ── ForexFactory scrape ────────────────────────────────────────────────────
    ff_events = fetch_forexfactory_events()
    for ev in ff_events:
        rows.append({
            "datetime":   now + timedelta(days=1),  # approx
            "name":       ev["name"],
            "category":   ev["category"],
            "importance": ev["importance"],
            "countdown":  ev.get("time","–"),
            "vol_impact": f"{IMPORTANCE_VOL.get(ev['importance'],1.0)}x ATR",
            "actual":     ev.get("actual","–"),
            "forecast":   ev.get("forecast","–"),
            "source":     "ForexFactory",
        })

    if not rows:
        return pd.DataFrame()

    df = pd.DataFrame(rows)
    df = df.sort_values("datetime").reset_index(drop=True)
    return df


def _countdown(dt: datetime) -> str:
    """Human-readable countdown to event."""
    try:
        now   = datetime.now(timezone.utc)
        delta = dt - now
        secs  = int(delta.total_seconds())
        if secs < 0:       return "Passed"
        if secs < 3600:    return f"{secs//60}m"
        if secs < 86400:   return f"{secs//3600}h {(secs%3600)//60}m"
        return f"{secs//86400}d {(secs%86400)//3600}h"
    except Exception:
        return "–"


def get_next_eia_release() -> dict:
    """Return info about next EIA weekly report."""
    now = datetime.now(timezone.utc)
    days_to_wed = (2 - now.weekday()) % 7
    if days_to_wed == 0 and now.hour >= 10:
        days_to_wed = 7
    next_wed = now + timedelta(days=days_to_wed)
    next_wed = next_wed.replace(hour=10, minute=30, second=0, microsecond=0)
    return {
        "datetime":  next_wed,
        "countdown": _countdown(next_wed),
        "name":      "EIA Weekly Petroleum Status Report",
    }

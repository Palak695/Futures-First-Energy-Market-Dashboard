"""
data/futures_curve.py — Phase 6 final
Brent:    LCOSettle parquet (c1-c31) — full term structure
WTI/HO/LGO: curve_daily parquet (c1-c10 from 1-min data) — real multi-contract curve
All products: Investing.com scrape override when accessible
"""
import requests
import pandas as pd
import numpy as np
import streamlit as st
from scipy.optimize import curve_fit
from data.local_data import (load_lco_settle, load_cl_daily, load_ho_monthly,
                              load_lgo_monthly, load_lco_daily,
                              load_cl_curve, load_ho_curve, load_lgo_curve)

INVESTING_HEADERS = {
    "User-Agent": ("Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
                   "AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0"),
    "Accept-Language": "en-US,en;q=0.9",
    "Referer": "https://www.google.com/",
}
FUTURES_URLS = {
    "Brent": "https://www.investing.com/commodities/brent-oil-futures",
    "WTI":   "https://www.investing.com/commodities/crude-oil-futures",
    "HO":    "https://www.investing.com/commodities/heating-oil-futures",
    "LGO":   "https://www.investing.com/commodities/london-gas-oil-futures",
    "NG":    "https://www.investing.com/commodities/natural-gas-futures",
}
PRODUCT_SOURCES = {
    "Brent": "LCOSettle parquet (c1–c31)",
    "WTI":   "cl_curve_daily parquet (c1–c10 from CL_data.csv)",
    "HO":    "ho_curve_daily parquet (c1–c10 from HO_data.csv)",
    "LGO":   "lgo_curve_daily parquet (c1–c10 from LGO_data.csv)",
    "NG":    "Investing.com live scrape",
}
PRODUCT_LABELS = {
    "Brent": "Brent Crude (LCO) — ICE",
    "WTI":   "WTI Crude (CL) — NYMEX",
    "HO":    "Heating Oil (HO) — NYMEX",
    "LGO":   "ICE Gasoil (LGO) — ICE",
    "NG":    "Natural Gas (NG) — NYMEX",
}


@st.cache_data(ttl=900, show_spinner=False)
def fetch_futures_strip(product: str = "Brent") -> pd.DataFrame:
    """
    Priority:
    Brent  → LCOSettle parquet → Investing.com
    WTI    → cl_curve_daily parquet (c1-c10) → Investing.com → M1 yF
    HO     → ho_curve_daily parquet (c1-c10) → Investing.com → M1 yF
    LGO    → lgo_curve_daily parquet (c1-c10) → Investing.com
    NG     → Investing.com → M1 yF
    """
    if product == "Brent":
        df = _from_lco_settle()
        if not df.empty:
            return df
        return _scrape_investing(product)

    if product == "WTI":
        df = _from_curve_parquet(load_cl_curve(), "CL", unit_mult=1.0)
        if not df.empty:
            return df

    elif product == "HO":
        df = _from_curve_parquet(load_ho_curve(), "HO", unit_mult=None)
        if not df.empty:
            return df

    elif product == "LGO":
        df = _from_curve_parquet(load_lgo_curve(), "LGO", unit_mult=1.0)
        if not df.empty:
            return df

    # Try Investing.com scrape
    df = _scrape_investing(product)
    if not df.empty and len(df) >= 3:
        return df

    # Last resort: M1 from yFinance
    return _yfinance_m1(product)


def _from_curve_parquet(curve_df: pd.DataFrame, prefix: str,
                        unit_mult: float = None) -> pd.DataFrame:
    """
    Extract latest day's c1-c10 closing prices from curve parquet.
    Returns strip DataFrame for term structure chart.
    """
    if curve_df.empty:
        return pd.DataFrame()

    # Find contract columns
    contract_cols = []
    for i in range(1, 13):
        col = f"{prefix}c{i}"
        if col in curve_df.columns:
            contract_cols.append((i, col))

    if len(contract_cols) < 2:
        # Try alternate naming (e.g. CLc1 vs CL1)
        for i in range(1, 13):
            col = f"{prefix}{i}"
            if col in curve_df.columns:
                contract_cols.append((i, col))

    if len(contract_cols) < 2:
        return pd.DataFrame()

    # Get latest row with all contracts populated
    ts_col = "timestamp" if "timestamp" in curve_df.columns else curve_df.columns[0]
    df_sorted = curve_df.sort_values(ts_col)

    # Find latest row where at least half the contracts have data
    min_contracts_needed = max(2, len(contract_cols) // 2)
    for idx in range(len(df_sorted)-1, max(len(df_sorted)-30, -1), -1):
        row = df_sorted.iloc[idx]
        valid = sum(1 for _, col in contract_cols
                    if pd.notna(row.get(col)) and float(row.get(col, 0)) > 0)
        if valid >= min_contracts_needed:
            latest = row
            date_str = str(row[ts_col])[:10]
            break
    else:
        latest = df_sorted.iloc[-1]
        date_str = str(latest[ts_col])[:10]

    # Also get previous day for comparison
    prev_idx = max(0, len(df_sorted)-2)
    prev = df_sorted.iloc[prev_idx]
    prev_date = str(prev[ts_col])[:10]

    rows = []
    for mnum, col in contract_cols:
        try:
            price = float(latest[col])
            prev_price = float(prev[col]) if col in prev else price
            if pd.notna(price) and price > 0:
                # Auto-detect unit conversion: HO in ¢/gal → $/bbl
                if unit_mult is None:
                    unit_mult_actual = 42.0 if price < 10 else 1.0
                else:
                    unit_mult_actual = unit_mult
                rows.append({
                    "contract":   f"M{mnum}",
                    "price":      round(price * unit_mult_actual, 3),
                    "price_prev": round(float(prev_price) * unit_mult_actual, 3)
                                  if pd.notna(prev_price) and float(prev_price) > 0
                                  else round(price * unit_mult_actual, 3),
                    "month":      mnum,
                    "source":     f"Local parquet ({prefix}c1–{prefix}c{mnum})",
                    "date":       date_str,
                    "date_prev":  prev_date,
                })
        except Exception:
            continue

    return pd.DataFrame(rows) if len(rows) >= 2 else pd.DataFrame()


def _from_lco_settle() -> pd.DataFrame:
    lco = load_lco_settle()
    if lco.empty:
        return pd.DataFrame()
    date_col = "date" if "date" in lco.columns else lco.columns[0]
    contract_cols = [(i, f"LCOc{i}") for i in range(1, 32)
                     if f"LCOc{i}" in lco.columns]
    if not contract_cols:
        settle = sorted([c for c in lco.columns
                         if "SETTLE" in str(c).upper() and c != date_col],
                        key=lambda x: int(''.join(filter(str.isdigit,x)) or "0"))
        contract_cols = [(i+1,c) for i,c in enumerate(settle)]
    if not contract_cols:
        return pd.DataFrame()
    df_s   = lco.sort_values(date_col)
    latest = df_s.iloc[-1]; prev = df_s.iloc[-2] if len(df_s)>1 else latest
    rows   = []
    for mnum, col in contract_cols:
        try:
            price = float(latest[col]); pp = float(prev[col])
            if pd.notna(price) and price > 0:
                rows.append({"contract":f"M{mnum}","price":round(price,3),
                             "price_prev":round(pp,3) if pd.notna(pp) and pp>0 else round(price,3),
                             "month":mnum,"source":"LCOSettle (local)",
                             "date":str(latest[date_col])[:10],
                             "date_prev":str(prev[date_col])[:10]})
        except Exception:
            continue
    return pd.DataFrame(rows) if len(rows)>=2 else pd.DataFrame()


def _scrape_investing(product: str) -> pd.DataFrame:
    url = FUTURES_URLS.get(product)
    if not url: return pd.DataFrame()
    try:
        from bs4 import BeautifulSoup
        resp = requests.get(url, headers=INVESTING_HEADERS, timeout=12)
        if resp.status_code != 200: return pd.DataFrame()
        soup  = BeautifulSoup(resp.text, "html.parser")
        table = (soup.find("table",{"id":"curr_table"}) or
                 soup.find("table",class_=lambda c: c and "datatable" in str(c).lower()))
        if not table: return pd.DataFrame()
        rows=[]
        for i,tr in enumerate(table.find_all("tr")[1:13]):
            tds=tr.find_all("td")
            if len(tds)<2: continue
            try:
                label=tds[0].get_text(strip=True)
                price=float(tds[1].get_text(strip=True).replace(",",""))
                rows.append({"contract":label,"price":price,"price_prev":price,
                             "month":i+1,"source":"Investing.com (live)"})
            except Exception: continue
        return pd.DataFrame(rows) if rows else pd.DataFrame()
    except Exception:
        return pd.DataFrame()


def _yfinance_m1(product: str) -> pd.DataFrame:
    import yfinance as yf
    ticker_map={"Brent":"BZ=F","WTI":"CL=F","HO":"HO=F","LGO":"HO=F","NG":"NG=F"}
    try:
        price=float(yf.Ticker(ticker_map.get(product,"CL=F")).fast_info.last_price)
        if price and price>0:
            if product=="HO" and price<10: price=price*42
            return pd.DataFrame([{"contract":"M1","price":round(price,3),
                                   "price_prev":round(price,3),"month":1,
                                   "source":"yFinance (M1 only)"}])
    except Exception: pass
    return pd.DataFrame()


def nelson_siegel(m, b0, b1, b2, tau):
    tau=max(tau,0.01); t=m/tau
    return b0+b1*(1-np.exp(-t))/t+b2*((1-np.exp(-t))/t-np.exp(-t))


@st.cache_data(ttl=900, show_spinner=False)
def fit_nelson_siegel(prices: list, maturities: list=None) -> dict:
    if not prices or len(prices)<4:
        return {"fitted":prices,"x_fine":maturities or [],"params":None}
    if maturities is None: maturities=list(range(1,len(prices)+1))
    x,y=np.array(maturities,dtype=float),np.array(prices,dtype=float)
    try:
        popt,_=curve_fit(nelson_siegel,x,y,p0=[y[-1],y[0]-y[-1],0.0,2.0],
                         bounds=([0,-50,-50,0.1],[500,50,50,30]),maxfev=5000,method="trf")
        xf=np.linspace(x[0],x[-1],100)
        return {"fitted":nelson_siegel(xf,*popt).tolist(),"x_fine":xf.tolist(),
                "params":{k:round(float(v),4) for k,v in zip(["beta0","beta1","beta2","tau"],popt)},
                "error":None}
    except Exception as e:
        return {"fitted":prices,"x_fine":list(maturities),"params":None,"error":str(e)}


def classify_structure(prices: list) -> dict:
    if len(prices)<2:
        return {"structure":"–","slope":0,"color":"#888780","description":"–"}
    slope=prices[-1]-prices[0]
    if slope>0.3:
        return {"structure":"CONTANGO","slope":round(slope,3),"color":"#E24B4A",
                "description":"Storage stress / bearish carry"}
    elif slope<-0.3:
        return {"structure":"BACKWARDATION","slope":round(slope,3),"color":"#1D9E75",
                "description":"Supply tightness / bullish carry"}
    return {"structure":"FLAT","slope":round(slope,3),"color":"#888780",
            "description":"Balanced market"}


@st.cache_data(ttl=3600, show_spinner=False)
def fetch_price_history(product: str) -> tuple:
    try:
        if product=="WTI":   df,label=load_cl_daily(),"WTI (CL) $/bbl"
        elif product=="HO":  df,label=load_ho_monthly(),"Heating Oil (HO)"
        elif product=="LGO": df,label=load_lgo_monthly(),"ICE Gasoil (LGO)"
        elif product=="Brent":df,label=load_lco_daily(),"Brent (LCO) $/bbl"
        else: return pd.DataFrame(), product
        if df.empty: return pd.DataFrame(), label
        ts=next((c for c in df.columns if "timestamp" in c.lower() or "date" in c.lower()),df.columns[0])
        df=df.rename(columns={ts:"timestamp"})
        df["timestamp"]=pd.to_datetime(df["timestamp"],errors="coerce")
        try:
            if df["timestamp"].dt.tz is not None: df["timestamp"]=df["timestamp"].dt.tz_convert(None)
        except Exception: pass
        df=df.dropna(subset=["timestamp"]).sort_values("timestamp").reset_index(drop=True)
        return df, label
    except Exception:
        return pd.DataFrame(), product

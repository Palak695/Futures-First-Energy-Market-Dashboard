"""
data/cot.py — Robust COT with visible diagnostics + manual CSV fallback
"""
import requests
import pandas as pd
import numpy as np
import io
import streamlit as st
from config import CFTC_CODES

CFTC_URLS = {
    "disagg": "https://www.cftc.gov/dea/newcot/c_disagg.txt",
    "legacy":  "https://www.cftc.gov/dea/newcot/c_fut.txt",
}
BRENT_USES_LEGACY = True

HEADERS = {
    "User-Agent": ("Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
                   "AppleWebKit/537.36 (KHTML, like Gecko) "
                   "Chrome/124.0.0.0 Safari/537.36"),
    "Accept": "text/html,application/xhtml+xml,text/plain,*/*;q=0.8",
    "Accept-Language": "en-US,en;q=0.9",
    "Cache-Control": "no-cache",
}


def _parse_cot_csv(text: str, code: str) -> tuple:
    """Parse raw CFTC text. Returns (DataFrame, error_msg)."""
    try:
        df = pd.read_csv(io.StringIO(text), low_memory=False)
    except Exception as e:
        return pd.DataFrame(), f"CSV parse failed: {e}"

    # Verify it's actually a CFTC file (not HTML/captcha)
    if len(df.columns) < 5:
        snippet = text[:200].replace('\n', ' ')
        return pd.DataFrame(), f"Not a valid CSV (got {len(df.columns)} cols). Response: {snippet[:80]}"

    # Find CFTC code column
    code_col = next((c for c in df.columns
                     if "CFTC" in c.upper() and "CODE" in c.upper()), None)
    if not code_col:
        return pd.DataFrame(), f"No CFTC code column found. Cols: {list(df.columns[:5])}"

    df_prod = df[df[code_col].astype(str).str.strip() == str(code)].copy()
    if df_prod.empty:
        all_codes = df[code_col].astype(str).str.strip().unique()[:5].tolist()
        return pd.DataFrame(), f"Code '{code}' not found. Sample codes: {all_codes}"

    # Date column — prefer explicit yyyy-mm-dd format
    date_col = None
    for pref in ["Report_Date_as_YYYY-MM-DD", "Report_Date_as_MM_DD_YYYY",
                 "As_of_Date_In_Form_YYMMDD"]:
        if pref in df.columns:
            date_col = pref
            break
    if not date_col:
        date_col = next((c for c in df.columns if "date" in c.lower()), None)
    if not date_col:
        return pd.DataFrame(), "No date column found"

    # Parse dates robustly
    raw = df_prod[date_col].astype(str)
    parsed = pd.to_datetime(raw, errors="coerce", dayfirst=False)
    if parsed.dropna().empty or parsed.dropna().dt.year.max() < 2000:
        for fmt in ["%m/%d/%Y", "%Y-%m-%d", "%Y%m%d", "%y%m%d"]:
            try:
                alt = pd.to_datetime(raw, format=fmt, errors="coerce")
                if not alt.dropna().empty and alt.dropna().dt.year.max() >= 2000:
                    parsed = alt; break
            except Exception:
                continue

    df_prod = df_prod.copy()
    df_prod["date"] = parsed
    df_prod = df_prod[df_prod["date"].dt.year >= 2000].reset_index(drop=True)
    if df_prod.empty:
        return pd.DataFrame(), f"All dates pre-2000 for code {code}. Raw sample: {raw.iloc[0] if len(raw) else 'empty'}"

    # Managed money columns — try multiple naming conventions
    mm_long = mm_short = None
    for pfx, lkey, skey in [
        ("M_Money_Positions",  "Long_All",  "Short_All"),
        ("NonComm_Positions",  "Long_All",  "Short_All"),
        ("NonCommercial",      "Long",      "Short"),
        ("Managed_Money",      "Long",      "Short"),
    ]:
        cl = [c for c in df.columns if pfx in c and lkey in c
              and "Change" not in c and "Spread" not in c]
        cs = [c for c in df.columns if pfx in c and skey in c
              and "Change" not in c and "Spread" not in c]
        if cl and cs:
            mm_long, mm_short = cl[0], cs[0]
            break

    if not mm_long or not mm_short:
        long_candidates = [c for c in df.columns if "Long" in c and "Change" not in c][:4]
        return pd.DataFrame(), f"No managed money cols. Long candidates: {long_candidates}"

    oi_col = next((c for c in df.columns
                   if "Open_Interest_All" in c and "Change" not in c), None)

    result = pd.DataFrame({
        "date":     df_prod["date"].values,
        "mm_long":  pd.to_numeric(df_prod[mm_long],  errors="coerce").values,
        "mm_short": pd.to_numeric(df_prod[mm_short], errors="coerce").values,
        "oi":       pd.to_numeric(df_prod[oi_col],   errors="coerce").values if oi_col else np.nan,
    })
    result = result.dropna(subset=["mm_long","mm_short"]).sort_values("date").reset_index(drop=True)
    if result.empty:
        return pd.DataFrame(), "All mm_long/mm_short values are NaN after parsing"

    result["net"]         = result["mm_long"] - result["mm_short"]
    result["net_pct"]     = result["mm_long"] / (result["mm_long"] + result["mm_short"]) * 100
    window = min(52, len(result))
    result["net_pct_rank"] = result["net"].rolling(window).apply(
        lambda x: pd.Series(x).rank(pct=True).iloc[-1] * 100, raw=False).round(1)

    return result, ""


@st.cache_data(ttl=3600, show_spinner=False)
def fetch_cot_data(commodity: str = "WTI") -> tuple:
    """Returns (DataFrame, error_message)."""
    code = CFTC_CODES.get(commodity)
    if not code:
        return pd.DataFrame(), f"No CFTC code for '{commodity}'"

    # Brent uses legacy file, others use disaggregated
    urls = ([CFTC_URLS["legacy"], CFTC_URLS["disagg"]]
            if commodity == "Brent"
            else [CFTC_URLS["disagg"], CFTC_URLS["legacy"]])

    errors = []
    for url in urls:
        try:
            resp = requests.get(url, headers=HEADERS, timeout=30)
            if resp.status_code != 200:
                errors.append(f"{url.split('/')[-1]}: HTTP {resp.status_code}")
                continue

            # Check if it looks like HTML (bot protection)
            first_line = resp.text.strip()[:100]
            if first_line.startswith("<") or "DOCTYPE" in first_line.upper():
                errors.append(f"{url.split('/')[-1]}: Got HTML instead of CSV (bot protection?)")
                continue

            df, err = _parse_cot_csv(resp.text, code)
            if not df.empty:
                return df, ""
            errors.append(f"{url.split('/')[-1]}: {err}")

        except requests.Timeout:
            errors.append(f"{url.split('/')[-1]}: Timeout after 30s")
        except Exception as e:
            errors.append(f"{url.split('/')[-1]}: {str(e)[:60]}")

    return pd.DataFrame(), " | ".join(errors)


def get_cot_signal(df: pd.DataFrame) -> dict:
    if df.empty:
        return {"signal":"NEUTRAL","percentile":50,"description":"No data","net":0,"color":"#888780"}
    l = df.iloc[-1]
    pct = float(l.get("net_pct_rank", 50) or 50)
    net = float(l.get("net", 0) or 0)
    if pct > 80:
        return {"signal":"CROWDED LONG","percentile":round(pct,1),"net":int(net),
                "description":f"{pct:.0f}th pct — extreme long, contrarian bearish","color":"#E24B4A"}
    if pct > 60:
        return {"signal":"BULLISH","percentile":round(pct,1),"net":int(net),
                "description":f"{pct:.0f}th pct — above-average long","color":"#1D9E75"}
    if pct < 20:
        return {"signal":"CROWDED SHORT","percentile":round(pct,1),"net":int(net),
                "description":f"{pct:.0f}th pct — extreme short, contrarian bullish","color":"#1D9E75"}
    if pct < 40:
        return {"signal":"BEARISH","percentile":round(pct,1),"net":int(net),
                "description":f"{pct:.0f}th pct — below-average long","color":"#E24B4A"}
    return {"signal":"NEUTRAL","percentile":round(pct,1),"net":int(net),
            "description":f"{pct:.0f}th pct — balanced","color":"#888780"}


def clear_cot_cache():
    fetch_cot_data.clear()

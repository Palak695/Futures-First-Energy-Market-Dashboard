"""
data/demand_indicators.py
Demand indicators using yFinance proxies + FRED data + Baltic freight indices.
All free-tier sources that work on local machines.
"""
import yfinance as yf
import pandas as pd
import numpy as np
import streamlit as st
from config import get_secret, COLORS


def _strip_tz(s: pd.Series) -> pd.Series:
    try:
        if hasattr(s.index, "tz") and s.index.tz:
            s = s.copy(); s.index = s.index.tz_convert(None)
    except Exception: pass
    return s


# ── Freight rates ──────────────────────────────────────────────────────────────
# yFinance proxies for tanker/freight market
FREIGHT_PROXIES = {
    "Frontline (FRO)":     "FRO",      # VLCC tanker operator
    "Nordic Tankers (INSW)":"INSW",    # International Seaways
    "Scorpio Tankers":     "STNG",     # Product tanker
    "ZIM Shipping":        "ZIM",      # Container / shipping proxy
    "Danaos":              "DAC",      # Container ships
}

# Baltic Dry Index via alternative — not on yF, but proxy via shipping stocks
# BDIY is the symbol but not available free tier
# Use MAERSK.CO on yF as proxy (listed in DKK)

# ── China demand proxies ───────────────────────────────────────────────────────
CHINA_PROXIES = {
    "MCHI (China ETF)":     "MCHI",    # iShares MSCI China
    "FXI (China Large Cap)":"FXI",     # iShares China Large-Cap
    "BABA (Alibaba)":       "BABA",    # China economic activity proxy
}

# ── Airline/Aviation proxies ──────────────────────────────────────────────────
AIRLINE_PROXIES = {
    "United Airlines": "UAL",
    "Delta Airlines":  "DAL",
    "Southwest":       "LUV",
    "IAG (Europe)":    "IAG.L",
    "Air China":       "0753.HK",
}

# ── Refinery proxies ──────────────────────────────────────────────────────────
REFINERY_PROXIES = {
    "Valero Energy":   "VLO",
    "Marathon Pete.":  "MPC",
    "Phillips 66":     "PSX",
    "Neste (EU ref.)": "NESTE.HE",
}

# ── FRED series for industrial demand ─────────────────────────────────────────
FRED_DEMAND = {
    "US Indus. Production": "INDPRO",
    "US Refinery Util %":   "WPULEUS3",
    "US Crude Imports":     "WCRIMUS2",
    "Jet Fuel Demand":      "WJFUPUS2",
    "Diesel Demand":        "WDIRPUS2",
}


@st.cache_data(ttl=1800, show_spinner=False)
def fetch_freight_proxies(period: str = "1y") -> dict:
    """Fetch tanker/shipping stock prices as freight rate proxies."""
    result = {}
    for name, ticker in FREIGHT_PROXIES.items():
        try:
            t  = yf.Ticker(ticker)
            df = _strip_tz(t.history(period=period, auto_adjust=True)["Close"])
            if df.empty: continue
            current  = float(df.iloc[-1])
            prev     = float(df.iloc[-2]) if len(df) > 1 else current
            ret_1m   = float(df.iloc[-1]/df.iloc[max(-22,-(len(df)))] - 1) * 100 if len(df) >= 22 else 0
            ret_3m   = float(df.iloc[-1]/df.iloc[max(-63,-(len(df)))] - 1) * 100 if len(df) >= 63 else 0
            result[name] = {
                "ticker":  ticker,
                "current": round(current, 2),
                "change":  round(current - prev, 2),
                "chg_pct": round((current/prev - 1)*100, 2) if prev else 0,
                "ret_1m":  round(ret_1m, 1),
                "ret_3m":  round(ret_3m, 1),
                "history": df,
                "bullish": current >= prev,
            }
        except Exception:
            continue
    return result


@st.cache_data(ttl=1800, show_spinner=False)
def fetch_china_demand_proxies(period: str = "1y") -> dict:
    """China demand proxy via ETFs."""
    result = {}
    for name, ticker in CHINA_PROXIES.items():
        try:
            t  = yf.Ticker(ticker)
            df = _strip_tz(t.history(period=period, auto_adjust=True)["Close"])
            if df.empty: continue
            current = float(df.iloc[-1])
            prev    = float(df.iloc[-2]) if len(df) > 1 else current
            ret_3m  = float(df.iloc[-1]/df.iloc[max(-63,-len(df))] - 1)*100 if len(df)>=63 else 0
            ret_1y  = float(df.iloc[-1]/df.iloc[0] - 1)*100 if len(df)>=200 else 0
            result[name] = {
                "ticker":  ticker,
                "current": round(current, 2),
                "chg_pct": round((current/prev - 1)*100, 2) if prev else 0,
                "ret_3m":  round(ret_3m, 1),
                "ret_1y":  round(ret_1y, 1),
                "history": df,
                "bullish": current >= prev,
            }
        except Exception:
            continue
    return result


@st.cache_data(ttl=1800, show_spinner=False)
def fetch_airline_proxies(period: str = "1y") -> dict:
    """Airline stock prices as jet fuel demand proxy."""
    result = {}
    for name, ticker in AIRLINE_PROXIES.items():
        try:
            t  = yf.Ticker(ticker)
            df = _strip_tz(t.history(period=period, auto_adjust=True)["Close"])
            if df.empty: continue
            current = float(df.iloc[-1])
            prev    = float(df.iloc[-2]) if len(df) > 1 else current
            ret_3m  = float(df.iloc[-1]/df.iloc[max(-63,-len(df))] - 1)*100 if len(df)>=63 else 0
            result[name] = {
                "ticker":  ticker,
                "current": round(current, 2),
                "chg_pct": round((current/prev - 1)*100, 2) if prev else 0,
                "ret_3m":  round(ret_3m, 1),
                "history": df,
                "bullish": current >= prev,
            }
        except Exception:
            continue
    return result


@st.cache_data(ttl=1800, show_spinner=False)
def fetch_refinery_proxies(period: str = "1y") -> dict:
    """Refinery stock prices as throughput proxy."""
    result = {}
    for name, ticker in REFINERY_PROXIES.items():
        try:
            t  = yf.Ticker(ticker)
            df = _strip_tz(t.history(period=period, auto_adjust=True)["Close"])
            if df.empty: continue
            current = float(df.iloc[-1])
            prev    = float(df.iloc[-2]) if len(df) > 1 else current
            ret_3m  = float(df.iloc[-1]/df.iloc[max(-63,-len(df))] - 1)*100 if len(df)>=63 else 0
            result[name] = {
                "ticker":  ticker,
                "current": round(current, 2),
                "chg_pct": round((current/prev - 1)*100, 2) if prev else 0,
                "ret_3m":  round(ret_3m, 1),
                "history": df,
                "bullish": current >= prev,
            }
        except Exception:
            continue
    return result


@st.cache_data(ttl=3600, show_spinner=False)
def fetch_fred_demand(fred_key: str) -> dict:
    """FRED demand series: refinery util, crude imports, jet fuel, diesel."""
    if not fred_key:
        return {}
    result = {}
    try:
        from fredapi import Fred
        fred = Fred(api_key=fred_key)
        for name, sid in FRED_DEMAND.items():
            try:
                s = fred.get_series(sid, limit=60)
                if s is not None and len(s) > 5:
                    s.index = pd.to_datetime(s.index)
                    if hasattr(s.index,"tz") and s.index.tz:
                        s.index = s.index.tz_localize(None)
                    s = s.dropna()
                    current = float(s.iloc[-1])
                    prev    = float(s.iloc[-2]) if len(s)>1 else current
                    yoy     = float(s.iloc[-53]) if len(s)>52 else None
                    result[name] = {
                        "value":   round(current, 2),
                        "change":  round(current - prev, 3),
                        "yoy_chg": round(current - yoy, 2) if yoy else None,
                        "series":  s.tail(52),
                        "date":    s.index[-1].strftime("%b %Y"),
                    }
            except Exception:
                continue
    except Exception:
        pass
    return result

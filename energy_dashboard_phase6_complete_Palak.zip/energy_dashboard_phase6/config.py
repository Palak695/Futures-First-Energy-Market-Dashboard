import streamlit as st

def get_secret(key: str, default: str = "") -> str:
    try:
        return st.secrets["api_keys"][key]
    except Exception:
        return default

PRICE_TICKERS = {
    "Brent":    "BZ=F",
    "WTI":      "CL=F",
    "DXY":      "DX-Y.NYB",
    "VIX":      "^VIX",
    "Nat Gas":  "NG=F",
    "RBOB":     "RB=F",
    "Heat Oil": "HO=F",
}

CORRELATION_TICKERS = {
    "Brent":   "BZ=F",
    "WTI":     "CL=F",
    "Nat Gas": "NG=F",
    "DXY":     "DX-Y.NYB",
    "S&P 500": "^GSPC",
    "Gold":    "GC=F",
    "XLE":     "XLE",
}

EIA_BASE_URL = "https://api.eia.gov/v2"
EIA_SERIES = {
    "crude_inventory":      "PET.WCRSTUS1.W",
    "gasoline_inventory":   "PET.WGTSTUS1.W",
    "distillate_inventory": "PET.WDISTUS1.W",
    "spr":                  "PET.WCSSTUS1.W",
    "go_supplied":          "PET.WDIRPUS2.W",
    "rbob_supplied":        "PET.WRBUPUS2.W",
    "ho_supplied":          "PET.W_EPD2F_VPP_NUS_MBBLD.W",
    "crude_production":     "PET.WCRFPUS2.W",
    "refinery_util":        "PET.WPULEUS3.W",
}

FRED_SERIES = {
    "gdp":          "GDPC1",
    "cpi":          "CPIAUCSL",
    "fed_funds":    "FEDFUNDS",
    "yield_curve":  "T10Y2Y",
    "pmi":          "NAPM",
    "unemployment": "UNRATE",
}

CFTC_CODES = {
    "WTI": "067651", "Brent": "067375",
    "Nat Gas": "023651", "Heating Oil": "022651", "RBOB": "111659",
}

REFRESH = {
    "prices": 30, "news": 300, "futures_curve": 900,
    "inventory": 3600, "correlation": 3600, "cot": 86400, "tankers": 7200,
}

COLORS = {
    "brent": "#378ADD", "wti": "#EF9F27", "natgas": "#5DCAA5",
    "ho": "#D85A30", "rbob": "#7F77DD", "dxy": "#888780", "vix": "#E24B4A",
    "bullish": "#1D9E75", "bearish": "#E24B4A", "neutral": "#888780",
    "bg_dark": "#0e1117", "bg_card": "#161b27", "border": "#2d3748",
    "text_primary": "#e8e8e8", "text_secondary": "#a0aec0",
}

# NO margin in template — set per chart to avoid conflict
PLOTLY_TEMPLATE = {
    "layout": {
        "paper_bgcolor": "rgba(0,0,0,0)",
        "plot_bgcolor":  "rgba(0,0,0,0)",
        "font":  {"color": "#e8e8e8", "family": "Inter, sans-serif", "size": 12},
        "xaxis": {"gridcolor": "#2d3748", "linecolor": "#2d3748", "tickcolor": "#a0aec0"},
        "yaxis": {"gridcolor": "#2d3748", "linecolor": "#2d3748", "tickcolor": "#a0aec0"},
        "legend":    {"bgcolor": "rgba(0,0,0,0)", "bordercolor": "#2d3748"},
        "hoverlabel":{"bgcolor": "#1e2738", "bordercolor": "#378ADD", "font_color": "#e8e8e8"},
    }
}

TV_SYMBOLS = {
    "Brent":    "OANDA:BCOUSD",
    "WTI":      "OANDA:WTICOUSD",
    "Nat Gas":  "OANDA:NATGASUSD",
    "DXY":      "TVC:DXY",
    "RBOB":     "NYMEX:RB1!",
    "Heat Oil": "NYMEX:HO1!",
    "Gold":     "OANDA:XAUUSD",
    "S&P 500":  "OANDA:SPX500USD",
}

NEWS_CATEGORIES = {
    "supply":       ["production","opec","output","cut","quota","supply","inventory",
                     "stock","barrel","rig","drilling","saudi","iran","iraq","russia","libya"],
    "demand":       ["demand","consumption","import","china","india","refinery",
                     "throughput","gasoline","diesel","jet","transport","airline","iea"],
    "macro":        ["fed","federal reserve","rate","dollar","inflation","gdp",
                     "recession","ecb","bank","monetary","interest","cpi","pmi"],
    "geopolitical": ["war","sanction","conflict","attack","missile","strait","hormuz",
                     "suez","pipeline","tanker","seizure","tension","ukraine","israel","houthi"],
}

PARQUET_PATHS = {
    "lco_settle":  "data_files/lco_settle.parquet",
    "wtcl_spread": "data_files/wtcl_spread_daily.parquet",
    "lco_daily":   "data_files/lco_daily.parquet",
    "cl_daily":    "data_files/cl_daily.parquet",
    "ho_monthly":  "data_files/ho_monthly.parquet",
    "lgo_monthly": "data_files/lgo_monthly.parquet",
}

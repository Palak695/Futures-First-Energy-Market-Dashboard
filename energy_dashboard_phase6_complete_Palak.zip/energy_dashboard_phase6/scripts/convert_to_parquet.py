"""
scripts/convert_to_parquet.py
Drop CSV files into raw_data/ then run: python scripts/convert_to_parquet.py

Expected filenames:
    LCOSettle.csv               — Brent daily settlements c1-c31
    LCO_data.csv                — Brent 1-min (LCOc1..LCOc10 MID columns)
    CL_data.csv                 — WTI 1-min  (CL1..CL10 MID columns)
    CL_outrights_1min.csv       — WTI 1-min additional
    HO_data.csv                 — Heating Oil 1-min (HO1..HO10 MID columns)
    LGO_data.csv                — ICE Gasoil 1-min  (LGO1..LGO10 MID columns)
    wtcl_lco_outrights_1min.csv — WTI-Brent spread 1-min
"""

import pandas as pd
import numpy as np
import os, sys
from pathlib import Path

SCRIPT_DIR   = Path(__file__).resolve().parent
PROJECT_ROOT = SCRIPT_DIR.parent
RAW_DIR      = PROJECT_ROOT / "raw_data"
DISPLAY_DIR  = PROJECT_ROOT / "data_files"
MODELS_DIR   = PROJECT_ROOT / "models" / "weights"

CSV_FILES = {
    "lco_settle":    "LCOSettle.csv",
    "lco_1min":      "LCO_data.csv",
    "cl_1min":       "CL_data.csv",
    "cl_out_1min":   "CL_outrights_1min.csv",
    "ho_1min":       "HO_data.csv",
    "lgo_1min":      "LGO_data.csv",
    "wtcl_spread":   "wtcl_lco_outrights_1min.csv",
}


def setup():
    for d in [RAW_DIR, DISPLAY_DIR, MODELS_DIR]:
        d.mkdir(parents=True, exist_ok=True)
    print(f"✓ Project root : {PROJECT_ROOT}")
    print(f"✓ Reading from : {RAW_DIR}")
    print(f"✓ Writing to   : {DISPLAY_DIR}\n")


def check_available():
    available, missing = {}, []
    for key, fname in CSV_FILES.items():
        path = RAW_DIR / fname
        if path.exists():
            mb = path.stat().st_size / (1024*1024)
            available[key] = path
            print(f"  ✓ {fname} ({mb:.1f} MB)")
        else:
            missing.append(fname)
            print(f"  ✗ {fname}  ← not found")
    if missing:
        print(f"\n  Copy missing files into: {RAW_DIR}\n")
    return available


# ── Helpers ────────────────────────────────────────────────────────────────────
def _detect_ts_col(df):
    for col in df.columns:
        if any(k in col.lower() for k in ["timestamp","date","time"]):
            return col
    return df.columns[0]


def _detect_price_col(df, contract="c1"):
    """Find the MID or SETTLE column for a given contract label."""
    cands = [c for c in df.columns
             if (("mid" in c.lower() or "settle" in c.lower() or "weight" in c.lower()))
             and contract.lower() in c.lower()]
    if cands:
        # Prefer MID over WEIGHT
        mid = [c for c in cands if "mid" in c.lower()]
        return mid[0] if mid else cands[0]
    ts  = _detect_ts_col(df)
    num = [c for c in df.columns if c != ts and pd.api.types.is_numeric_dtype(df[c])]
    return num[0] if num else df.columns[1]


def _find_contract_cols(df, prefix, max_contracts=12):
    """
    Find MID price columns for c1..c{max_contracts}.
    Works for both 'LCOc1', 'CL1', 'HO1', 'LGO1' style naming.
    Returns list of (contract_num, col_name) tuples.
    """
    found = []
    for i in range(1, max_contracts + 1):
        # Try various naming conventions
        for pattern in [f"{prefix}c{i}", f"{prefix}{i}", f"c{i}", str(i)]:
            matches = [c for c in df.columns
                       if (pattern.lower() in c.lower()
                           and ("mid" in c.lower() or "settle" in c.lower()
                                or "weight" in c.lower()))
                       and c not in [m[1] for m in found]]
            if matches:
                mid = [c for c in matches if "mid" in c.lower()]
                col = mid[0] if mid else matches[0]
                found.append((i, col))
                break
    return found


def read_csv_smart(path, name):
    print(f"  Reading {name} ...")
    with open(path, "r", encoding="utf-8", errors="replace") as f:
        first = f.readline().strip()
    skip = 1 if first.startswith("#") else 0
    try:
        df = pd.read_csv(path, skiprows=skip, low_memory=False)
    except Exception as e:
        print(f"  ✗ Read failed: {e}"); return pd.DataFrame()
    ts = _detect_ts_col(df)
    if str(df[ts].iloc[0]).lower() in ("timestamp","date","period"):
        try:
            df = pd.read_csv(path, skiprows=skip+1, low_memory=False)
            ts = _detect_ts_col(df)
        except Exception:
            pass
    try:
        df[ts] = pd.to_datetime(df[ts], infer_datetime_format=True, utc=True, errors="coerce")
        df = df.rename(columns={ts: "timestamp"})
        df = (df.dropna(subset=["timestamp"])
                .sort_values("timestamp")
                .reset_index(drop=True))
    except Exception as e:
        print(f"  ✗ Timestamp parse failed: {e}"); return pd.DataFrame()
    for col in df.columns:
        if col != "timestamp":
            df[col] = pd.to_numeric(df[col], errors="ignore")
    print(f"  → {len(df):,} rows | "
          f"{df['timestamp'].iloc[0].date()} → {df['timestamp'].iloc[-1].date()}")
    return df


# ── LCOSettle ─────────────────────────────────────────────────────────────────
def convert_lco_settle(path):
    print("\n[1/7] LCOSettle — Brent daily settlements (c1–c31)")
    try:
        df = pd.read_csv(path, header=[0, 1], low_memory=False)
        df.columns = ["_".join(str(c).strip() for c in col).strip()
                      for col in df.columns]
        ts_cols     = [c for c in df.columns if "Timestamp" in c or "timestamp" in c.lower()]
        settle_cols = [c for c in df.columns if "SETTLE" in c.upper()]
        if not ts_cols:
            raise ValueError("No Timestamp column found")
        ts_col = ts_cols[0]
        df[ts_col] = pd.to_datetime(df[ts_col], dayfirst=True, errors="coerce")
        df = df.rename(columns={ts_col: "date"})
        df = df.dropna(subset=["date"]).sort_values("date").reset_index(drop=True)
        keep = ["date"] + settle_cols
        df   = df[keep].copy()
        rename_map = {}
        for i, col in enumerate(settle_cols, 1):
            rename_map[col] = f"LCOc{i}"
        df = df.rename(columns=rename_map)
        for col in df.columns:
            if col != "date":
                df[col] = pd.to_numeric(df[col], errors="coerce")
        out = DISPLAY_DIR / "lco_settle.parquet"
        df.to_parquet(out, index=False, compression="snappy")
        print(f"  ✓ {out.name} ({out.stat().st_size/1024:.0f} KB, "
              f"{len(df)} rows, {len(settle_cols)} contracts)")
    except Exception as e:
        print(f"  ✗ Dual-header parse failed: {e}, trying fallback...")
        _lco_settle_fallback(path)


def _lco_settle_fallback(path):
    for skip, hdr in [(1, 0), (0, 0), (2, 0)]:
        try:
            df = pd.read_csv(path, skiprows=skip, header=hdr, low_memory=False)
            ts_col = None
            for col in df.columns:
                if "timestamp" in str(col).lower() or "date" in str(col).lower():
                    sample = str(df[col].iloc[0])
                    if sample.lower() not in ("timestamp","date","nan"):
                        ts_col = col; break
            if ts_col is None: continue
            df[ts_col] = pd.to_datetime(df[ts_col], dayfirst=True, errors="coerce")
            df = df.dropna(subset=[ts_col]).rename(columns={ts_col:"date"})
            if df.empty: continue
            settle = [c for c in df.columns if c!="date" and "settle" in c.lower()]
            if not settle:
                settle = [c for c in df.columns if c!="date"
                          and pd.api.types.is_numeric_dtype(df[c])]
            for col in settle:
                df[col] = pd.to_numeric(df[col], errors="coerce")
            df = df[["date"]+settle].sort_values("date").reset_index(drop=True)
            out = DISPLAY_DIR / "lco_settle.parquet"
            df.to_parquet(out, index=False, compression="snappy")
            print(f"  ✓ Fallback (skip={skip}): {out.name} "
                  f"({out.stat().st_size/1024:.0f} KB, {len(df)} rows)")
            return
        except Exception:
            continue
    print("  ✗ All fallback attempts failed.")


# ── 1-min multi-contract converter ────────────────────────────────────────────
def convert_1min(path, name, prefix, idx):
    """
    Converts 1-min CSV to:
    - {prefix}_daily.parquet      — M1 OHLC daily
    - {prefix}_5min.parquet       — M1 OHLC 5-min
    - {prefix}_monthly.parquet    — M1 monthly
    - {prefix}_curve_daily.parquet— c1..c10 daily settle prices (TERM STRUCTURE)
    """
    print(f"\n[{idx}/7] {name}")
    df = read_csv_smart(path, name)
    if df.empty:
        return

    pc  = _detect_price_col(df, "c1") if "lco" in prefix.lower() else \
          _detect_price_col(df, f"{prefix.upper()}1" if prefix.upper() in ["CL","HO","LGO"] else "c1")
    vc  = next((c for c in df.columns
                if "volum" in c.lower() and
                ("c1" in c.lower() or f"{prefix}1".lower() in c.lower())), None)
    print(f"  M1 price col: {pc}")

    df_ts = df.set_index("timestamp")
    cols  = [pc] + ([vc] if vc else [])
    agg   = {pc: ["first","max","min","last"]}
    if vc: agg[vc] = "sum"

    # ── M1 OHLC aggregates ────────────────────────────────────────────────────
    for resample_freq, out_suffix in [("5min","5min"), ("1D","daily"), ("ME","monthly")]:
        try:
            dfa = df_ts[cols].resample(resample_freq).agg(agg)
            dfa.columns = ["open","high","low","close"] + (["volume"] if vc else [])
            dfa = dfa.dropna(subset=["close"]).reset_index()
            dfa["timestamp"] = dfa["timestamp"].dt.tz_convert(None)
            if resample_freq == "ME":
                dfa["year"]    = dfa["timestamp"].dt.year
                dfa["month"]   = dfa["timestamp"].dt.month
                dfa["quarter"] = dfa["timestamp"].dt.quarter
            out = DISPLAY_DIR / f"{prefix}_{out_suffix}.parquet"
            dfa.to_parquet(out, index=False, compression="snappy")
            print(f"  ✓ {out_suffix:8s}: {out.name} ({out.stat().st_size/1024:.0f} KB)")
        except Exception as e:
            print(f"  ✗ {out_suffix}: {e}")

    # ── Multi-contract term structure (c1..c10 daily settle) ──────────────────
    _extract_curve(df, df_ts, prefix, name)


def _extract_curve(df_raw, df_ts, prefix, name):
    """
    Extract c1..c10 daily closing prices → {prefix}_curve_daily.parquet
    This enables real term structure charts for WTI, HO, LGO.
    """
    # Determine naming convention from prefix
    contract_prefix_map = {
        "lco":    "LCO",
        "cl":     "CL",
        "cl_out": "CL",
        "ho":     "HO",
        "lgo":    "LGO",
    }
    cp = contract_prefix_map.get(prefix.lower(), prefix.upper())

    contract_cols_found = _find_contract_cols(df_raw, cp, max_contracts=12)

    if len(contract_cols_found) < 2:
        print(f"  ℹ Curve: found only {len(contract_cols_found)} contract(s) — skipping curve parquet")
        return

    print(f"  ✓ Curve: found {len(contract_cols_found)} contracts "
          f"({cp}c1..{cp}c{contract_cols_found[-1][0]})")

    # Resample each contract to daily close
    curve_data = {"timestamp": None}
    valid_contracts = []

    for cnum, col in contract_cols_found:
        try:
            daily = df_ts[[col]].resample("1D").last().dropna()
            daily.index = daily.index.tz_convert(None)
            if curve_data["timestamp"] is None:
                curve_data["timestamp"] = daily.index
            contract_label = f"{cp}c{cnum}"
            curve_data[contract_label] = daily[col].values[:len(curve_data["timestamp"])]
            valid_contracts.append(contract_label)
        except Exception:
            continue

    if len(valid_contracts) < 2:
        print(f"  ✗ Curve: insufficient valid contract columns")
        return

    # Align lengths
    min_len = min(len(v) for k, v in curve_data.items() if k != "timestamp")
    ts_arr  = curve_data["timestamp"][:min_len]

    curve_df = pd.DataFrame({"timestamp": ts_arr})
    for col in valid_contracts:
        arr = curve_data[col]
        curve_df[col] = arr[:min_len] if len(arr) >= min_len else np.nan

    # Convert to numeric
    for col in valid_contracts:
        curve_df[col] = pd.to_numeric(curve_df[col], errors="coerce")

    curve_df = curve_df.dropna(subset=valid_contracts[:1]).reset_index(drop=True)
    out = DISPLAY_DIR / f"{prefix}_curve_daily.parquet"
    curve_df.to_parquet(out, index=False, compression="snappy")
    print(f"  ✓ Curve:    {out.name} ({out.stat().st_size/1024:.0f} KB, "
          f"{len(curve_df)} rows, {len(valid_contracts)} contracts)")


# ── Spread ────────────────────────────────────────────────────────────────────
def convert_wtcl_spread(path):
    print("\n[7/7] WTI-Brent spread")
    df = read_csv_smart(path, "wtcl_spread")
    if df.empty: return
    pc    = _detect_price_col(df, "c1")
    df_ts = df.set_index("timestamp")
    dfd   = df_ts[[pc]].resample("1D").agg({pc: ["mean","max","min","last"]})
    dfd.columns = ["mean_spread","max_spread","min_spread","close_spread"]
    dfd   = dfd.dropna().reset_index().rename(columns={"timestamp":"date"})
    dfd["date"] = dfd["date"].dt.tz_convert(None)
    out   = DISPLAY_DIR / "wtcl_spread_daily.parquet"
    dfd.to_parquet(out, index=False, compression="snappy")
    print(f"  ✓ {out.name} ({out.stat().st_size/1024:.0f} KB)")


def merge_wti():
    a = DISPLAY_DIR / "cl_daily.parquet"
    b = DISPLAY_DIR / "cl_out_daily.parquet"
    if not a.exists() or not b.exists(): return
    print("\n[MERGE] CL_data + CL_outrights → cl_merged_daily.parquet")
    df_a = pd.read_parquet(a); df_b = pd.read_parquet(b)
    common = list(set(df_a.columns) & set(df_b.columns))
    merged = (pd.concat([df_a[common], df_b[common]], ignore_index=True)
                .sort_values("timestamp")
                .drop_duplicates(subset=["timestamp"], keep="last")
                .reset_index(drop=True))
    out = DISPLAY_DIR / "cl_merged_daily.parquet"
    merged.to_parquet(out, index=False, compression="snappy")
    print(f"  ✓ {out.name} ({out.stat().st_size/1024:.0f} KB, {len(merged):,} rows)")


def print_summary():
    print("\n" + "="*60)
    print("CONVERSION COMPLETE")
    print("="*60)
    print(f"\n📁 data_files/  (commit to GitHub)")
    total = 0
    for f in sorted(DISPLAY_DIR.glob("*.parquet")):
        sz = f.stat().st_size; total += sz
        tag = " ← CURVE" if "curve" in f.name else ""
        print(f"   {f.name:<48} {sz/1024:>6.0f} KB{tag}")
    print(f"\n   Total: {total/(1024*1024):.1f} MB")
    print("\nNext: streamlit run app.py")


if __name__ == "__main__":
    print("Energy Dashboard — CSV → Parquet Converter")
    print("="*60)
    setup()
    print("Scanning raw_data/ ...")
    available = check_available()
    if not available:
        print(f"\n⚠ No CSV files found in {RAW_DIR}")
        sys.exit(0)

    print(f"\nConverting {len(available)} file(s)...\n")

    if "lco_settle"  in available: convert_lco_settle(available["lco_settle"])
    if "lco_1min"    in available: convert_1min(available["lco_1min"],   "LCO_data",          "lco",    2)
    if "cl_1min"     in available: convert_1min(available["cl_1min"],    "CL_data",           "cl",     3)
    if "cl_out_1min" in available: convert_1min(available["cl_out_1min"],"CL_outrights_1min", "cl_out", 4)
    if "ho_1min"     in available: convert_1min(available["ho_1min"],    "HO_data",           "ho",     5)
    if "lgo_1min"    in available: convert_1min(available["lgo_1min"],   "LGO_data",          "lgo",    6)
    if "wtcl_spread" in available: convert_wtcl_spread(available["wtcl_spread"])
    merge_wti()
    print_summary()

"""
app.py — Energy Trading Dashboard Phase 6 (Complete)
All 6 phases integrated in one clean folder.
"""
import streamlit as st

st.set_page_config(
    page_title="Energy Trading Dashboard",
    page_icon="⚡", layout="wide",
    initial_sidebar_state="collapsed",
)

st.markdown("""
<style>
#MainMenu{visibility:hidden;}footer{visibility:hidden;}header{visibility:hidden;}
::-webkit-scrollbar{width:5px;height:5px;}
::-webkit-scrollbar-track{background:#0e1117;}
::-webkit-scrollbar-thumb{background:#2d3748;border-radius:3px;}
.stTabs [data-baseweb="tab-list"]{gap:4px;background:transparent;
  border-bottom:1px solid #2d3748;}
.stTabs [data-baseweb="tab"]{font-size:14px;font-weight:500;padding:7px 18px;
  border-radius:6px 6px 0 0;color:#a0aec0;background:transparent;
  border:none;border-bottom:2px solid transparent;}
.stTabs [aria-selected="true"]{color:#378ADD;background:rgba(55,138,221,0.08);
  border-bottom:2px solid #378ADD;}
[data-testid="metric-container"]{background:#1a2035;border:.5px solid #2d3748;
  border-radius:8px;padding:12px;}
[data-testid="stMetricValue"]{font-size:20px !important;color:#e8e8e8;}
[data-testid="stMetricLabel"]{font-size:12px !important;color:#a0aec0;}
[data-testid="stSidebar"]{background:#0d1120;border-right:.5px solid #2d3748;}
.block-container{padding-top:1rem !important;padding-bottom:0 !important;}
.element-container{margin-bottom:5px !important;}
hr{border-color:#2d3748;margin:10px 0;}
.stExpander{background:#1a2035 !important;border:.5px solid #2d3748 !important;
  border-radius:8px !important;}
.streamlit-expanderHeader{font-size:13px !important;}
p,span,label{font-size:13px;}
</style>""", unsafe_allow_html=True)

# ── Startup ────────────────────────────────────────────────────────────────────
try:
    from analytics.sentiment import ensure_finbert_loading
    ensure_finbert_loading()
except Exception:
    pass

try:
    from scheduler.jobs import start_scheduler
    start_scheduler()
except Exception:
    pass

from data.local_data import dataset_status
from tabs.tab1_overview import render_tab1
from tabs.tab1b_seasonality import render_seasonality_tab
from tabs.tab1c_fundamentals import render_fundamentals_tab
from tabs.tab2_logistics import render_tab2
from tabs.tab3_macro import render_tab3
from tabs.tab4_risk import render_tab4


def render_sidebar():
    with st.sidebar:
        st.markdown("### Dataset status")
        for name, loaded in dataset_status().items():
            st.markdown(f"{'🟢' if loaded else '⚪'} {name.replace('_',' ').title()}")
        st.divider()
        st.markdown("### Quick links")
        st.markdown("""
- [EIA Weekly](https://www.eia.gov/petroleum/supply/weekly/)
- [CFTC COT](https://www.cftc.gov/MarketReports/CommitmentsofTraders/)
- [OPEC Report](https://www.opec.org/opec_web/en/publications/338.htm)
- [Financial Juice](https://www.financialjuice.com/)
- [ForexFactory](https://www.forexfactory.com/calendar)""")
        st.divider()
        st.markdown("### Phases complete")
        for ph, desc, done in [
            ("Phase 1","Live prices + charts",True),
            ("Phase 2","FinBERT + events calendar",True),
            ("Phase 3","XGBoost + HMM + alerts",True),
            ("Phase 4","Futures curve + cracks + tankers",True),
            ("Phase 5","GARCH + fair value + options",True),
            ("Phase 6","Monte Carlo + Geo risk + macro factors",True),
        ]:
            st.markdown(f"{'✅' if done else '🔲'} **{ph}** — {desc}")
        st.divider()
        st.caption("v6.0 Complete · All phases integrated")
        st.caption("AI: FinBERT · XGBoost · HMM · GARCH")


def main():
    render_sidebar()

    c1, c2 = st.columns([4, 1])
    with c1:
        st.markdown("""
<span style="font-size:22px;font-weight:700;color:#e8e8e8;">
  ⚡ Energy Trading Dashboard
</span>
<span style="font-size:12px;color:#666;margin-left:12px;">
  Complete · Phases 1–6 · Brent · WTI · NatGas · HO · LGO
</span>""", unsafe_allow_html=True)
    with c2:
        statuses = dataset_status()
        loaded   = sum(statuses.values())
        total    = len(statuses)
        color    = "#1D9E75" if loaded==total else "#EF9F27" if loaded>0 else "#888780"
        st.markdown(
            f'<div style="text-align:right;font-size:12px;color:{color};padding-top:8px;">'
            f'Datasets: {loaded}/{total} loaded</div>',
            unsafe_allow_html=True)

    st.divider()

    tab1, tab2, tab3, tab4 = st.tabs([
        "📈 Market Overview",
        "🚢 Logistics & Spreads",
        "🌍 Macro & AI Engine",
        "⚖️ Positioning & Risk",
    ])

    with tab1:
        sub1, sub2, sub3 = st.tabs(["Overview", "📅 Seasonality", "📐 Fundamentals"])
        with sub1:  render_tab1()
        with sub2:  render_seasonality_tab()
        with sub3:  render_fundamentals_tab()
    with tab2:  render_tab2()
    with tab3:  render_tab3()
    with tab4:  render_tab4()


if __name__ == "__main__":
    main()

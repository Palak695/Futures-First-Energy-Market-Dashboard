"""
scheduler/jobs.py
APScheduler background jobs — price refresh, news scoring, EIA timing.
Uses BackgroundScheduler so jobs run without blocking Streamlit UI.
"""

import streamlit as st
import threading
import logging
from datetime import datetime

logger = logging.getLogger(__name__)

_scheduler = None
_lock = threading.Lock()


def get_scheduler():
    """Return singleton APScheduler instance."""
    global _scheduler
    if _scheduler is not None:
        return _scheduler
    with _lock:
        if _scheduler is not None:
            return _scheduler
        try:
            from apscheduler.schedulers.background import BackgroundScheduler
            from apscheduler.executors.pool import ThreadPoolExecutor
            executors = {"default": ThreadPoolExecutor(max_workers=3)}
            _scheduler = BackgroundScheduler(executors=executors, timezone="UTC")
            return _scheduler
        except Exception as e:
            logger.warning(f"APScheduler unavailable: {e}")
            return None


def _clear_price_cache():
    """Clear yFinance price cache so fragment refreshes get fresh data."""
    try:
        from data.prices import fetch_prices, fetch_ohlcv
        fetch_prices.clear()
    except Exception:
        pass


def _clear_news_cache():
    try:
        from data.news import fetch_news
        fetch_news.clear()
    except Exception:
        pass


def _clear_eia_cache():
    try:
        from data.eia import fetch_inventory_data, fetch_seasonality_data
        fetch_inventory_data.clear()
        fetch_seasonality_data.clear()
    except Exception:
        pass


def _clear_calendar_cache():
    try:
        from data.calendar import get_upcoming_events, fetch_forexfactory_events
        get_upcoming_events.clear()
        fetch_forexfactory_events.clear()
    except Exception:
        pass


@st.cache_resource(show_spinner=False)
def start_scheduler():
    """
    Start APScheduler with all background jobs.
    Called once at app startup via st.cache_resource.
    """
    sched = get_scheduler()
    if sched is None:
        return None

    try:
        if not sched.running:
            # Price cache clear every 28s (slightly before st.fragment 30s refresh)
            sched.add_job(_clear_price_cache, "interval", seconds=28,
                          id="price_refresh", replace_existing=True)

            # News cache clear every 4.5 min
            sched.add_job(_clear_news_cache, "interval", seconds=270,
                          id="news_refresh", replace_existing=True)

            # EIA cache — every Wed at 10:35 ET (after 10:30 release)
            sched.add_job(_clear_eia_cache, "cron",
                          day_of_week="wed", hour=15, minute=35,
                          id="eia_weekly", replace_existing=True)

            # Calendar refresh — every 30 min
            sched.add_job(_clear_calendar_cache, "interval", minutes=30,
                          id="calendar_refresh", replace_existing=True)

            sched.start()
            logger.info("APScheduler started with all jobs")

    except Exception as e:
        logger.warning(f"Scheduler start error: {e}")

    return sched

"""analytics/technicals.py — Technical indicators, FutureWarning fixed"""
import pandas as pd
import numpy as np
import streamlit as st

try:
    import pandas_ta as ta
    HAS_TA = True
except Exception:
    HAS_TA = False

from data.prices import fetch_ohlcv

INDICATOR_TICKERS = {
    "Brent":    "BZ=F",
    "WTI":      "CL=F",
    "Nat Gas":  "NG=F",
    "RBOB":     "RB=F",
    "Heat Oil": "HO=F",
    "Gasoil":   "HO=F",
}


@st.cache_data(ttl=60, show_spinner=False)
def compute_indicators(ticker: str, period: str = "1y") -> dict:
    df = fetch_ohlcv(ticker, period=period, interval="1d")
    if df.empty or len(df) < 20:
        return _empty()
    df = df.copy()
    for col in ["Open","High","Low","Close","Volume"]:
        if col in df.columns:
            df[col] = pd.to_numeric(df[col], errors="coerce")
    df = df.dropna(subset=["Close"])
    res = {}

    if HAS_TA:
        try:
            rsi = ta.rsi(df["Close"], length=14)
            res["rsi"] = round(float(rsi.iloc[-1]), 2) if rsi is not None and len(rsi) else None
        except Exception: res["rsi"] = None

        try:
            md = ta.macd(df["Close"], fast=12, slow=26, signal=9)
            if md is not None and not md.empty:
                c = md.columns.tolist()
                res["macd"]      = round(float(md[c[0]].iloc[-1]), 4)
                res["macd_sig"]  = round(float(md[c[1]].iloc[-1]), 4)
                res["macd_hist"] = round(float(md[c[2]].iloc[-1]), 4)
                res["macd_cross"]= "bullish" if res["macd"] > res["macd_sig"] else "bearish"
            else: res.update({"macd":None,"macd_sig":None,"macd_hist":None,"macd_cross":None})
        except Exception: res.update({"macd":None,"macd_sig":None,"macd_hist":None,"macd_cross":None})

        try:
            bb = ta.bbands(df["Close"], length=20, std=2)
            if bb is not None and not bb.empty:
                c = bb.columns.tolist()
                bu,bm,bl = float(bb[c[0]].iloc[-1]),float(bb[c[1]].iloc[-1]),float(bb[c[2]].iloc[-1])
                px = float(df["Close"].iloc[-1])
                bw = bu - bl
                bp = (px - bl)/bw*100 if bw > 0 else 50
                res.update({"bb_upper":round(bu,4),"bb_mid":round(bm,4),"bb_lower":round(bl,4),
                            "bb_pct":round(bp,2),
                            "bb_signal":"overbought" if px>bu else "oversold" if px<bl else "inside"})
            else: res.update({"bb_upper":None,"bb_mid":None,"bb_lower":None,"bb_pct":None,"bb_signal":None})
        except Exception: res.update({"bb_upper":None,"bb_mid":None,"bb_lower":None,"bb_pct":None,"bb_signal":None})

        try:
            atr = ta.atr(df["High"], df["Low"], df["Close"], length=14)
            res["atr"] = round(float(atr.iloc[-1]), 4) if atr is not None and len(atr) else None
            px = float(df["Close"].iloc[-1])
            res["atr_pct"] = round(res["atr"]/px*100, 3) if res["atr"] and px else None
        except Exception: res["atr"] = res["atr_pct"] = None

        for n in [20, 50, 200]:
            try:
                ema = ta.ema(df["Close"], length=n)
                v = float(ema.iloc[-1]) if ema is not None and len(ema) and not pd.isna(ema.iloc[-1]) else None
                res[f"ema{n}"] = round(v, 4) if v else None
            except Exception: res[f"ema{n}"] = None

        try:
            if "Volume" in df.columns and df["Volume"].sum() > 0:
                vwap = ta.vwap(df["High"], df["Low"], df["Close"], df["Volume"])
                if vwap is not None and len(vwap):
                    res["vwap"] = round(float(vwap.iloc[-1]), 4)
                    px = float(df["Close"].iloc[-1])
                    res["vwap_dev_pct"] = round((px - res["vwap"])/res["vwap"]*100, 3)
                else: res["vwap"] = res["vwap_dev_pct"] = None
            else: res["vwap"] = res["vwap_dev_pct"] = None
        except Exception: res["vwap"] = res["vwap_dev_pct"] = None
    else:
        close = df["Close"]
        delta = close.diff()
        gain  = delta.clip(lower=0).rolling(14).mean()
        loss  = (-delta.clip(upper=0)).rolling(14).mean()
        rs    = gain / loss.replace(0, np.nan)
        rsi_s = 100 - 100/(1+rs)
        res["rsi"] = round(float(rsi_s.iloc[-1]), 2) if not pd.isna(rsi_s.iloc[-1]) else None
        res.update({"macd":None,"macd_sig":None,"macd_hist":None,"macd_cross":None,
                    "bb_upper":None,"bb_mid":None,"bb_lower":None,"bb_pct":None,"bb_signal":None,
                    "atr":None,"atr_pct":None,"ema20":None,"ema50":None,"ema200":None,
                    "vwap":None,"vwap_dev_pct":None})

    px = float(df["Close"].iloc[-1])
    e20,e50,e200 = res.get("ema20"),res.get("ema50"),res.get("ema200")
    if e20 and e50 and e200:
        if px>e20>e50>e200:   res["trend"]="strong_up"
        elif px>e20>e50:      res["trend"]="up"
        elif px<e20<e50<e200: res["trend"]="strong_down"
        elif px<e20<e50:      res["trend"]="down"
        else:                 res["trend"]="sideways"
    else: res["trend"]="sideways"

    bull = sum([
        bool(res.get("rsi") is not None and res["rsi"] < 45),
        bool(res.get("macd_cross") == "bullish"),
        bool(res.get("bb_signal") == "oversold"),
        bool(res.get("trend") in ["up","strong_up"]),
    ])
    bear = sum([
        bool(res.get("rsi") is not None and res["rsi"] > 55),
        bool(res.get("macd_cross") == "bearish"),
        bool(res.get("bb_signal") == "overbought"),
        bool(res.get("trend") in ["down","strong_down"]),
    ])
    if bull > bear:   res["bias"],res["bias_strength"] = "BULLISH", round(bull/4*100)
    elif bear > bull: res["bias"],res["bias_strength"] = "BEARISH", round(bear/4*100)
    else:             res["bias"],res["bias_strength"] = "NEUTRAL", 50

    res["df"]         = df
    res["rsi_signal"] = ("overbought" if res.get("rsi") and res["rsi"]>70 else
                         "oversold"   if res.get("rsi") and res["rsi"]<30 else "neutral")
    return res


def _empty():
    return {"rsi":None,"rsi_signal":None,"macd":None,"macd_sig":None,"macd_hist":None,
            "macd_cross":None,"bb_upper":None,"bb_mid":None,"bb_lower":None,
            "bb_pct":None,"bb_signal":None,"atr":None,"atr_pct":None,
            "ema20":None,"ema50":None,"ema200":None,"vwap":None,"vwap_dev_pct":None,
            "trend":"sideways","bias":"NEUTRAL","bias_strength":50,"df":pd.DataFrame()}


@st.cache_data(ttl=60, show_spinner=False)
def compute_correlation_matrix(df_closes: pd.DataFrame, window: int = 60) -> pd.DataFrame:
    if df_closes.empty or len(df_closes) < window:
        return pd.DataFrame()
    # Fix FutureWarning: fill_method=None
    returns = df_closes.pct_change(fill_method=None).dropna()
    return returns.tail(window).corr().round(3)


# Public alias for external use (alerts.py, bias.py)
def rsi(series, period=14):
    return _rsi(series, period)

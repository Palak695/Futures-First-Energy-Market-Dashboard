"""
analytics/fair_value.py — Phase 5 fixed
Uses weekly resampled data + forward-fill to avoid dropna wiping too many rows.
"""
import numpy as np
import pandas as pd
import streamlit as st
import yfinance as yf
from data.prices import fetch_ohlcv
from config import COLORS


def _strip_tz(s):
    """Strip timezone from Series or DatetimeIndex."""
    try:
        if hasattr(s.index, 'tz') and s.index.tz:
            s = s.copy()
            s.index = s.index.tz_convert(None)
        return s
    except Exception:
        return s


@st.cache_data(ttl=3600, show_spinner=False)
def compute_fair_value(ticker: str = "BZ=F") -> dict:
    """
    Fair value via Ridge regression of log(price) on DXY, VIX, S&P500, NatGas.
    Uses weekly frequency + forward-fill to maximise aligned rows.
    """
    from sklearn.linear_model import Ridge
    from sklearn.preprocessing import StandardScaler

    # ── Fetch price (target) ──────────────────────────────────────────────────
    df_price = fetch_ohlcv(ticker, period="3y", interval="1d")
    if df_price.empty or len(df_price) < 30:
        return _empty()

    price = df_price["Close"].copy()
    price = _strip_tz(price)

    # ── Fetch factors ─────────────────────────────────────────────────────────
    factor_tickers = {
        "DXY":    "DX-Y.NYB",
        "VIX":    "^VIX",
        "S&P500": "^GSPC",
        "NatGas": "NG=F",
    }
    factor_series = {"price": price}
    for name, fticker in factor_tickers.items():
        try:
            s = yf.Ticker(fticker).history(period="3y", auto_adjust=True)["Close"]
            s = _strip_tz(s)
            if not s.empty:
                factor_series[name] = s
        except Exception:
            pass

    if len(factor_series) < 3:   # need at least price + 2 factors
        return _empty()

    # ── Align on WEEKLY frequency with forward-fill ───────────────────────────
    df = pd.DataFrame(factor_series)
    # Resample to weekly (Friday close)
    df = df.resample("W-FRI").last()
    # Forward-fill up to 5 business days to bridge gaps (weekends, holidays)
    df = df.ffill(limit=2).dropna()

    if len(df) < 30:
        return _empty()

    # ── Model ─────────────────────────────────────────────────────────────────
    available_factors = [c for c in df.columns if c != "price"]
    X = df[available_factors].values
    y = np.log(df["price"].values)

    split  = int(len(df) * 0.8)
    scaler = StandardScaler()
    X_s    = scaler.fit_transform(X)
    model  = Ridge(alpha=1.0)
    model.fit(X_s[:split], y[:split])

    y_pred  = np.exp(model.predict(X_s))
    current = float(df["price"].iloc[-1])
    fair    = round(float(y_pred[-1]), 2)
    premium = round(current - fair, 2)
    prem_pct= round(premium / fair * 100, 2) if fair != 0 else 0

    # Factor contributions
    contributions = {}
    for i, fname in enumerate(available_factors):
        val  = float(df[fname].iloc[-1])
        mean = float(scaler.mean_[i])
        std  = float(scaler.scale_[i])
        if std == 0: continue
        contrib = model.coef_[i] * (val - mean) / std
        contributions[fname] = round(float(np.exp(contrib) - 1) * fair, 2)

    rmse = round(float(np.std(df["price"].values - y_pred)), 2)

    hist = pd.DataFrame({
        "date":       df.index,
        "actual":     df["price"].values,
        "fair_value": y_pred,
    }).reset_index(drop=True)

    return {
        "fair_value":    fair,
        "current":       current,
        "premium":       premium,
        "premium_pct":   prem_pct,
        "contributions": contributions,
        "band":          rmse,
        "history":       hist,
        "model":         f"Ridge regression (weekly, {len(df)} obs, {len(available_factors)} factors)",
        "status":        "ok",
    }


def _empty():
    return {"fair_value":None,"current":None,"premium":None,"premium_pct":None,
            "contributions":{},"band":None,"history":pd.DataFrame(),
            "model":"unavailable","status":"error"}

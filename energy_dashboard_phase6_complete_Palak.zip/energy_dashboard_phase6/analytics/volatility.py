"""
analytics/volatility.py — Phase 5
GARCH(1,1) volatility forecast + realized vol from OHLCV + vol regime classification.
Trained on daily yFinance data — no 1-min parquet needed for basic operation.
Uses 1-min parquet if available for higher-quality GARCH calibration.
"""
import numpy as np
import pandas as pd
import streamlit as st
from data.prices import fetch_ohlcv
from config import COLORS


def _safe_returns(df: pd.DataFrame) -> pd.Series:
    """Compute log returns, stripping tz, filling NaN."""
    close = df["Close"].copy()
    close.index = pd.to_datetime(close.index).tz_localize(None) \
                  if close.index.tz is None \
                  else pd.to_datetime(close.index).tz_convert(None)
    rets = np.log(close / close.shift(1)).dropna()
    return rets


@st.cache_data(ttl=3600, show_spinner=False)
def compute_realized_vol(ticker: str, windows: list = None) -> pd.DataFrame:
    """
    Compute annualised realized vol over multiple rolling windows.
    Returns DataFrame with columns: date, close, ret, vol_Nd for each window.
    """
    if windows is None:
        windows = [10, 20, 60]

    df = fetch_ohlcv(ticker, period="2y", interval="1d")
    if df.empty or len(df) < 30:
        return pd.DataFrame()

    rets = _safe_returns(df)
    result = pd.DataFrame({
        "date":  rets.index,
        "ret":   rets.values,
        "close": df["Close"].loc[rets.index].values,
    })

    for w in windows:
        result[f"vol_{w}d"] = (
            pd.Series(rets.values).rolling(w).std() * np.sqrt(252) * 100
        ).values

    return result.dropna(subset=[f"vol_{windows[0]}d"]).reset_index(drop=True)


@st.cache_resource(show_spinner=False)
def fit_garch(ticker: str = "BZ=F") -> dict:
    """
    Fit GARCH(1,1) model and return vol forecast.
    Uses arch library. Falls back to historical vol if arch unavailable.
    """
    df = fetch_ohlcv(ticker, period="5y", interval="1d")
    if df.empty or len(df) < 100:
        return {"forecast_1d": None, "forecast_5d": None, "model": "unavailable"}

    rets = _safe_returns(df) * 100  # percent returns for GARCH

    try:
        from arch import arch_model
        am = arch_model(rets, vol="Garch", p=1, q=1, dist="Normal",
                        rescale=False)
        res  = am.fit(disp="off", show_warning=False)
        fore = res.forecast(horizon=5, reindex=False)
        var_1d = float(fore.variance.iloc[-1, 0])
        var_5d = float(fore.variance.iloc[-1, 4])
        vol_1d = round(np.sqrt(var_1d * 252), 2)
        vol_5d = round(np.sqrt(var_5d * 252), 2)
        cond_vol = np.sqrt(res.conditional_volatility * 252)
        return {
            "forecast_1d":    vol_1d,
            "forecast_5d":    vol_5d,
            "conditional_vol": pd.Series(cond_vol.values, index=rets.index),
            "params": {
                "omega": round(float(res.params.get("omega", 0)), 6),
                "alpha": round(float(res.params.get("alpha[1]", 0)), 4),
                "beta":  round(float(res.params.get("beta[1]", 0)), 4),
            },
            "model": "GARCH(1,1)",
        }
    except Exception:
        # Fallback: simple historical vol
        vol = float(rets.std() * np.sqrt(252))
        return {
            "forecast_1d":    round(vol, 2),
            "forecast_5d":    round(vol, 2),
            "conditional_vol": pd.Series(dtype=float),
            "params":         {},
            "model":          "historical_vol_fallback",
        }


@st.cache_data(ttl=1800, show_spinner=False)
def get_vol_regime(ticker: str = "BZ=F") -> dict:
    """
    Classify current vol regime: LOW / NORMAL / HIGH / EXTREME.
    Based on current 20d vol vs 2yr percentile distribution.
    """
    df = fetch_ohlcv(ticker, period="2y", interval="1d")
    if df.empty:
        return {"regime":"UNKNOWN","color":COLORS["neutral"],"vol_pct":50,"current_vol":None}

    rets    = _safe_returns(df)
    vol_20d = rets.rolling(20).std() * np.sqrt(252) * 100
    vol_20d = vol_20d.dropna()
    if vol_20d.empty:
        return {"regime":"UNKNOWN","color":COLORS["neutral"],"vol_pct":50,"current_vol":None}

    current = float(vol_20d.iloc[-1])
    pct     = float((vol_20d <= current).mean() * 100)

    if pct >= 90:
        regime, color = "EXTREME",  COLORS["bearish"]
    elif pct >= 70:
        regime, color = "HIGH",     "#EF9F27"
    elif pct <= 20:
        regime, color = "LOW",      COLORS["bullish"]
    else:
        regime, color = "NORMAL",   COLORS["neutral"]

    return {
        "regime":      regime,
        "color":       color,
        "vol_pct":     round(pct, 1),
        "current_vol": round(current, 2),
        "vol_series":  vol_20d,
        "vol_mean":    round(float(vol_20d.mean()), 2),
        "vol_p25":     round(float(vol_20d.quantile(0.25)), 2),
        "vol_p75":     round(float(vol_20d.quantile(0.75)), 2),
    }

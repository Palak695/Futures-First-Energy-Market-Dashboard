"""
analytics/bias.py — Phase 4: XGBoost + HMM with joblib weight caching
Models persist to disk after first train — zero cold-start penalty on restart.
"""
import numpy as np
import pandas as pd
import os
import streamlit as st
from datetime import datetime, timedelta
from data.prices import fetch_ohlcv
from analytics.technicals import compute_indicators
from config import COLORS

WEIGHTS_DIR = "models/weights"
os.makedirs(WEIGHTS_DIR, exist_ok=True)
XGB_PATH = os.path.join(WEIGHTS_DIR, "xgb_signal.joblib")
HMM_PATH = os.path.join(WEIGHTS_DIR, "hmm_regime.joblib")
CACHE_HOURS = 24  # retrain if weights older than this


def _weights_fresh(path: str, max_hours: int = CACHE_HOURS) -> bool:
    if not os.path.exists(path):
        return False
    age = datetime.now() - datetime.fromtimestamp(os.path.getmtime(path))
    return age < timedelta(hours=max_hours)


def _build_features(df: pd.DataFrame) -> pd.DataFrame:
    f = pd.DataFrame(index=df.index)
    c = df["Close"]
    f["ret_1d"]  = c.pct_change(fill_method=None)
    f["ret_5d"]  = c.pct_change(5, fill_method=None)
    f["ret_20d"] = c.pct_change(20, fill_method=None)
    f["rsi_14"]  = _rsi_series(c, 14)
    f["rsi_7"]   = _rsi_series(c, 7)
    f["ema20"]   = c.ewm(span=20).mean()
    f["ema50"]   = c.ewm(span=50).mean()
    f["ema_cross"]       = (f["ema20"] / f["ema50"] - 1)
    f["price_vs_ema50"]  = (c / f["ema50"] - 1)
    h, l = df.get("High", c), df.get("Low", c)
    tr   = pd.concat([h-l, (h-c.shift()).abs(), (l-c.shift()).abs()], axis=1).max(axis=1)
    f["atr_14"]   = tr.rolling(14).mean()
    f["vol_20"]   = f["ret_1d"].rolling(20).std()
    f["vol_ratio"]= f["vol_20"] / f["ret_1d"].rolling(60).std().replace(0, np.nan)
    sma20 = c.rolling(20).mean()
    std20 = c.rolling(20).std()
    f["bb_pct"]   = (c - (sma20 - 2*std20)) / (4*std20.replace(0, np.nan))
    ema12 = c.ewm(span=12).mean()
    ema26 = c.ewm(span=26).mean()
    macd  = ema12 - ema26
    sig   = macd.ewm(span=9).mean()
    f["macd_hist"]   = (macd - sig) / c.replace(0, np.nan)
    f["macd_signal"] = np.sign(macd - sig)
    if "Volume" in df.columns and df["Volume"].sum() > 0:
        f["vol_spike"] = df["Volume"] / df["Volume"].rolling(20).mean().replace(0, np.nan)
    else:
        f["vol_spike"] = 1.0
    f["target"] = (c.pct_change(fill_method=None).shift(-1) > 0).astype(int)
    return f.dropna()


def _rsi_series(series, period=14):
    delta = series.diff()
    gain  = delta.clip(lower=0).rolling(period).mean()
    loss  = (-delta.clip(upper=0)).rolling(period).mean()
    rs    = gain / loss.replace(0, np.nan)
    return 100 - (100 / (1 + rs))


# ── XGBoost ───────────────────────────────────────────────────────────────────
@st.cache_resource(show_spinner=False)
def _get_xgboost(ticker: str = "BZ=F"):
    import joblib
    # Load from disk if fresh
    if _weights_fresh(XGB_PATH):
        try:
            return joblib.load(XGB_PATH)
        except Exception:
            pass
    # Train fresh
    try:
        import xgboost as xgb
        from sklearn.preprocessing import StandardScaler
        df = fetch_ohlcv(ticker, period="2y", interval="1d")
        if df.empty or len(df) < 100:
            return None
        feats       = _build_features(df)
        feat_cols   = [c for c in feats.columns if c != "target"]
        X, y        = feats[feat_cols].values, feats["target"].values
        split       = int(len(X) * 0.8)
        scaler      = StandardScaler()
        X_train_s   = scaler.fit_transform(X[:split])
        model = xgb.XGBClassifier(
            n_estimators=150, max_depth=4, learning_rate=0.05,
            subsample=0.8, colsample_bytree=0.8,
            use_label_encoder=False, eval_metric="logloss",
            random_state=42, verbosity=0,
        )
        model.fit(X_train_s, y[:split])
        bundle = {"model": model, "scaler": scaler, "feat_cols": feat_cols}
        joblib.dump(bundle, XGB_PATH)
        return bundle
    except Exception:
        return None


def get_xgboost_signal(ticker: str = "BZ=F") -> dict:
    bundle = _get_xgboost(ticker)
    if bundle is None:
        return {"signal":"NEUTRAL","prob_bull":0.5,"confidence":0.0,
                "top_features":[],"model":"unavailable"}
    try:
        df     = fetch_ohlcv(ticker, period="2y", interval="1d")
        feats  = _build_features(df)
        X_live = feats[bundle["feat_cols"]].iloc[-1:].values
        X_s    = bundle["scaler"].transform(X_live)
        prob   = float(bundle["model"].predict_proba(X_s)[0][1])
        signal = "BULLISH" if prob > 0.55 else "BEARISH" if prob < 0.45 else "NEUTRAL"
        imps   = dict(zip(bundle["feat_cols"], bundle["model"].feature_importances_))
        top    = sorted(imps.items(), key=lambda x: x[1], reverse=True)[:5]
        return {"signal":signal,"prob_bull":round(prob,3),
                "confidence":round(abs(prob-0.5)*2,3),"top_features":top,"model":"xgboost"}
    except Exception:
        return {"signal":"NEUTRAL","prob_bull":0.5,"confidence":0.0,
                "top_features":[],"model":"error"}


# ── HMM ───────────────────────────────────────────────────────────────────────
@st.cache_resource(show_spinner=False)
def _get_hmm(ticker: str = "BZ=F"):
    import joblib
    if _weights_fresh(HMM_PATH):
        try:
            return joblib.load(HMM_PATH)
        except Exception:
            pass
    try:
        from hmmlearn import hmm
        df   = fetch_ohlcv(ticker, period="5y", interval="1d")
        if df.empty or len(df) < 200:
            return None
        rets = df["Close"].pct_change(fill_method=None).dropna()
        vol  = rets.rolling(10).std().dropna()
        rets = rets.loc[vol.index]
        X    = np.column_stack([rets.values, vol.values])
        model= hmm.GaussianHMM(n_components=3, covariance_type="full",
                                n_iter=100, random_state=42)
        model.fit(X)
        means     = model.means_[:, 0]
        labels    = np.argsort(means)
        state_map = {labels[0]:"BEARISH", labels[1]:"NEUTRAL", labels[2]:"BULLISH"}
        bundle    = {"model":model, "state_map":state_map}
        joblib.dump(bundle, HMM_PATH)
        return bundle
    except Exception:
        return None


def get_hmm_regime(ticker: str = "BZ=F") -> dict:
    bundle = _get_hmm(ticker)
    if bundle is None:
        return {"regime":"UNKNOWN","regime_color":COLORS["neutral"],
                "state_probs":{},"history":pd.Series(dtype=str)}
    try:
        model, state_map = bundle["model"], bundle["state_map"]
        df   = fetch_ohlcv(ticker, period="5y", interval="1d")
        rets = df["Close"].pct_change(fill_method=None).dropna()
        vol  = rets.rolling(10).std().dropna()
        rets = rets.loc[vol.index]
        X    = np.column_stack([rets.values, vol.values])
        hidden  = model.predict(X)
        probs   = model.predict_proba(X)
        cur_s   = int(hidden[-1])
        regime  = state_map.get(cur_s, "NEUTRAL")
        sp      = {state_map.get(i,"?"): round(float(probs[-1][i]),3) for i in range(3)}
        history = pd.Series([state_map.get(int(s),"NEUTRAL") for s in hidden],
                            index=vol.index)
        cmap    = {"BULLISH":COLORS["bullish"],"BEARISH":COLORS["bearish"],
                   "NEUTRAL":COLORS["neutral"]}
        return {"regime":regime,"regime_color":cmap.get(regime,COLORS["neutral"]),
                "state_probs":sp,"history":history}
    except Exception:
        return {"regime":"UNKNOWN","regime_color":COLORS["neutral"],
                "state_probs":{},"history":pd.Series(dtype=str)}


@st.cache_data(ttl=300, show_spinner=False)
def get_ensemble_bias(ticker: str = "BZ=F", sentiment_score: float = 0.0) -> dict:
    tech  = compute_indicators(ticker)
    xgb_s = get_xgboost_signal(ticker)
    hmm_r = get_hmm_regime(ticker)
    signals = []
    signals.append(("XGBoost",       xgb_s["prob_bull"],  0.35))
    regime  = hmm_r.get("regime","NEUTRAL")
    hmm_b   = 0.7 if regime=="BULLISH" else 0.3 if regime=="BEARISH" else 0.5
    signals.append(("HMM Regime",    hmm_b,               0.25))
    ts = 0.5
    if tech:
        bull = sum([bool(tech.get("rsi") and tech["rsi"]<45),
                    bool(tech.get("macd_cross")=="bullish"),
                    bool(tech.get("bb_signal")=="oversold"),
                    bool(tech.get("trend") in ["up","strong_up"])])
        ts = bull / 4.0
    signals.append(("Technicals",    ts,                   0.30))
    sb = max(0, min(1, (sentiment_score+1)/2))
    signals.append(("News Sentiment",sb,                   0.10))
    tw   = sum(w for _,_,w in signals)
    bp   = sum(s*w for _,s,w in signals) / tw
    bias = "BULLISH" if bp>0.58 else "BEARISH" if bp<0.42 else "NEUTRAL"
    conf = round(abs(bp-0.5)*200)
    return {"bias":bias,"confidence":conf,"bull_prob":round(bp,3),
            "signals":signals,"xgb":xgb_s,"hmm":hmm_r,"tech":tech}

"""
analytics/macro_regime.py — Fixed: robust feature building, better PMI series,
aggressive ffill, minimum 2 series threshold, full error diagnostics.
"""
import numpy as np
import pandas as pd
import streamlit as st
from config import get_secret, COLORS

# Series to fetch — ordered by reliability. Will use whatever is available.
FRED_SERIES = {
    "yield_curve": "T10Y2Y",     # Daily — 10Y-2Y spread
    "fed_funds":   "FEDFUNDS",   # Monthly — Fed Funds rate
    "cpi_yoy":     "CPIAUCSL",   # Monthly — CPI
    "unemp":       "UNRATE",     # Monthly — Unemployment
    "pmi":         "MANEMP",     # Monthly — Manufacturing employment (proxy, never discontinued)
}

# Fallback PMI series to try if primary fails
PMI_FALLBACKS = ["MANEMP", "INDPRO", "NAPM", "BUSLOANS"]


@st.cache_data(ttl=3600, show_spinner=False)
def _get_macro_features(fred_key: str) -> tuple:
    """Returns (DataFrame, error_message)."""
    if not fred_key:
        return pd.DataFrame(), "FRED_KEY not set in .streamlit/secrets.toml"

    try:
        from fredapi import Fred
        fred = Fred(api_key=fred_key)
    except Exception as e:
        return pd.DataFrame(), f"fredapi import failed: {e}"

    # ── Fetch each series individually ────────────────────────────────────────
    series_data = {}
    errors      = {}

    # Core series
    for name, sid in FRED_SERIES.items():
        try:
            s = fred.get_series(sid, limit=200)
            if s is not None and len(s) > 10:
                s.index = pd.to_datetime(s.index)
                if hasattr(s.index, "tz") and s.index.tz:
                    s.index = s.index.tz_localize(None)
                s = s.dropna()
                series_data[name] = s
        except Exception as e:
            errors[name] = str(e)[:50]

    # Try PMI fallbacks if primary failed
    if "pmi" not in series_data:
        for fallback_sid in PMI_FALLBACKS:
            try:
                s = fred.get_series(fallback_sid, limit=200)
                if s is not None and len(s) > 10:
                    s.index = pd.to_datetime(s.index)
                    if hasattr(s.index, "tz") and s.index.tz:
                        s.index = s.index.tz_localize(None)
                    series_data["pmi"] = s.dropna()
                    break
            except Exception:
                continue

    if len(series_data) < 2:
        msg = f"Only {len(series_data)} FRED series loaded. Errors: {list(errors.values())[:3]}"
        return pd.DataFrame(), msg

    # ── Align to monthly frequency ────────────────────────────────────────────
    frames = {}
    for name, s in series_data.items():
        try:
            # Resample to month-start, use last value
            monthly = s.resample("MS").last()
            frames[name] = monthly
        except Exception:
            frames[name] = s

    df = pd.DataFrame(frames)

    # Forward-fill generously (up to 3 months) — handles different release calendars
    df = df.ffill(limit=3).bfill(limit=1)

    # Drop rows where MORE THAN HALF the columns are NaN
    thresh = max(2, len(df.columns) // 2)
    df = df.dropna(thresh=thresh)

    if df.empty or len(df) < 24:
        # Try dropping columns with too many NaN instead
        df_alt = pd.DataFrame(frames)
        # Only keep series with <20% NaN
        good_cols = [c for c in df_alt.columns
                     if df_alt[c].isna().mean() < 0.2]
        if good_cols:
            df = df_alt[good_cols].ffill(limit=3).dropna()

    if df.empty or len(df) < 24:
        available = list(series_data.keys())
        msg = (f"Only {len(df)} months aligned after cleaning. "
               f"Available: {available}. "
               f"Try refreshing — FRED data may need time to load.")
        return pd.DataFrame(), msg

    # ── Derived features ──────────────────────────────────────────────────────
    if "cpi_yoy" in df.columns:
        df["cpi_mom"] = df["cpi_yoy"].pct_change(fill_method=None) * 100
        df = df.ffill(limit=2)

    if "pmi" in df.columns:
        med_pmi = df["pmi"].median()
        df["pmi_above_med"] = (df["pmi"] > med_pmi).astype(float)

    # Final clean
    df = df.ffill(limit=2).dropna()
    if len(df) < 24:
        return pd.DataFrame(), f"Only {len(df)} usable rows after feature engineering (need 24)"

    return df, ""


@st.cache_data(ttl=3600, show_spinner=False)
def fit_macro_hmm(fred_key: str) -> dict:
    empty = {"regime": "UNKNOWN", "history": pd.Series(dtype=str),
             "probs": {}, "color": COLORS["neutral"], "error": ""}

    df, err = _get_macro_features(fred_key)
    if df.empty:
        empty["error"] = err
        return empty

    try:
        from hmmlearn import hmm

        # Pick best available features
        preferred = ["yield_curve", "fed_funds", "cpi_mom", "unemp",
                     "pmi_above_med", "pmi", "cpi_yoy"]
        feat_cols = [c for c in preferred if c in df.columns]
        if not feat_cols:
            feat_cols = df.columns.tolist()[:4]
        if not feat_cols:
            empty["error"] = "No feature columns available"
            return empty

        X = df[feat_cols].values

        # Scale to avoid numerical issues
        from sklearn.preprocessing import StandardScaler
        scaler = StandardScaler()
        X_scaled = scaler.fit_transform(X)

        n_states = 4
        model = hmm.GaussianHMM(n_components=n_states, covariance_type="diag",
                                  n_iter=200, random_state=42, tol=1e-4)
        model.fit(X_scaled)
        hidden = model.predict(X_scaled)
        probs  = model.predict_proba(X_scaled)

        # Label states: use yield_curve or fed_funds to rank economic strength
        rank_col = ("yield_curve" if "yield_curve" in feat_cols
                    else "fed_funds" if "fed_funds" in feat_cols
                    else feat_cols[0])
        rank_idx  = feat_cols.index(rank_col)

        # Higher yield curve + moderate rates = expansion
        # Lower yield curve (inverted) = recession risk
        means      = scaler.inverse_transform(model.means_)
        yc_means   = means[:, rank_idx]
        ranked     = np.argsort(yc_means)[::-1]
        names      = ["EXPANSION", "RECOVERY", "SLOWDOWN", "RECESSION"]
        state_map  = {int(ranked[i]): names[i] for i in range(n_states)}

        history = pd.Series([state_map.get(int(s), "UNKNOWN") for s in hidden],
                            index=df.index)
        cur    = int(hidden[-1])
        regime = state_map.get(cur, "UNKNOWN")
        cur_probs = {state_map.get(i, f"S{i}"): round(float(probs[-1][i]), 3)
                     for i in range(n_states)}
        cmap = {"EXPANSION": COLORS["bullish"], "RECOVERY": "#5DCAA5",
                "SLOWDOWN": "#EF9F27", "RECESSION": COLORS["bearish"]}

        return {"regime": regime, "history": history, "probs": cur_probs,
                "color": cmap.get(regime, COLORS["neutral"]),
                "df": df, "state_map": state_map,
                "features_used": feat_cols,
                "n_obs": len(df), "error": ""}

    except Exception as e:
        empty["error"] = f"HMM fitting failed: {str(e)[:100]}"
        return empty


def get_macro_regime() -> dict:
    fred_key = get_secret("FRED_KEY")
    return fit_macro_hmm(fred_key)


def clear_macro_cache():
    _get_macro_features.clear()
    fit_macro_hmm.clear()

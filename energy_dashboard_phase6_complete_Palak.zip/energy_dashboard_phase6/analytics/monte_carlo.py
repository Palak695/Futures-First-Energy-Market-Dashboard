"""
analytics/monte_carlo.py — Phase 6
Monte Carlo price simulation: 10,000 paths, GBM + GARCH vol.
Returns bull/base/bear scenario fan chart + VaR/CVaR estimates.
"""
import numpy as np
import pandas as pd
import streamlit as st
from data.prices import fetch_ohlcv


@st.cache_data(ttl=3600, show_spinner=False)
def run_monte_carlo(ticker: str = "BZ=F",
                    horizon_days: int = 63,
                    n_paths: int = 10000,
                    use_garch: bool = True) -> dict:
    """
    Run Monte Carlo simulation with:
    - GARCH(1,1) conditional vol if use_garch=True, else historical vol
    - Drift from trailing 1yr average daily return
    - Returns percentile fan chart + scenario stats
    """
    df = fetch_ohlcv(ticker, period="2y", interval="1d")
    if df.empty or len(df) < 60:
        return {"status": "error", "message": "Insufficient data"}

    close = df["Close"].copy()
    close.index = pd.to_datetime(close.index)
    if close.index.tz:
        close.index = close.index.tz_localize(None)

    rets   = np.log(close / close.shift(1)).dropna().values
    S0     = float(close.iloc[-1])
    mu     = float(np.mean(rets))          # daily drift
    sigma  = float(np.std(rets))           # daily vol baseline

    # GARCH conditional vol estimate
    garch_sigma = sigma
    if use_garch:
        try:
            from arch import arch_model
            am  = arch_model(rets * 100, vol="Garch", p=1, q=1,
                             dist="Normal", rescale=False)
            res = am.fit(disp="off", show_warning=False)
            fore = res.forecast(horizon=horizon_days, reindex=False)
            # Use day-1 GARCH vol as starting sigma
            garch_sigma = float(np.sqrt(fore.variance.iloc[-1,0])) / 100
        except Exception:
            garch_sigma = sigma

    # Simulate n_paths × horizon_days
    np.random.seed(42)
    daily_shocks = np.random.normal(0, 1, (n_paths, horizon_days))
    daily_rets   = mu + garch_sigma * daily_shocks

    # Cumulative paths
    log_paths  = np.cumsum(daily_rets, axis=1)
    price_paths= S0 * np.exp(log_paths)  # shape (n_paths, horizon_days)

    # Terminal prices
    terminal   = price_paths[:, -1]

    # Percentile bands for fan chart
    days       = list(range(1, horizon_days + 1))
    pct_bands  = {
        "p5":    np.percentile(price_paths, 5,  axis=0),
        "p25":   np.percentile(price_paths, 25, axis=0),
        "p50":   np.percentile(price_paths, 50, axis=0),
        "p75":   np.percentile(price_paths, 75, axis=0),
        "p95":   np.percentile(price_paths, 95, axis=0),
    }

    # Risk metrics on terminal distribution
    var_95  = round(float(S0 - np.percentile(terminal, 5)),  2)
    var_99  = round(float(S0 - np.percentile(terminal, 1)),  2)
    cvar_95 = round(float(S0 - terminal[terminal <= np.percentile(terminal, 5)].mean()), 2)

    # Scenario summary
    bull_target = round(float(np.percentile(terminal, 75)), 2)
    base_target = round(float(np.percentile(terminal, 50)), 2)
    bear_target = round(float(np.percentile(terminal, 25)), 2)

    return {
        "status":      "ok",
        "S0":          round(S0, 3),
        "horizon":     horizon_days,
        "n_paths":     n_paths,
        "days":        days,
        "pct_bands":   {k: [round(float(v),3) for v in arr]
                        for k, arr in pct_bands.items()},
        "bull_target": bull_target,
        "base_target": base_target,
        "bear_target": bear_target,
        "var_95":      var_95,
        "var_99":      var_99,
        "cvar_95":     cvar_95,
        "vol_used":    round(garch_sigma * np.sqrt(252) * 100, 2),
        "model":       "GBM + GARCH(1,1)" if use_garch else "GBM + Historical Vol",
        "terminal":    terminal.tolist(),
    }

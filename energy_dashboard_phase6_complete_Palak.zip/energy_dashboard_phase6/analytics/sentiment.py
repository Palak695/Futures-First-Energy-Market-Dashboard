"""
analytics/sentiment.py — Phase 4: FinBERT loaded in background thread
No more spinner blocking the UI during 438MB model download.
"""
import os
import threading
import streamlit as st
from config import NEWS_CATEGORIES

os.environ["TOKENIZERS_PARALLELISM"] = "false"

ENTITY_WEIGHTS = {
    "opec":3.0,"federal reserve":3.0,"fed ":2.8,"eia":2.8,
    "saudi":2.5,"iran":2.5,"russia":2.5,"ukraine":2.5,
    "china":2.3,"israel":2.3,"houthi":2.3,"hormuz":3.0,
    "suez":2.8,"red sea":2.8,"pipeline":2.0,
    "iraq":2.0,"libya":2.0,"nigeria":1.8,"venezuela":1.8,
    "iea":1.8,"brent":1.5,"wti":1.5,"crude":1.3,
    "inflation":1.5,"gdp":1.5,"recession":2.0,
    "rate hike":2.0,"rate cut":2.0,"natural gas":1.3,
    "gasoline":1.2,"diesel":1.2,"refinery":1.2,
    "inventory":1.2,"production":1.1,"tanker":1.2,"sanction":2.0,
}

# Module-level model state — shared across reruns
_model_state = {"pipe": None, "ready": False, "loading": False, "error": None}


def _load_in_background():
    """Load FinBERT in a daemon thread so UI never blocks."""
    if _model_state["loading"] or _model_state["ready"]:
        return
    _model_state["loading"] = True
    try:
        from transformers import pipeline as hf_pipeline
        pipe = hf_pipeline(
            "text-classification", model="ProsusAI/finbert",
            top_k=None, device=-1, truncation=True, max_length=512,
        )
        pipe(["test"], batch_size=1)  # warm-up
        _model_state["pipe"]  = pipe
        _model_state["ready"] = True
    except Exception as e:
        _model_state["error"] = str(e)
    finally:
        _model_state["loading"] = False


def ensure_finbert_loading():
    """Call once at app startup to begin background load."""
    if not _model_state["ready"] and not _model_state["loading"]:
        t = threading.Thread(target=_load_in_background, daemon=True)
        t.start()


def finbert_status() -> str:
    if _model_state["ready"]:    return "ready"
    if _model_state["loading"]:  return "loading"
    if _model_state["error"]:    return "error"
    return "not_started"


def _keyword_sentiment(text: str) -> tuple:
    t = text.lower()
    bull = ["rise","surge","gain","rally","bull","jump","soar","recover","higher","boost",
            "strong","increase","cut production","supply cut","opec cut","shortage","tight"]
    bear = ["fall","drop","decline","bear","plunge","crash","lower","reduce","weak",
            "oversupply","surplus","recession","sanction","attack","conflict",
            "disruption","pressure","risk","slump","concern","war"]
    bs = sum(1 for w in bull if w in t)
    es = sum(1 for w in bear if w in t)
    if bs > es:   return "positive", round(min(bs*0.25, 1.0), 3)
    if es > bs:   return "negative", round(-min(es*0.25, 1.0), 3)
    return "neutral", 0.0


def _entity_weight(text: str) -> float:
    t = text.lower()
    weights = [w for kw,w in ENTITY_WEIGHTS.items() if kw in t]
    return max(weights) if weights else 1.0


def _impact(sentiment, confidence, ew) -> float:
    return round(min(max(abs(confidence)*ew*3.5, 1.0), 10.0), 2)


def _cat(text: str) -> str:
    t = text.lower()
    scores = {c: sum(1 for kw in kws if kw in t) for c,kws in NEWS_CATEGORIES.items()}
    best = max(scores, key=scores.get)
    return best if scores[best] > 0 else "macro"


def score_headlines(news_items: list) -> list:
    if not news_items:
        return []
    scored = []
    pipe   = _model_state["pipe"] if _model_state["ready"] else None

    if pipe is not None:
        try:
            texts   = [item.get("headline","")[:256] for item in news_items]
            results = pipe(texts, batch_size=4)
            for item, result in zip(news_items, results):
                lm  = {r["label"].lower(): r["score"] for r in result}
                pos,neg,neu = lm.get("positive",0),lm.get("negative",0),lm.get("neutral",0)
                if pos>=neg and pos>=neu:   sentiment,conf = "positive", round(pos,3)
                elif neg>=pos and neg>=neu: sentiment,conf = "negative", round(-neg,3)
                else:                       sentiment,conf = "neutral",  round(neu,3)
                ew = _entity_weight(item.get("headline",""))
                scored.append({**item,
                    "sentiment":sentiment,"score":conf,"confidence":abs(conf),
                    "impact":_impact(sentiment,conf,ew),"category":_cat(item.get("headline","")),
                    "entity_weight":ew,"finbert":True})
            scored.sort(key=lambda x: x.get("impact",0), reverse=True)
            return scored
        except Exception:
            pass

    # Keyword fallback (used while FinBERT loading or on error)
    for item in news_items:
        text = item.get("headline","")
        sentiment,score = _keyword_sentiment(text)
        ew = _entity_weight(text)
        scored.append({**item,
            "sentiment":sentiment,"score":score,"confidence":abs(score),
            "impact":_impact(sentiment,abs(score),ew),"category":_cat(text),
            "entity_weight":ew,"finbert":False})
    scored.sort(key=lambda x: x.get("impact",0), reverse=True)
    return scored


def aggregate_sentiment(scored_items: list) -> dict:
    if not scored_items:
        return {"overall":"NEUTRAL","bull_pct":33,"bear_pct":33,"neut_pct":34,
                "weighted_score":0.0,"signal":"–"}
    tw = sum(i.get("impact",1) for i in scored_items) or len(scored_items)
    bw = sum(i.get("impact",1) for i in scored_items if i.get("sentiment")=="positive")
    ew = sum(i.get("impact",1) for i in scored_items if i.get("sentiment")=="negative")
    bp = round(bw/tw*100); ep = round(ew/tw*100); np_ = max(0,100-bp-ep)
    ws = round(sum(i.get("score",0)*i.get("impact",1) for i in scored_items)/tw, 3)
    overall = ("BULLISH" if bp>ep+15 else "BEARISH" if ep>bp+15 else
               "SLIGHTLY BULLISH" if bp>ep+5 else "SLIGHTLY BEARISH" if ep>bp+5 else "NEUTRAL")
    signal  = ("Strong buy" if ws>0.4 else "Mild buy bias" if ws>0.15 else
               "Strong sell" if ws<-0.4 else "Mild sell bias" if ws<-0.15 else "No clear signal")
    return {"overall":overall,"bull_pct":bp,"bear_pct":ep,"neut_pct":np_,
            "weighted_score":ws,"signal":signal}

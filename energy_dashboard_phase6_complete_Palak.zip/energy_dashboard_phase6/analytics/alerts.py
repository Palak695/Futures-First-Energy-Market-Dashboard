"""
analytics/alerts.py — Phase 3: Isolation Forest + Z-score alert system
Detects: price anomalies, volume spikes, spread extremes, inventory surprises
"""
import numpy as np
import pandas as pd
import streamlit as st
from datetime import datetime, timezone
from data.prices import fetch_ohlcv, fetch_prices
from config import COLORS


@st.cache_resource(show_spinner=False)
def _train_isolation_forest(ticker: str = "BZ=F"):
    """Train Isolation Forest on historical OHLCV features."""
    try:
        from sklearn.ensemble import IsolationForest
        df = fetch_ohlcv(ticker, period="2y", interval="1d")
        if df.empty or len(df) < 50:
            return None

        df = df.copy()
        ret  = df["Close"].pct_change(fill_method=None)
        vol  = ret.rolling(20).std()
        hl_r = (df["High"] - df["Low"]) / df["Close"]

        X = pd.DataFrame({
            "ret":     ret,
            "vol":     vol,
            "hl_range": hl_r,
        }).dropna().values

        model = IsolationForest(contamination=0.05, random_state=42, n_estimators=100)
        model.fit(X)
        return model
    except Exception:
        return None


def _z_score_alert(series: pd.Series, current_val: float,
                   window: int = 60, threshold: float = 2.0) -> dict | None:
    """Return alert dict if current value is anomalous vs rolling window."""
    if len(series) < window:
        return None
    recent = series.tail(window)
    mean   = float(recent.mean())
    std    = float(recent.std())
    if std == 0:
        return None
    z = (current_val - mean) / std
    if abs(z) >= threshold:
        direction = "above" if z > 0 else "below"
        severity  = "HIGH" if abs(z) > 3 else "MEDIUM"
        return {"z_score": round(z, 2), "direction": direction, "severity": severity}
    return None


@st.cache_data(ttl=60, show_spinner=False)
def generate_alerts(tickers: dict = None) -> list:
    """
    Generate live alerts across price, vol, and spread anomalies.
    Returns list of alert dicts sorted by severity.
    """
    if tickers is None:
        tickers = {"Brent": "BZ=F", "WTI": "CL=F", "Nat Gas": "NG=F"}

    alerts = []
    prices = fetch_prices()

    for name, ticker in tickers.items():
        try:
            df = fetch_ohlcv(ticker, period="1y", interval="1d")
            if df.empty or len(df) < 30:
                continue

            closes = df["Close"]
            rets   = closes.pct_change(fill_method=None).dropna()
            current_price = float(closes.iloc[-1])
            current_ret   = float(rets.iloc[-1])

            # Price move alert
            z = _z_score_alert(rets, current_ret, window=60)
            if z:
                alerts.append({
                    "time":     datetime.now(timezone.utc).strftime("%H:%M"),
                    "asset":    name,
                    "type":     "Price Move",
                    "message":  f"{name} daily return {current_ret*100:+.2f}% — {abs(z['z_score']):.1f}σ {z['direction']} 60d norm",
                    "severity": z["severity"],
                    "value":    f"{current_ret*100:+.2f}%",
                })

            # Volatility alert
            vol_20  = float(rets.rolling(20).std().iloc[-1]) * np.sqrt(252) * 100
            vol_hist = rets.rolling(20).std().dropna() * np.sqrt(252) * 100
            z_vol = _z_score_alert(vol_hist, vol_20, window=60)
            if z_vol and z_vol["direction"] == "above":
                alerts.append({
                    "time":     datetime.now(timezone.utc).strftime("%H:%M"),
                    "asset":    name,
                    "type":     "Volatility Spike",
                    "message":  f"{name} 20d vol at {vol_20:.1f}% — elevated vs 60d avg",
                    "severity": z_vol["severity"],
                    "value":    f"{vol_20:.1f}%",
                })

            # RSI extreme alert
            from analytics.technicals import rsi as _rsi
            rsi_vals = _rsi(closes, 14)
            if rsi_vals is not None and len(rsi_vals):
                cur_rsi = float(rsi_vals.iloc[-1])
                if cur_rsi > 75:
                    alerts.append({
                        "time": datetime.now(timezone.utc).strftime("%H:%M"),
                        "asset": name, "type": "RSI Overbought",
                        "message": f"{name} RSI at {cur_rsi:.1f} — overbought territory",
                        "severity": "MEDIUM", "value": f"RSI {cur_rsi:.1f}",
                    })
                elif cur_rsi < 25:
                    alerts.append({
                        "time": datetime.now(timezone.utc).strftime("%H:%M"),
                        "asset": name, "type": "RSI Oversold",
                        "message": f"{name} RSI at {cur_rsi:.1f} — oversold territory",
                        "severity": "MEDIUM", "value": f"RSI {cur_rsi:.1f}",
                    })

        except Exception:
            continue

    # Brent-WTI spread alert
    try:
        brent_p = prices.get("Brent", {}).get("price", 0)
        wti_p   = prices.get("WTI",   {}).get("price", 0)
        if brent_p > 0 and wti_p > 0:
            spread = brent_p - wti_p
            if spread > 6:
                alerts.append({
                    "time": datetime.now(timezone.utc).strftime("%H:%M"),
                    "asset": "Brent-WTI", "type": "Spread Extreme",
                    "message": f"Brent premium over WTI at ${spread:.2f}/bbl — above 6yr avg",
                    "severity": "MEDIUM", "value": f"${spread:.2f}",
                })
            elif spread < 1:
                alerts.append({
                    "time": datetime.now(timezone.utc).strftime("%H:%M"),
                    "asset": "Brent-WTI", "type": "Spread Compression",
                    "message": f"Brent-WTI spread compressed to ${spread:.2f}/bbl",
                    "severity": "MEDIUM", "value": f"${spread:.2f}",
                })
    except Exception:
        pass

    # Sort: HIGH first, then MEDIUM
    sev_order = {"HIGH": 0, "MEDIUM": 1, "LOW": 2}
    alerts.sort(key=lambda x: sev_order.get(x.get("severity","LOW"), 2))
    return alerts

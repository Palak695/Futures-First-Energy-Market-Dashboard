# Energy Trading Dashboard

Professional-grade crude oil & energy markets dashboard built with Python + Streamlit.

**Live:** Brent · WTI · Natural Gas · DXY · VIX · RBOB · Heating Oil  
**Data:** yFinance · EIA API · FRED API · NewsAPI · TradingView widgets

---

## Quick start (local)

### 1. Install dependencies
```bash
pip install -r requirements.txt
python -m spacy download en_core_web_sm
```

### 2. Configure API keys
Copy the secrets template and fill in your keys:
```bash
cp .streamlit/secrets.toml.example .streamlit/secrets.toml
```

Edit `.streamlit/secrets.toml`:
```toml
[api_keys]
EIA_KEY  = "your_eia_key"
FRED_KEY = "your_fred_key"
NEWS_API_KEY = "your_newsapi_key"
```

Get free keys:
- EIA: https://www.eia.gov/opendata/register.php
- FRED: https://fredapi.stlouisfed.org/docs/api
- NewsAPI: https://newsapi.org/register

### 3. Convert your datasets (if you have the CSV files)
```bash
# Edit scripts/convert_to_parquet.py — set CSV_PATHS to your file locations
python scripts/convert_to_parquet.py
```

### 4. Run
```bash
streamlit run app.py
```

Open: http://localhost:8501

---

## Deploy to Streamlit Community Cloud (free, shareable URL)

### 1. Push to GitHub
```bash
git init
git add .
git commit -m "Energy dashboard Phase 1"
git remote add origin https://github.com/YOUR_USERNAME/energy-dashboard.git
git push -u origin main
```

### 2. Connect Streamlit Cloud
1. Go to https://share.streamlit.io
2. Click "New app"
3. Select your GitHub repo
4. Set main file: `app.py`
5. Click "Advanced settings" → add your secrets:
   ```
   [api_keys]
   EIA_KEY = "Or2cPky2GPT6abAhGtx0ucwjiJy8y2WAgJhTMBTV"
   FRED_KEY = "145ea507288f12eb9ccb5107d9e01337"
   NEWS_API_KEY = "2a930db4c67247b4ae4691e68ad8402f"
   ```
6. Click "Deploy!" — live URL generated in ~2 minutes

---

## Phase roadmap

| Phase | Features | Status |
|-------|----------|--------|
| 1 | Skeleton, live prices, TradingView, EIA inventory, news feed, correlations | ✅ Current |
| 2 | FinBERT news sentiment, impact scoring, events calendar | 🔲 Next |
| 3 | ML signals (LSTM + XGBoost + HMM), bias panel, SHAP | 🔲 |
| 4 | Futures curve, crack spreads, seasonality, WTI-Brent spread | 🔲 |
| 5 | Tanker map, CFTC COT, GARCH vol, options flow | 🔲 |
| 6 | Macro HMM regime, Monte Carlo, geo risk heatmap, AI engine | 🔲 |

---

## Dataset setup

Run `scripts/convert_to_parquet.py` with your CSV files to enable:
- Futures curve (LCOSettle c1–c31)
- WTI-Brent spread analytics (wtcl_lco)
- Seasonality charts (LGO, HO monthly aggregates)
- ML model training (1-min datasets, local only)

**Never commit raw CSV or 1-min parquet files to GitHub** — they are too large
and contain potentially proprietary data. Only the display-aggregated parquets
in `data_files/` should be in the repo.

---

## Architecture

```
app.py                    ← Streamlit entrypoint
tabs/                     ← One file per tab
data/                     ← All API fetchers
analytics/                ← Indicators + ML inference
models/weights/           ← Pre-trained model files
components/               ← Reusable UI components
scripts/                  ← Run locally (data conversion, training)
data_files/               ← Parquet display files (in repo)
```

Data never hardcoded. All values from live APIs or cached parquet files.

RAW DATA FOLDER
===============
Drop your CSV files here. The converter script reads from this folder automatically.

Expected files (copy your CSVs here with these exact names):
  LCOSettle.csv               — Brent daily settlements c1-c31
  LCO_data.csv                — Brent 1-min 2021-2024
  CL_data.csv                 — WTI 1-min 2021-2024
  CL_outrights_1min.csv       — WTI 1-min 2022-2025
  HO_data.csv                 — Heating Oil 1-min 2021-2024
  LGO_data.csv                — ICE Gasoil 1-min 2021-2024
  wtcl_lco_outrights_1min.csv — WTI-Brent spread 1-min 2021-2024

After copying, run from the project root:
  python scripts/convert_to_parquet.py

Then push to GitHub and Streamlit Cloud auto-redeploys.

NOTE: raw_data/*.csv files are in .gitignore (too large for GitHub).
      Only the converted data_files/*.parquet files go to GitHub.

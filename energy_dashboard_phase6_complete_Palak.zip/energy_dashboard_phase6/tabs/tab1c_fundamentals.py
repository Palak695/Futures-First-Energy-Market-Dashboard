"""
tabs/tab1c_fundamentals.py
Fundamentals tab with 3 subtabs: Macro (GDP/PMI), Supply (US/OPEC), Trade (BDI/CPB).
"""
import streamlit as st
import plotly.graph_objects as go
from plotly.subplots import make_subplots
import pandas as pd
import numpy as np

from data.fundamentals import (
    fetch_wb_gdp, fetch_fred_macro, fetch_supply_data,
    compute_opec_compliance, fetch_cpb_world_trade, fetch_bdi_proxy,
)
from config import COLORS, get_secret


def _apply(fig, h=320, m=None):
    m = m or dict(l=55, r=20, t=40, b=45)
    fig.update_layout(
        paper_bgcolor="rgba(0,0,0,0)", plot_bgcolor="rgba(0,0,0,0)",
        font=dict(color="#e8e8e8", size=12),
        xaxis=dict(gridcolor="#2d3748", linecolor="#2d3748", tickcolor="#a0aec0"),
        yaxis=dict(gridcolor="#2d3748", linecolor="#2d3748", tickcolor="#a0aec0"),
        legend=dict(bgcolor="rgba(0,0,0,0)"),
        hoverlabel=dict(bgcolor="#1e2738", font_color="#e8e8e8"),
        height=h, margin=m)


def _rgba(h, a=0.12):
    h = h.lstrip("#")
    return f"rgba({int(h[0:2],16)},{int(h[2:4],16)},{int(h[4:6],16)},{a})"


def _val_card(col, label, value, change=None, note="", color=None):
    if color is None:
        color = COLORS["bullish"] if (change or 0) >= 0 else COLORS["bearish"]
    arrow = "▲" if (change or 0) > 0 else "▼" if (change or 0) < 0 else "→"
    col.markdown(f"""
<div style="background:#1a2035;border:.5px solid #2d3748;border-left:3px solid {color};
     border-radius:7px;padding:10px 12px;margin-bottom:6px;">
  <div style="font-size:10px;color:#a0aec0;">{label}</div>
  <div style="font-size:18px;font-weight:700;color:#e8e8e8;">{value}</div>
  <div style="font-size:11px;color:{color};">{arrow} {abs(change):.2f} vs prev</div>
  <div style="font-size:10px;color:#555;">{note}</div>
</div>""", unsafe_allow_html=True)


def render_fundamentals_tab():
    st.markdown("""
<div style="background:#1a2035;border:.5px solid #2d3748;border-radius:8px;
     padding:12px 18px;margin-bottom:14px;">
  <span style="font-size:15px;font-weight:600;color:#e8e8e8;">
    📐 Fundamentals
  </span>
  <span style="font-size:12px;color:#a0aec0;margin-left:12px;">
    GDP · PMI · US Production · OPEC+ · Spare Capacity · Trade Volume · BDI
  </span>
</div>""", unsafe_allow_html=True)

    t1, t2, t3 = st.tabs([
        "🌍 Macro (GDP & PMI)",
        "🛢️ Supply (US & OPEC+)",
        "🚢 Trade & Freight",
    ])
    with t1: _macro_tab()
    with t2: _supply_tab()
    with t3: _trade_tab()


# ── MACRO: GDP & PMI ──────────────────────────────────────────────────────────
def _macro_tab():
    fred_key = get_secret("FRED_KEY")

    c1, c2 = st.columns(2)
    with c1:
        st.markdown("**🌐 GDP growth — World Bank (annual %)**")
        with st.spinner("Fetching World Bank GDP data..."):
            gdp = fetch_wb_gdp()

        if not gdp:
            st.info("World Bank GDP data unavailable. Check network connection.")
        else:
            # Summary metric cards
            card_cols = st.columns(min(len(gdp), 3))
            for i, (country, data) in enumerate(gdp.items()):
                chg = (data["latest_value"] - data["prev_value"]
                       if data["prev_value"] else 0)
                color = COLORS["bullish"] if data["latest_value"] > 0 else COLORS["bearish"]
                with card_cols[i % 3]:
                    st.markdown(f"""
<div style="background:#1a2035;border:.5px solid #2d3748;border-left:3px solid {color};
     border-radius:7px;padding:8px 10px;margin-bottom:6px;text-align:center;">
  <div style="font-size:10px;color:#a0aec0;">{country}</div>
  <div style="font-size:16px;font-weight:700;color:{color};">
    {data['latest_value']:+.1f}%
  </div>
  <div style="font-size:10px;color:#555;">{data['latest_year']}</div>
</div>""", unsafe_allow_html=True)

            # GDP bar chart — all countries latest year
            countries  = list(gdp.keys())
            values     = [gdp[c]["latest_value"] for c in countries]
            bar_colors = [COLORS["bullish"] if v > 0 else COLORS["bearish"] for v in values]
            fig = go.Figure(go.Bar(
                x=countries, y=values,
                marker_color=bar_colors,
                text=[f"{v:+.1f}%" for v in values],
                textposition="outside",
                hovertemplate="<b>%{x}</b><br>GDP growth: %{y:+.2f}%<extra></extra>"))
            fig.add_hline(y=0, line=dict(color="#555", width=1))
            _apply(fig, h=280)
            fig.update_layout(
                title=dict(text="GDP growth rate % (latest available year)",
                           font=dict(size=13)),
                yaxis_title="GDP growth (%)")
            st.plotly_chart(fig, use_container_width=True,
                            config={"displayModeBar":False}, key="gdp_bar")

            # Historical trend for selected country
            sel_country = st.selectbox("GDP history", list(gdp.keys()),
                                        key="gdp_country_sel")
            hist = gdp[sel_country].get("history", pd.DataFrame())
            if not hist.empty:
                fig2 = go.Figure()
                color = COLORS["brent"]
                fig2.add_trace(go.Scatter(
                    x=hist["year"], y=hist["gdp_growth"].round(2),
                    mode="lines+markers", name=sel_country,
                    line=dict(color=color, width=2),
                    marker=dict(size=5),
                    fill="tozeroy", fillcolor=_rgba(color, 0.1),
                    hovertemplate="Year: %{x}<br>GDP: %{y:+.2f}%<extra></extra>"))
                fig2.add_hline(y=0, line=dict(color="#555", width=1, dash="dash"))
                _apply(fig2, h=240)
                fig2.update_layout(
                    title=dict(text=f"{sel_country} GDP growth history",
                               font=dict(size=12)),
                    yaxis_title="GDP growth (%)")
                st.plotly_chart(fig2, use_container_width=True,
                                config={"displayModeBar":False}, key="gdp_hist")

        st.markdown("**Oil demand impact:**")
        st.markdown("""
<div style="background:#0e1117;border:.5px solid #2d3748;border-radius:7px;padding:10px 14px;font-size:12px;color:#a0aec0;line-height:1.7;">
• Global GDP 1% change ≈ 0.8–1.0 mbbl/d crude demand change<br>
• China GDP below 5% = downside risk to 16 mbbl/d import run-rate<br>
• US recession = 1–3 mbbl/d demand destruction (historical)<br>
• India growing >7% = 300–500 kbbl/d incremental demand per year
</div>""", unsafe_allow_html=True)

    with c2:
        st.markdown("**📊 Manufacturing PMI & Industrial Production (FRED)**")
        if not fred_key:
            st.warning("Set FRED_KEY in .streamlit/secrets.toml to load PMI data.")
        else:
            with st.spinner("Loading FRED macro data..."):
                macro = fetch_fred_macro(fred_key)

            if not macro:
                st.info("FRED macro data loading — check FRED_KEY.")
            else:
                # PMI card
                pmi = macro.get("US_PMI", {})
                if pmi:
                    val = pmi["value"]; chg = pmi["change"]
                    color = COLORS["bullish"] if val > 50 else COLORS["bearish"]
                    st.markdown(f"""
<div style="background:#1a2035;border:1px solid {color};border-radius:9px;
     padding:14px 18px;margin-bottom:10px;">
  <div style="font-size:11px;color:#a0aec0;">US ISM Manufacturing PMI · {pmi['date']}</div>
  <div style="font-size:28px;font-weight:800;color:{color};">{val:.1f}</div>
  <div style="font-size:12px;color:{color};">
    {'▲' if chg>0 else '▼'}{abs(chg):.1f} vs prior month · 
    {'Expanding (>50)' if val>50 else 'Contracting (<50)'}
  </div>
  <div style="font-size:11px;color:#555;margin-top:4px;">
    50 = neutral. &gt;50 = manufacturing expansion → crude demand bullish.
  </div>
</div>""", unsafe_allow_html=True)

                # Industrial Production chart
                ip = macro.get("US_INDPRO", {})
                if ip:
                    s = ip["series"]
                    fig3 = go.Figure(go.Scatter(
                        x=s.index, y=s.round(2).values,
                        mode="lines", name="US Industrial Production",
                        line=dict(color=COLORS["wti"], width=2),
                        fill="tozeroy", fillcolor=_rgba(COLORS["wti"], 0.1)))
                    _apply(fig3, h=240)
                    fig3.update_layout(
                        title=dict(text="US Industrial Production Index",
                                   font=dict(size=12)),
                        yaxis_title="Index (2017=100)")
                    st.plotly_chart(fig3, use_container_width=True,
                                    config={"displayModeBar":False}, key="indpro_chart")

                # PMI history chart
                if pmi and "series" in pmi:
                    s = pmi["series"]
                    fig4 = go.Figure()
                    colors_pmi = [COLORS["bullish"] if v > 50 else COLORS["bearish"]
                                  for v in s.values]
                    fig4.add_trace(go.Bar(x=s.index, y=s.round(1).values,
                                          marker_color=colors_pmi,
                                          name="PMI"))
                    fig4.add_hline(y=50, line=dict(color="#e8e8e8", width=1.5,
                                                    dash="dash"),
                                   annotation_text="50 = neutral",
                                   annotation_font_color="#a0aec0")
                    _apply(fig4, h=240)
                    fig4.update_layout(
                        title=dict(text="US ISM Manufacturing PMI", font=dict(size=12)),
                        yaxis_title="PMI")
                    st.plotly_chart(fig4, use_container_width=True,
                                    config={"displayModeBar":False}, key="pmi_chart")

        st.markdown("**PMI → oil demand signal:**")
        st.markdown("""
<div style="background:#0e1117;border:.5px solid #2d3748;border-radius:7px;padding:10px 14px;font-size:12px;color:#a0aec0;line-height:1.7;">
• PMI 50→55: Industrial demand picking up, diesel/HO consumption rising<br>
• PMI &lt;48 for 2+ months: Manufacturing recession, crude demand at risk<br>
• Global PMI divergence (US strong, China weak): Bearish for sour crude
</div>""", unsafe_allow_html=True)


# ── SUPPLY: US PRODUCTION + OPEC+ ────────────────────────────────────────────
def _supply_tab():
    fred_key = get_secret("FRED_KEY")

    if not fred_key:
        st.warning("Set FRED_KEY in .streamlit/secrets.toml for supply data.")
        return

    with st.spinner("Loading supply data from FRED..."):
        supply  = fetch_supply_data(fred_key)
        opec    = compute_opec_compliance(fred_key)

    # ── Row 1: US Crude Production ────────────────────────────────────────────
    st.markdown("**🇺🇸 US Crude Oil Production**")
    us_prod = supply.get("US_crude_production", {})
    if us_prod:
        c1, c2, c3, c4 = st.columns(4)
        current_prod = us_prod["value"]
        yoy_prod     = us_prod.get("yoy")
        color_prod   = COLORS["bearish"] if (us_prod["change"] or 0) > 0 else COLORS["bullish"]
        # Rising production = bearish for price (more supply)
        c1.metric("US Weekly Production",
                  f"{current_prod:.2f} mbbl/d",
                  delta=f"{us_prod['change']:+.3f} vs prior week")
        c2.metric("YoY change",
                  f"{yoy_prod:+.2f} mbbl/d" if yoy_prod else "–")
        c3.metric("As of", us_prod.get("date","–"))
        c4.metric("vs 2023 peak",
                  f"{current_prod - 13.2:+.2f} mbbl/d",
                  delta="2023 record: 13.2 mbbl/d")

        s = us_prod["series"]
        fig = go.Figure()
        fig.add_trace(go.Scatter(
            x=s.index, y=s.round(3).values,
            mode="lines", name="US crude production",
            line=dict(color=COLORS["wti"], width=2),
            fill="tozeroy", fillcolor=_rgba(COLORS["wti"], 0.08)))
        # Add 4-week MA
        ma4 = s.rolling(4).mean()
        fig.add_trace(go.Scatter(
            x=ma4.index, y=ma4.round(3).values,
            mode="lines", name="4-week avg",
            line=dict(color=COLORS["brent"], width=1.5, dash="dot")))
        _apply(fig, h=280)
        fig.update_layout(
            title=dict(text="US crude oil field production (weekly, mbbl/d)",
                       font=dict(size=13)),
            yaxis_title="mbbl/d")
        st.plotly_chart(fig, use_container_width=True,
                        config={"displayModeBar":True}, key="us_prod_chart")
    else:
        st.info("US production data loading — check FRED_KEY.")

    st.divider()

    # ── Row 2: OPEC+ Compliance & Spare Capacity ──────────────────────────────
    st.markdown("**🛢️ OPEC+ Production Quotas, Compliance & Spare Capacity**")

    col1, col2 = st.columns([1, 1])

    with col1:
        st.markdown("**Quota reference table** *(updated Nov 2024)*")
        quotas = opec.get("quotas", {})
        if quotas:
            df_q = pd.DataFrame([
                {"Country": k, "Quota (mbbl/d)": v,
                 "Status": "Exempt" if k in ("Libya","Iran","Venezuela") else "Active"}
                for k, v in quotas.items()
            ])
            df_q["Quota (mbbl/d)"] = df_q["Quota (mbbl/d)"].round(2)
            df_q = df_q.sort_values("Quota (mbbl/d)", ascending=False)
            st.dataframe(df_q, use_container_width=True, hide_index=True, height=320)
            total = opec.get("total_quota", 0)
            st.caption(f"Total OPEC+ quota: {total:.1f} mbbl/d · {opec.get('quota_date','')}")

    with col2:
        st.markdown("**Saudi Arabia — production vs quota vs spare capacity**")
        saudi = opec.get("saudi", {})
        if saudi:
            sc    = saudi["spare_capacity"]
            comp  = saudi["compliance_pct"]
            quota = saudi["quota"]
            act   = saudi["actual"]
            sc_color = (COLORS["bearish"] if sc < 1.5
                        else COLORS["bullish"] if sc > 2.5
                        else "#EF9F27")

            c1, c2, c3 = st.columns(3)
            c1.metric("Production",     f"{act:.2f} mbbl/d",
                      delta=f"{act-quota:+.2f} vs quota")
            c2.metric("Quota",          f"{quota:.2f} mbbl/d")
            c3.metric("Spare Capacity", f"{sc:.2f} mbbl/d",
                      delta="Tight" if sc < 1.5 else "Adequate",
                      delta_color="inverse" if sc < 1.5 else "normal")

            st.markdown(f"""
<div style="background:#1a2035;border:1px solid {sc_color};border-radius:8px;
     padding:12px 16px;margin:8px 0;">
  <div style="font-size:12px;font-weight:600;color:{sc_color};">
    Spare capacity: {sc:.2f} mbbl/d
    {"— TIGHT (price spike risk ↑)" if sc < 1.5
     else "— ADEQUATE" if sc < 2.5
     else "— COMFORTABLE (price cap effect)"}
  </div>
  <div style="font-size:11px;color:#a0aec0;margin-top:4px;">
    Saudi compliance: {comp:.0f}% · Source: FRED SAOIDPCP · {saudi.get('date','')}
  </div>
</div>""", unsafe_allow_html=True)

            # Spare capacity history
            s_series = saudi.get("series")
            if s_series is not None and not s_series.empty:
                spare_series = 12.0 - s_series
                fig = go.Figure()
                fig.add_trace(go.Scatter(
                    x=s_series.index, y=s_series.round(3).values,
                    name="Saudi production", mode="lines",
                    line=dict(color=COLORS["wti"], width=2)))
                fig.add_trace(go.Scatter(
                    x=spare_series.index, y=spare_series.round(3).values,
                    name="Spare capacity (12 - actual)",
                    mode="lines", line=dict(color=sc_color, width=2, dash="dot"),
                    fill="tozeroy", fillcolor=_rgba(sc_color, 0.1)))
                fig.add_hline(y=quota,
                              line=dict(color="#888780", width=1.5, dash="dash"),
                              annotation_text=f"Quota {quota} mbbl/d",
                              annotation_font_color="#888780")
                _apply(fig, h=280)
                fig.update_layout(
                    title=dict(text="Saudi Arabia: production vs spare capacity",
                               font=dict(size=12)),
                    yaxis_title="mbbl/d")
                st.plotly_chart(fig, use_container_width=True,
                                config={"displayModeBar":True}, key="saudi_chart")
        else:
            st.info("Saudi production data loading from FRED (SAOIDPCP).")

    st.divider()
    st.markdown("**Market significance — supply signals:**")
    st.markdown("""
<div style="background:#0e1117;border:.5px solid #2d3748;border-radius:7px;
     padding:10px 14px;font-size:12px;color:#a0aec0;line-height:1.8;">
• <strong style="color:#e8e8e8;">Spare capacity &lt;1.5 mbbl/d:</strong> Any supply disruption can't be covered — geopolitical risk premium justified ($3–8/bbl)<br>
• <strong style="color:#e8e8e8;">OPEC over-producing vs quota:</strong> Compliance breakdown → more supply → bearish (seen 2016, 2020)<br>
• <strong style="color:#e8e8e8;">US production >13 mbbl/d:</strong> Structural ceiling on price rallies above $90/bbl (shale economics)<br>
• <strong style="color:#e8e8e8;">OPEC meets:</strong> Dec and Jun typically. 2-week pre-meeting window often shows unusual positioning in COT
</div>""", unsafe_allow_html=True)


# ── TRADE: GLOBAL TRADE + BDI ─────────────────────────────────────────────────
def _trade_tab():
    c1, c2 = st.columns([1, 1])

    with c1:
        st.markdown("**📦 Global Trade Volume (World Bank / CPB)**")
        with st.spinner("Fetching global trade data..."):
            trade_df = fetch_cpb_world_trade()

        if not trade_df.empty:
            # Show whatever columns we got
            numeric_cols = trade_df.select_dtypes(include="number").columns.tolist()
            date_col     = next((c for c in trade_df.columns
                                 if "year" in c.lower() or "date" in c.lower()
                                 or "period" in c.lower()), None)

            if date_col and numeric_cols:
                # Plot first numeric column as trade volume index
                val_col = numeric_cols[0]
                fig = go.Figure(go.Scatter(
                    x=trade_df[date_col], y=trade_df[val_col].round(2),
                    mode="lines+markers", name="Global trade volume",
                    line=dict(color=COLORS["brent"], width=2),
                    fill="tozeroy", fillcolor=_rgba(COLORS["brent"], 0.08),
                    marker=dict(size=4)))
                _apply(fig, h=280)
                fig.update_layout(
                    title=dict(text="Global trade volume index", font=dict(size=13)),
                    yaxis_title=val_col)
                st.plotly_chart(fig, use_container_width=True,
                                config={"displayModeBar":True}, key="trade_chart")

                latest = float(trade_df[val_col].iloc[-1])
                prev   = float(trade_df[val_col].iloc[-2]) if len(trade_df)>1 else latest
                chg    = round(latest - prev, 2)
                color  = COLORS["bullish"] if chg >= 0 else COLORS["bearish"]
                st.markdown(f"""
<div style="background:#1a2035;border:.5px solid #2d3748;border-left:3px solid {color};
     border-radius:7px;padding:8px 12px;">
  <div style="font-size:10px;color:#a0aec0;">Latest: {trade_df[date_col].iloc[-1]}</div>
  <div style="font-size:18px;font-weight:700;color:#e8e8e8;">{latest:.1f}</div>
  <div style="font-size:11px;color:{color};">{'▲' if chg>=0 else '▼'}{abs(chg):.2f} vs prior</div>
</div>""", unsafe_allow_html=True)
        else:
            st.info("""
**World Bank trade data unavailable from network.**

Global Trade Monitor sources:
- CPB World Trade Monitor: [cpb.nl](https://www.cpb.nl)
- World Bank Open Data: [data.worldbank.org](https://data.worldbank.org)
- WTO Statistics: [stats.wto.org](https://stats.wto.org)

The BDI proxy chart (right) uses publicly available shipping stocks as a real-time proxy.
""")
            # Show context table instead
            st.markdown("**Historical context: trade volume and oil demand**")
            rows = [
                ("2008 GFC",      "Global trade -25%",  "Crude -70% ($147→$35)"),
                ("2011-2014",     "Trade recovery",     "Brent above $100"),
                ("2015-2016",     "China slowdown",     "WTI -65% ($100→$35)"),
                ("2020 COVID",    "Trade -8.5%",        "WTI negative briefly"),
                ("2021-2022",     "Supply chain surge", "Brent +85% recovery"),
                ("2023-2024",     "Trade normalising",  "Brent $70-$90 range"),
            ]
            df_ctx = pd.DataFrame(rows, columns=["Period","Trade","Oil price impact"])
            st.dataframe(df_ctx, use_container_width=True, hide_index=True)

        st.markdown("**Trade → oil demand signal:**")
        st.markdown("""
<div style="background:#0e1117;border:.5px solid #2d3748;border-radius:7px;
     padding:10px 14px;font-size:12px;color:#a0aec0;line-height:1.7;">
• Global trade 5%+ decline historically precedes crude demand contraction within 2 quarters<br>
• Container shipping slowdown leads diesel demand by ~6 weeks (trucks/rail follow container moves)<br>
• Trade finance conditions (USD LIBOR/SOFR) affect emerging market oil import capacity
</div>""", unsafe_allow_html=True)

    with c2:
        st.markdown("**⚓ Baltic Dry Index Proxy (shipping stocks)**")
        st.caption("BDI requires paid Baltic Exchange subscription. "
                   "These shipping stocks correlate closely with dry bulk and tanker rates.")

        period = st.radio("Period", ["6mo","1y","2y"], index=1,
                           horizontal=True, key="bdi_period")

        with st.spinner("Loading BDI proxies..."):
            bdi = fetch_bdi_proxy(period=period)

        if not bdi:
            st.info("BDI proxy data loading — check yFinance connection.")
        else:
            # Cards
            cols = st.columns(3)
            for i, (name, data) in enumerate(bdi.items()):
                c = COLORS["bullish"] if data["bullish"] else COLORS["bearish"]
                with cols[i % 3]:
                    st.markdown(f"""
<div style="background:#1a2035;border:.5px solid #2d3748;border-left:3px solid {c};
     border-radius:7px;padding:7px 9px;margin-bottom:5px;text-align:center;">
  <div style="font-size:9px;color:#a0aec0;">{name.split('(')[0].strip()}</div>
  <div style="font-size:13px;font-weight:700;color:{c};">${data['current']:.2f}</div>
  <div style="font-size:10px;color:{c};">{'▲' if data['bullish'] else '▼'}{abs(data['chg_pct']):.1f}%</div>
  <div style="font-size:9px;color:#555;">3M: {data['ret_3m']:+.1f}%</div>
</div>""", unsafe_allow_html=True)

            # Normalised chart — split dry bulk vs tankers
            dry_bulk = {k:v for k,v in bdi.items()
                        if any(x in k for x in ["Star","Genco","Safe"])}
            tankers  = {k:v for k,v in bdi.items()
                        if any(x in k for x in ["Frontline","Scorpio","ZIM"])}

            fig = go.Figure()
            colors_cycle = [COLORS["brent"],COLORS["wti"],"#5DCAA5",
                            "#EF9F27","#7F77DD","#D85A30"]
            for i,(name,data) in enumerate(bdi.items()):
                s = data.get("history", pd.Series())
                if s.empty or len(s)<2: continue
                norm = (s/s.iloc[0]*100).round(2)
                # Distinguish dry bulk vs tanker with line style
                is_dry = any(x in name for x in ["Star","Genco","Safe"])
                fig.add_trace(go.Scatter(
                    x=norm.index, y=norm.values,
                    name=name.split("(")[0].strip(),
                    mode="lines",
                    line=dict(color=colors_cycle[i % len(colors_cycle)],
                              width=1.8,
                              dash="dot" if is_dry else "solid"),
                    hovertemplate=f"<b>{name}</b><br>%{{y:.1f}}<extra></extra>"))

            fig.add_hline(y=100, line=dict(color="#2d3748", width=1, dash="dot"))
            _apply(fig, h=300)
            fig.update_layout(
                title=dict(
                    text="Shipping stocks normalised (solid=tanker, dot=dry bulk)",
                    font=dict(size=12)),
                yaxis_title="Rebased (100 = period start)")
            st.plotly_chart(fig, use_container_width=True,
                            config={"displayModeBar":True}, key="bdi_chart")

            # Performance table
            perf_rows = [{"Name": n.split("(")[0].strip(),
                          "Type": "Dry Bulk" if any(x in n for x in ["Star","Genco","Safe"])
                                  else "Tanker/Container",
                          "Current": f"${d['current']:.2f}",
                          "Today": f"{d['chg_pct']:+.1f}%",
                          "3M return": f"{d['ret_3m']:+.1f}%",
                          "1Y return": f"{d['ret_1y']:+.1f}%"}
                         for n,d in bdi.items()]
            st.dataframe(pd.DataFrame(perf_rows), use_container_width=True, hide_index=True)

        st.markdown("**BDI interpretation:**")
        st.markdown("""
<div style="background:#0e1117;border:.5px solid #2d3748;border-radius:7px;
     padding:10px 14px;font-size:12px;color:#a0aec0;line-height:1.7;">
• <strong style="color:#e8e8e8;">Dry bulk (SBLK, GNK) rising:</strong> Iron ore, coal, grain demand up → industrial activity → oil demand bullish<br>
• <strong style="color:#e8e8e8;">Tanker (FRO, STNG) rising:</strong> Crude/product freight rates rising → physical supply tightness<br>
• <strong style="color:#e8e8e8;">Container (ZIM) rising:</strong> Global trade recovering → consumer goods demand → diesel/jet fuel bullish<br>
• <strong style="color:#e8e8e8;">All shipping falling together:</strong> Global trade recession signal — strongest bearish macro signal
</div>""", unsafe_allow_html=True)

# Energy Trading Dashboard
# Phase 1 — Skeleton + Live Prices

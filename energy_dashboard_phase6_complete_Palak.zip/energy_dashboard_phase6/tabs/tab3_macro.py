"""tabs/tab3_macro.py — Monte Carlo, FRED indicators, Geo risk (macro regime removed)"""
import streamlit as st
import plotly.graph_objects as go
import pandas as pd
import numpy as np

from data.fred import fetch_yield_curve_history, fetch_fed_funds_history
from analytics.monte_carlo import run_monte_carlo
from config import COLORS


def _rgba(h, a=0.12):
    h = h.lstrip("#")
    return f"rgba({int(h[0:2],16)},{int(h[2:4],16)},{int(h[4:6],16)},{a})"


def _apply(fig, h=300, m=None):
    m = m or dict(l=55, r=20, t=40, b=45)
    fig.update_layout(
        paper_bgcolor="rgba(0,0,0,0)", plot_bgcolor="rgba(0,0,0,0)",
        font=dict(color="#e8e8e8", size=12),
        xaxis=dict(gridcolor="#2d3748", linecolor="#2d3748", tickcolor="#a0aec0"),
        yaxis=dict(gridcolor="#2d3748", linecolor="#2d3748", tickcolor="#a0aec0"),
        legend=dict(bgcolor="rgba(0,0,0,0)"),
        hoverlabel=dict(bgcolor="#1e2738", font_color="#e8e8e8"),
        height=h, margin=m)


def render_tab3():
    t1, t2, t3 = st.tabs([
        "🎲 Monte Carlo forecast",
        "📊 FRED indicators",
        "🗺️ Geopolitical risk",
    ])
    with t1: _monte_carlo()
    with t2: _fred_charts()
    with t3: _geo_risk()


def _monte_carlo():
    col1, col2, col3 = st.columns(3)
    with col1:
        ticker_map = {"Brent":"BZ=F","WTI":"CL=F","Nat Gas":"NG=F"}
        asset  = st.selectbox("Asset", list(ticker_map.keys()), key="mc_asset")
        ticker = ticker_map[asset]
    with col2:
        horizon = st.select_slider("Horizon", options=[21,42,63,126,252], value=63,
                                    key="mc_horizon", format_func=lambda x:f"{x}d (~{x//21}mo)")
    with col3:
        use_garch = st.checkbox("GARCH vol", value=True, key="mc_garch")

    with st.spinner(f"Running 10,000 Monte Carlo paths for {asset}..."):
        mc = run_monte_carlo(ticker, horizon_days=horizon, n_paths=10000, use_garch=use_garch)

    if mc.get("status") != "ok":
        st.info(mc.get("message", "Monte Carlo unavailable — check yFinance connection.")); return

    S0=mc["S0"]; days=mc["days"]; pb=mc["pct_bands"]
    fig = go.Figure()
    for lo,hi,rgba_str,name in [
        ("p5","p95","rgba(136,135,128,0.10)","90% CI"),
        ("p25","p75","rgba(55,138,221,0.15)","50% CI"),
    ]:
        fig.add_trace(go.Scatter(
            x=days+days[::-1], y=pb[hi]+pb[lo][::-1],
            fill="toself", fillcolor=rgba_str,
            line=dict(color="rgba(0,0,0,0)"), name=name))
    fig.add_trace(go.Scatter(x=days, y=pb["p50"], mode="lines",
        name="Median", line=dict(color=COLORS["brent"], width=2.5)))
    for label,key,col in [("Bull P75","p75",COLORS["bullish"]),
                           ("Bear P25","p25",COLORS["bearish"])]:
        fig.add_trace(go.Scatter(x=days, y=pb[key], mode="lines", name=label,
            line=dict(color=col, width=1.5, dash="dot")))
    fig.add_hline(y=S0, line=dict(color="#666", width=1, dash="dash"),
                  annotation_text=f"Current ${S0:.2f}", annotation_font_color="#888")
    _apply(fig, h=420)
    fig.update_layout(
        title=dict(text=f"{asset} Monte Carlo — {horizon}d · {mc['model']} · Vol={mc['vol_used']:.1f}%",
                   font=dict(size=14)),
        xaxis_title="Trading days ahead", yaxis_title="Price ($/bbl)")
    st.plotly_chart(fig, use_container_width=True, config={"displayModeBar":True}, key="mc_fan")

    c1,c2,c3,c4,c5,c6 = st.columns(6)
    c1.metric("Current", f"${S0:.2f}")
    c2.metric("Median",  f"${mc['base_target']:.2f}", delta=f"{(mc['base_target']/S0-1)*100:+.1f}%")
    c3.metric("Bull P75",f"${mc['bull_target']:.2f}", delta=f"{(mc['bull_target']/S0-1)*100:+.1f}%")
    c4.metric("Bear P25",f"${mc['bear_target']:.2f}", delta=f"{(mc['bear_target']/S0-1)*100:+.1f}%")
    c5.metric("VaR 95%", f"-${mc['var_95']:.2f}", delta_color="inverse")
    c6.metric("CVaR 95%",f"-${mc['cvar_95']:.2f}", delta_color="inverse")

    with st.expander("Terminal distribution", expanded=False):
        terminal = mc.get("terminal", [])
        if terminal:
            fig2 = go.Figure(go.Histogram(x=[round(v,2) for v in terminal],
                nbinsx=80, marker_color=COLORS["brent"], opacity=0.8))
            fig2.add_vline(x=S0, line=dict(color="#e8e8e8", width=2, dash="dash"),
                           annotation_text=f"Current ${S0:.2f}")
            _apply(fig2, h=260)
            fig2.update_layout(title=dict(text=f"Terminal distribution ({horizon}d)", font=dict(size=13)),
                               xaxis_title="Price ($/bbl)", yaxis_title="Frequency")
            st.plotly_chart(fig2, use_container_width=True,
                            config={"displayModeBar":False}, key="mc_terminal")


def _fred_charts():
    """FRED macro indicators — yield curve and Fed Funds directly (no macro_regime dependency)."""
    st.markdown("**Key macro indicators (FRED)**")

    c1, c2 = st.columns(2)
    with c1:
        st.markdown("**10Y–2Y Yield Spread**")
        yc = fetch_yield_curve_history(120)
        if not yc.empty:
            fig = go.Figure()
            fig.add_trace(go.Scatter(
                x=yc.index, y=[round(float(v), 3) for v in yc.values],
                mode="lines", name="10Y-2Y",
                line=dict(color=COLORS["brent"], width=2),
                fill="tozeroy", fillcolor=_rgba(COLORS["brent"], 0.1)))
            fig.add_hline(y=0, line=dict(color=COLORS["bearish"], width=1.5, dash="dash"))
            _apply(fig, h=280)
            fig.update_layout(
                title=dict(text="Yield curve inversion (negative = recession signal)", font=dict(size=13)),
                yaxis_title="Spread (%)")
            st.plotly_chart(fig, use_container_width=True,
                            config={"displayModeBar":False}, key="yc_chart")
            latest_yc = float(yc.iloc[-1])
            color = COLORS["bearish"] if latest_yc < 0 else COLORS["bullish"]
            st.markdown(
                f'<div style="background:#1a2035;border:.5px solid {color};border-radius:8px;'
                f'padding:10px 14px;font-size:13px;color:{color};font-weight:600;">'
                f'Current: {latest_yc:+.2f}%  '
                f'{"⚠ Inverted — historical recession signal" if latest_yc < 0 else "✓ Normal"}'
                f'</div>', unsafe_allow_html=True)
        else:
            st.info("Yield curve — set FRED_KEY in .streamlit/secrets.toml")

    with c2:
        st.markdown("**Federal Funds Rate**")
        ff = fetch_fed_funds_history(60)
        if not ff.empty:
            fig = go.Figure(go.Scatter(
                x=ff.index, y=[round(float(v), 3) for v in ff.values],
                mode="lines+markers", name="Fed Funds",
                line=dict(color=COLORS["wti"], width=2), marker=dict(size=4)))
            _apply(fig, h=280)
            fig.update_layout(
                title=dict(text="Federal Funds rate", font=dict(size=13)),
                yaxis_title="Rate (%)")
            st.plotly_chart(fig, use_container_width=True,
                            config={"displayModeBar":False}, key="ff_chart")
            latest_ff = float(ff.iloc[-1])
            wti_col   = COLORS["wti"]
            ff_html   = (
                '<div style="background:#1a2035;border:.5px solid #2d3748;border-radius:8px;'
                'padding:10px 14px;font-size:13px;color:#e8e8e8;">'
                f'Current Fed Funds: <strong style="color:{wti_col};">{latest_ff:.2f}%</strong>'
                '</div>'
            )
            st.markdown(ff_html, unsafe_allow_html=True)
        else:
            st.info("Fed Funds — set FRED_KEY in .streamlit/secrets.toml")


def _geo_risk():
    st.markdown("**Key geopolitical risk factors for oil markets**")
    risk_factors = [
        {"country":"Iran",           "risk":"HIGH",  "lat":32.4,"lon":53.7,
         "drivers":"Nuclear programme, sanctions, Hormuz control","bbl_impact":"+$5–15/bbl"},
        {"country":"Saudi Arabia",   "risk":"MEDIUM","lat":23.9,"lon":45.1,
         "drivers":"OPEC+ compliance, output decisions","bbl_impact":"±$3–8/bbl"},
        {"country":"Russia",         "risk":"HIGH",  "lat":61.5,"lon":105.3,
         "drivers":"Ukraine war, G7 price cap, pipeline disruption","bbl_impact":"+$3–10/bbl"},
        {"country":"Libya",          "risk":"MEDIUM","lat":27.0,"lon":17.2,
         "drivers":"Political instability, force majeure risk","bbl_impact":"+$1–4/bbl"},
        {"country":"Nigeria",        "risk":"MEDIUM","lat":9.1, "lon":8.7,
         "drivers":"Pipeline theft, militant activity","bbl_impact":"+$1–3/bbl"},
        {"country":"Venezuela",      "risk":"LOW",   "lat":6.4, "lon":-66.6,
         "drivers":"US sanction waivers, production recovery","bbl_impact":"+1–2 mbbl/d"},
        {"country":"Yemen (Houthis)","risk":"HIGH",  "lat":15.6,"lon":48.5,
         "drivers":"Shipping attacks, tanker rerouting","bbl_impact":"+$2–6/bbl freight"},
        {"country":"Kazakhstan",     "risk":"MEDIUM","lat":48.0,"lon":66.9,
         "drivers":"CPC pipeline, Russia transit dependency","bbl_impact":"+$1–3/bbl"},
    ]
    risk_colors = {"HIGH":"#E24B4A","MEDIUM":"#EF9F27","LOW":"#1D9E75"}
    fig = go.Figure()
    for rf in risk_factors:
        color = risk_colors.get(rf["risk"], "#888780")
        hov   = (f"<b>{rf['country']}</b><br>Risk: {rf['risk']}<br>"
                 f"{rf['drivers']}<br><i>{rf['bbl_impact']}</i><extra></extra>")
        fig.add_trace(go.Scattergeo(
            lat=[rf["lat"]], lon=[rf["lon"]], mode="markers+text",
            text=[rf["country"].split("(")[0].strip()[:12]],
            textposition="top center", textfont=dict(size=9, color="#e8e8e8"),
            marker=dict(size=14 if rf["risk"]=="HIGH" else 10, color=color,
                        opacity=0.85, line=dict(color="#e8e8e8", width=1)),
            name=f"{rf['country']} ({rf['risk']})", hovertemplate=hov))
    fig.update_layout(
        paper_bgcolor="rgba(0,0,0,0)",
        geo=dict(showframe=False, showcoastlines=True, coastlinecolor="#2d3748",
                 landcolor="#1a2035", oceancolor="#0e1117", showocean=True,
                 showcountries=True, countrycolor="#2d3748", bgcolor="rgba(0,0,0,0)",
                 projection_type="natural earth"),
        height=420, margin=dict(l=0, r=0, t=20, b=0),
        legend=dict(bgcolor="rgba(14,17,23,0.85)", bordercolor="#2d3748",
                    font=dict(size=10, color="#e8e8e8"), x=0.01, y=0.99),
        title=dict(text="Oil market geopolitical risk map", font=dict(size=14, color="#e8e8e8")))
    st.plotly_chart(fig, use_container_width=True,
                    config={"displayModeBar":True}, key="geo_map")

    df_r = pd.DataFrame(risk_factors)[["country","risk","drivers","bbl_impact"]]
    df_r.columns = ["Country","Risk","Key drivers","$/bbl impact"]
    st.dataframe(df_r, use_container_width=True, hide_index=True)

"""
tabs/tab1b_seasonality.py — Phase 3: Fixed for all 3 products + yfinance fallback
"""
import streamlit as st
import plotly.graph_objects as go
import pandas as pd
import numpy as np
from datetime import datetime
from data.eia import fetch_seasonality_data, fetch_seasonality_product, SEASONALITY_SERIES
from config import COLORS


PRODUCT_COLORS = {
    "Gasoil / Distillates": COLORS["brent"],
    "Heating Oil":           COLORS["ho"],
    "RBOB Gasoline":         COLORS["rbob"],
}

PRODUCT_UNITS = {
    "Gasoil / Distillates": "Mbbl/d",
    "Heating Oil":           "Mbbl/d",
    "RBOB Gasoline":         "Mbbl/d",
}


def _apply(fig, h=420, m=None):
    m = m or dict(l=60, r=20, t=45, b=60)
    fig.update_layout(
        paper_bgcolor="rgba(0,0,0,0)", plot_bgcolor="rgba(0,0,0,0)",
        font=dict(color="#e8e8e8", size=12),
        xaxis=dict(gridcolor="#2d3748", linecolor="#2d3748", tickcolor="#a0aec0"),
        yaxis=dict(gridcolor="#2d3748", linecolor="#2d3748", tickcolor="#a0aec0"),
        legend=dict(bgcolor="rgba(0,0,0,0)", orientation="h", y=-0.18),
        hoverlabel=dict(bgcolor="#1e2738", font_color="#e8e8e8"),
        height=h, margin=m,
    )


def render_seasonality_tab():
    st.markdown("""
<p style="font-size:13px;color:#a0aec0;margin-bottom:12px;">
Seasonal demand patterns — last 10 years vs current year.
Source: EIA Weekly Petroleum Status Report (price proxy via yFinance if EIA API unavailable).
</p>""", unsafe_allow_html=True)

    # ── All 3 products side by side overview ──────────────────────────────────
    st.markdown("#### All products — Q1–Q4 10yr average")
    _render_all_products_overview()

    st.divider()

    # ── Detailed single product view ──────────────────────────────────────────
    st.markdown("#### Detailed product analysis")
    col1, col2 = st.columns([2, 2])
    with col1:
        selected = st.selectbox("Product", list(SEASONALITY_SERIES.keys()),
                                key="season_product")
    with col2:
        chart_type = st.selectbox("Chart type",
                                  ["Quarterly bars", "Weekly seasonality", "Monthly heatmap"],
                                  key="season_chart_type")

    with st.spinner(f"Loading {selected} data..."):
        df = fetch_seasonality_product(selected)

    if df.empty:
        st.warning(f"No data available for {selected}. Both EIA API and yFinance fallback returned empty.")
        return

    current_year  = datetime.now().year
    last_10_years = sorted([y for y in df["year"].unique() if y >= current_year - 10])

    is_price_proxy = df["value"].mean() < 20  # price in $/gal or $/bbl, not Mbbl/d
    unit_label = "$/unit (price proxy)" if is_price_proxy else "Mbbl/d"

    if chart_type == "Quarterly bars":
        _quarterly_bars(df, selected, current_year, last_10_years, unit_label)
    elif chart_type == "Weekly seasonality":
        _weekly_lines(df, selected, current_year, last_10_years, unit_label)
    else:
        _monthly_heatmap(df, selected, last_10_years)

    _stats_row(df, selected, current_year, unit_label)


def _render_all_products_overview():
    """Side-by-side quarterly bar charts for all 3 products."""
    cols = st.columns(3)
    current_year = datetime.now().year

    for col, product_name in zip(cols, SEASONALITY_SERIES.keys()):
        with col:
            with st.spinner(f"Loading {product_name}..."):
                df = fetch_seasonality_product(product_name)

            color = PRODUCT_COLORS.get(product_name, COLORS["brent"])

            if df.empty:
                st.markdown(f"""
<div style="background:#1a2035;border:.5px solid #2d3748;border-radius:8px;
     padding:16px;text-align:center;height:200px;display:flex;
     align-items:center;justify-content:center;">
  <div>
    <div style="font-size:13px;font-weight:600;color:#e8e8e8;">{product_name}</div>
    <div style="font-size:11px;color:#666;margin-top:6px;">Data unavailable</div>
  </div>
</div>""", unsafe_allow_html=True)
                continue

            hist = df[df["year"] < current_year]
            curr = df[df["year"] == current_year]
            q_avg = hist.groupby("quarter")["value"].mean()
            q_curr = curr.groupby("quarter")["value"].mean() if not curr.empty else pd.Series(dtype=float)
            q_names = {1:"Q1", 2:"Q2", 3:"Q3", 4:"Q4"}

            fig = go.Figure()
            if not q_avg.empty:
                fig.add_trace(go.Bar(
                    x=[q_names.get(int(q), f"Q{q}") for q in q_avg.index],
                    y=q_avg.round(2).tolist(),
                    name="10yr avg", marker_color=f"rgba(136,135,128,0.4)",
                    showlegend=False,
                ))
            if not q_curr.empty:
                fig.add_trace(go.Bar(
                    x=[q_names.get(int(q), f"Q{q}") for q in q_curr.index],
                    y=q_curr.round(2).tolist(),
                    name=str(current_year), marker_color=color,
                    showlegend=False,
                ))

            fig.update_layout(
                paper_bgcolor="rgba(0,0,0,0)", plot_bgcolor="rgba(0,0,0,0)",
                font=dict(color="#e8e8e8", size=11),
                height=200,
                margin=dict(l=35, r=10, t=30, b=30),
                barmode="overlay",
                xaxis=dict(gridcolor="#2d3748", linecolor="#2d3748"),
                yaxis=dict(gridcolor="#2d3748", linecolor="#2d3748"),
                title=dict(text=product_name, font=dict(size=12, color=color)),
            )
            st.plotly_chart(fig, use_container_width=True,
                            config={"displayModeBar": False}, key=f"overview_{product_name}")


def _quarterly_bars(df, product, current_year, years, unit_label):
    hist_df  = df[df["year"].isin(years)].copy()
    quarterly = hist_df.groupby(["year","quarter"])["value"].mean().reset_index()
    hist_only = quarterly[quarterly["year"] < current_year]
    curr_data = quarterly[quarterly["year"] == current_year]
    color     = PRODUCT_COLORS.get(product, COLORS["brent"])
    q_names   = {1:"Q1 (Jan-Mar)", 2:"Q2 (Apr-Jun)", 3:"Q3 (Jul-Sep)", 4:"Q4 (Oct-Dec)"}

    fig = go.Figure()
    hist_years = sorted(hist_only["year"].unique())
    for yr in hist_years:
        yd = hist_only[hist_only["year"] == yr].sort_values("quarter")
        if yd.empty: continue
        idx     = list(hist_years).index(yr)
        opacity = round(0.1 + idx / max(len(hist_years), 1) * 0.35, 2)
        fig.add_trace(go.Bar(
            x=[q_names.get(int(q), f"Q{q}") for q in yd["quarter"]],
            y=yd["value"].round(2).tolist(),
            name=str(int(yr)),
            marker_color=f"rgba(136,135,128,{opacity})",
            showlegend=bool(yr == hist_years[-1]),
            legendgroup="hist",
        ))

    if not curr_data.empty:
        yd = curr_data.sort_values("quarter")
        fig.add_trace(go.Bar(
            x=[q_names.get(int(q), f"Q{q}") for q in yd["quarter"]],
            y=yd["value"].round(2).tolist(),
            name=str(int(current_year)),
            marker_color=color, showlegend=True,
        ))

    avg = hist_only.groupby("quarter")["value"].mean()
    std = hist_only.groupby("quarter")["value"].std().fillna(0)
    qs  = sorted(avg.index)
    qx  = [q_names.get(int(q), f"Q{q}") for q in qs]

    fig.add_trace(go.Scatter(
        x=qx, y=[round(float(avg[q]), 2) for q in qs],
        name="10yr avg", mode="lines+markers",
        line=dict(color="#FFFFFF", width=2, dash="dash"), marker=dict(size=7),
    ))
    upper = [round(float(avg[q] + std[q]), 2) for q in qs]
    lower = [round(float(avg[q] - std[q]), 2) for q in qs]
    fig.add_trace(go.Scatter(
        x=qx + qx[::-1], y=upper + lower[::-1],
        fill="toself", fillcolor="rgba(55,138,221,0.07)",
        line=dict(color="rgba(0,0,0,0)"), name="±1σ band",
    ))

    _apply(fig, h=430)
    fig.update_layout(
        barmode="overlay",
        title=dict(text=f"{product} — quarterly demand ({unit_label})", font=dict(size=14)),
        xaxis_title="Quarter", yaxis_title=unit_label,
    )
    st.plotly_chart(fig, use_container_width=True, config={"displayModeBar": True}, key="t1b_seasonality_chart_2")


def _weekly_lines(df, product, current_year, years, unit_label):
    color   = PRODUCT_COLORS.get(product, COLORS["brent"])
    hist_df = df[df["year"].isin(years)].copy()
    fig     = go.Figure()

    for yr in sorted(hist_df["year"].unique()):
        yd = hist_df[hist_df["year"] == yr].sort_values("week")
        is_cur = bool(yr == current_year)
        fig.add_trace(go.Scatter(
            x=yd["week"].tolist(), y=yd["value"].round(2).tolist(),
            name=str(int(yr)), mode="lines",
            line=dict(color=color if is_cur else "rgba(136,135,128,0.2)",
                      width=2.5 if is_cur else 1),
        ))

    avg_w = hist_df[hist_df["year"] < current_year].groupby("week")["value"].mean()
    if not avg_w.empty:
        std_w = hist_df[hist_df["year"] < current_year].groupby("week")["value"].std().fillna(0)
        fig.add_trace(go.Scatter(
            x=avg_w.index.tolist(), y=avg_w.round(2).tolist(),
            name="10yr avg", mode="lines",
            line=dict(color="#FFFFFF", width=2, dash="dot"),
        ))
        # Seasonal band
        fig.add_trace(go.Scatter(
            x=avg_w.index.tolist() + avg_w.index.tolist()[::-1],
            y=(avg_w + std_w).round(2).tolist() + (avg_w - std_w).round(2).tolist()[::-1],
            fill="toself", fillcolor="rgba(55,138,221,0.07)",
            line=dict(color="rgba(0,0,0,0)"), name="±1σ band",
        ))

    for qw in [1, 14, 27, 40]:
        fig.add_vline(x=qw, line=dict(color="#2d3748", width=1, dash="dot"))
    for qn, qw in enumerate([7, 20, 33, 46], 1):
        fig.add_annotation(x=qw, y=0.02, text=f"Q{qn}", showarrow=False,
                           font=dict(color="#555", size=10), yref="paper")

    _apply(fig, h=420)
    fig.update_layout(
        title=dict(text=f"{product} — weekly seasonality ({unit_label})", font=dict(size=14)),
        xaxis_title="Week of year", yaxis_title=unit_label,
    )
    st.plotly_chart(fig, use_container_width=True, config={"displayModeBar": True}, key="t1b_seasonality_chart_3")


def _monthly_heatmap(df, product, years):
    hist_df     = df[df["year"].isin(years)].copy()
    hist_df["month"] = hist_df["date"].dt.month
    pivot = hist_df.groupby(["year","month"])["value"].mean().unstack()
    mnames = ["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"]
    pivot.columns = [mnames[int(m)-1] for m in pivot.columns]

    cs = {"Gasoil / Distillates": [[0,"#0e1117"],[1,"#378ADD"]],
          "Heating Oil":           [[0,"#0e1117"],[1,"#D85A30"]],
          "RBOB Gasoline":         [[0,"#0e1117"],[1,"#7F77DD"]]}.get(product, [[0,"#0e1117"],[1,"#378ADD"]])

    fig = go.Figure(go.Heatmap(
        z=pivot.values,
        x=pivot.columns.tolist(),
        y=[str(int(y)) for y in pivot.index.tolist()],
        colorscale=cs,
        hovertemplate="Year: %{y}<br>Month: %{x}<br>%{z:.2f}<extra></extra>",
        text=[[f"{v:.1f}" if not np.isnan(v) else "" for v in row] for row in pivot.values],
        texttemplate="%{text}", textfont={"size": 9},
    ))
    _apply(fig, h=360)
    fig.update_layout(title=dict(text=f"{product} — monthly heatmap", font=dict(size=14)))
    st.plotly_chart(fig, use_container_width=True, config={"displayModeBar": True}, key="t1b_seasonality_chart_4")


def _stats_row(df, product, current_year, unit_label):
    st.divider()
    df_c = df[df["year"] == current_year]
    df_h = df[(df["year"] >= current_year - 10) & (df["year"] < current_year)]
    if df_c.empty or df_h.empty:
        return
    ca  = float(df_c["value"].mean())
    ha  = float(df_h["value"].mean())
    hs  = float(df_h["value"].std())
    dev = ca - ha
    zs  = dev / hs if hs > 0 else 0
    cols = st.columns(4)
    cols[0].metric(f"{current_year} avg",     f"{ca:.2f}", unit_label)
    cols[1].metric("10yr historical avg",      f"{ha:.2f}", unit_label)
    cols[2].metric("YTD deviation from norm",  f"{dev:+.2f}", unit_label)
    cols[3].metric("Seasonal z-score",         f"{zs:+.2f}", "σ — above/below avg")

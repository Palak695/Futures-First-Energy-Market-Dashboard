"""
tabs/tab2_logistics.py — Futures curve, Crack spreads, WTI-Brent spread,
Tanker map + Freight rates + Demand indicators
"""
import streamlit as st
import plotly.graph_objects as go
from plotly.subplots import make_subplots
import pandas as pd
import numpy as np

from data.futures_curve import (fetch_futures_strip, fetch_price_history,
                                 classify_structure, PRODUCT_SOURCES, PRODUCT_LABELS)
from data.cracks import fetch_all_cracks, CRACK_DEFINITIONS
from data.spread import get_spread_history, get_spread_signal, fetch_live_spread
from data.tankers import (fetch_tanker_positions, dbscan_route_clusters,
                           get_chokepoint_risk_summary, get_route_display_data)
from data.demand_indicators import (fetch_freight_proxies, fetch_china_demand_proxies,
                                     fetch_airline_proxies, fetch_refinery_proxies)
from config import COLORS


def _apply(fig, h=380, m=None):
    m = m or dict(l=55, r=20, t=40, b=45)
    fig.update_layout(
        paper_bgcolor="rgba(0,0,0,0)", plot_bgcolor="rgba(0,0,0,0)",
        font=dict(color="#e8e8e8", size=12),
        xaxis=dict(gridcolor="#2d3748", linecolor="#2d3748", tickcolor="#a0aec0"),
        yaxis=dict(gridcolor="#2d3748", linecolor="#2d3748", tickcolor="#a0aec0"),
        legend=dict(bgcolor="rgba(0,0,0,0)"),
        hoverlabel=dict(bgcolor="#1e2738", font_color="#e8e8e8"),
        height=h, margin=m)


def _chg_color(v):
    return COLORS["bullish"] if v >= 0 else COLORS["bearish"]


def render_tab2():
    t1, t2, t3, t4, t5 = st.tabs([
        "📈 Futures curve",
        "⚗️ Crack spreads",
        "↔️ WTI–Brent spread",
        "🚢 Tanker map & freight",
        "📊 Demand indicators",
    ])
    with t1: _futures_curve()
    with t2: _crack_spreads()
    with t3: _spread()
    with t4: _tanker_and_freight()
    with t5: _demand_indicators()


# ── FUTURES CURVE ─────────────────────────────────────────────────────────────
def _futures_curve():
    col1, col2 = st.columns([1, 3])
    with col1:
        product   = st.selectbox("Product", ["Brent","WTI","HO","LGO","NG"],
                                  index=0, key="curve_product")
        show_hist = st.checkbox("Also show price history", value=False, key="curve_hist_toggle")

    src_info = PRODUCT_SOURCES.get(product, "")
    st.markdown(f'<div style="font-size:11px;color:#a0aec0;margin-bottom:8px;">'
                f'Data: <strong style="color:#378ADD;">{src_info}</strong></div>',
                unsafe_allow_html=True)

    with st.spinner(f"Fetching {product} futures strip..."):
        df_strip = fetch_futures_strip(product)

    if df_strip.empty:
        if product == "Brent":
            from data.local_data import load_lco_settle
            if load_lco_settle().empty:
                st.info("Run `python scripts/convert_to_parquet.py` with LCOSettle.csv "
                        "in raw_data/ to enable the Brent c1–c31 futures curve.")
            else:
                st.warning("LCOSettle loaded but no valid prices found.")
        else:
            st.info(f"{product} term structure — run converter to generate "
                    f"{product.lower()}_curve_daily.parquet from your CSV data.")
    else:
        prices   = df_strip["price"].tolist()
        labels   = df_strip["contract"].tolist()
        source   = df_strip["source"].iloc[0]
        date_lbl = df_strip["date"].iloc[0] if "date" in df_strip.columns else ""
        struct   = classify_structure(prices)

        fig = go.Figure()
        if "price_prev" in df_strip.columns:
            prev_p = df_strip["price_prev"].tolist()
            prev_d = df_strip["date_prev"].iloc[0] if "date_prev" in df_strip.columns else "Prior"
            if prev_p != prices:
                fig.add_trace(go.Scatter(
                    x=labels, y=[round(p,3) for p in prev_p],
                    mode="lines", name=f"Prior ({str(prev_d)[:10]})",
                    line=dict(color="#2d3748", width=1.5, dash="dot")))

        fig.add_trace(go.Scatter(
            x=labels, y=[round(p,3) for p in prices],
            mode="lines+markers",
            name=f"Latest{(' (' + str(date_lbl)[:10] + ')') if date_lbl else ''}",
            line=dict(color=struct["color"], width=2.5),
            marker=dict(size=6, color=struct["color"]),
            hovertemplate="<b>%{x}</b><br>$%{y:.3f}<extra></extra>"))

        _apply(fig, h=420, m=dict(l=60,r=30,t=50,b=50))
        fig.update_layout(
            title=dict(
                text=f"{PRODUCT_LABELS.get(product,product)} — {struct['structure']} · "
                     f"{struct['description']} · {source}",
                font=dict(size=13, color=struct["color"])),
            xaxis_title="Contract month", yaxis_title="Price ($/bbl)")
        st.plotly_chart(fig, use_container_width=True,
                        config={"displayModeBar":True}, key=f"curve_{product}")

        c1, c2, c3, c4 = st.columns(4)
        c1.metric("M1", f"${prices[0]:.3f}")
        if len(prices) > 1:
            roll = round(prices[0]-prices[1], 3)
            c2.metric("M1–M2 roll", f"${roll:+.3f}",
                      delta="Backwardation" if roll>0 else "Contango")
        if len(prices) > 1:
            c3.metric(f"M1–M{len(prices)} slope", f"${prices[-1]-prices[0]:+.3f}")
        c4.metric("Contracts", str(len(prices)))

    if show_hist:
        st.divider()
        st.markdown(f"**{product} price history (local data)**")
        df_h, label = fetch_price_history(product)
        if not df_h.empty:
            ts = "timestamp" if "timestamp" in df_h.columns else df_h.columns[0]
            cl = "close" if "close" in df_h.columns else \
                 next((c for c in df_h.columns if c != ts), None)
            if cl:
                dp = df_h[[ts,cl]].dropna().tail(504)
                fig2 = go.Figure()
                fig2.add_trace(go.Scatter(x=dp[ts], y=dp[cl].round(4),
                    mode="lines", name=label,
                    line=dict(color=COLORS["brent"],width=2),
                    fill="tozeroy", fillcolor="rgba(55,138,221,0.08)"))
                if len(dp) > 20:
                    fig2.add_trace(go.Scatter(x=dp[ts], y=dp[cl].rolling(20).mean().round(4),
                        mode="lines", name="MA20",
                        line=dict(color=COLORS["wti"],width=1.5,dash="dot")))
                _apply(fig2, h=300)
                fig2.update_layout(title=dict(text=f"{label} — price history",
                                              font=dict(size=13)), yaxis_title=label)
                st.plotly_chart(fig2, use_container_width=True,
                                config={"displayModeBar":True}, key=f"hist_{product}")
        else:
            st.info(f"No local data for {product}. Run the converter first.")


# ── CRACK SPREADS ─────────────────────────────────────────────────────────────
def _crack_spreads():
    with st.spinner("Calculating crack spreads..."):
        cracks = fetch_all_cracks()
    if not cracks:
        st.warning("Crack spread data unavailable — check yFinance connection."); return
    cols = st.columns(4)
    for col, (name, data) in zip(cols, cracks.items()):
        cur = data.get("current"); zs = data.get("zscore",0) or 0
        col.metric(name.split("(")[0].strip(),
                   f"${cur:.2f}" if cur else "–",
                   delta=f"Z: {zs:+.2f}σ" if cur else None)
    sel  = st.selectbox("Crack spread", list(CRACK_DEFINITIONS.keys()), key="crack_select")
    data = cracks.get(sel, {}); hist = data.get("history", pd.DataFrame())
    if hist.empty: st.caption(f"No history for {sel}"); return
    fig = go.Figure()
    fig.add_trace(go.Scatter(x=hist["date"], y=hist["crack"].round(2),
        mode="lines", name=sel, line=dict(color=COLORS["brent"],width=2),
        fill="tozeroy", fillcolor="rgba(55,138,221,0.08)"))
    if "ma20" in hist.columns:
        fig.add_trace(go.Scatter(x=hist["date"], y=hist["ma20"].round(2),
            mode="lines", name="MA20", line=dict(color=COLORS["wti"],width=1.5,dash="dot")))
    cur = data.get("current")
    if cur:
        fig.add_hline(y=cur, line=dict(color="#e8e8e8",width=1,dash="dot"),
                      annotation_text=f"Live: ${cur:.2f}", annotation_font_color="#e8e8e8")
    _apply(fig, h=360)
    fig.update_layout(title=dict(text=f"{sel} — {data.get('description','')}",font=dict(size=14)),
                      yaxis_title="Crack spread ($/bbl)")
    st.plotly_chart(fig, use_container_width=True, config={"displayModeBar":True}, key="crack_hist")
    if cur and data.get("high52") and data.get("low52"):
        c1,c2,c3,c4 = st.columns(4)
        c1.metric("Current",  f"${cur:.2f}"); c2.metric("52w high", f"${data['high52']:.2f}")
        c3.metric("52w low",  f"${data['low52']:.2f}"); c4.metric("Z-score", f"{data.get('zscore',0):+.2f}σ")


# ── WTI-BRENT SPREAD ─────────────────────────────────────────────────────────
def _spread():
    live   = fetch_live_spread()
    with st.spinner("Loading spread history..."):
        df = get_spread_history()
    signal = get_spread_signal(df)
    sc = signal["color"]
    st.markdown(f"""
<div style="background:#1a2035;border:1px solid {sc};border-radius:8px;
     padding:12px 16px;margin-bottom:12px;display:flex;
     justify-content:space-between;align-items:center;">
  <div>
    <div style="font-size:11px;color:#a0aec0;">Signal</div>
    <div style="font-size:14px;font-weight:600;color:{sc};">{signal['signal']}</div>
  </div>
  <div style="text-align:right;">
    <div style="font-size:11px;color:#a0aec0;">Z-score vs 60d avg</div>
    <div style="font-size:20px;font-weight:700;color:{sc};">{signal.get('zscore',0):+.2f}σ</div>
  </div>
</div>""", unsafe_allow_html=True)
    if df.empty:
        st.info("Spread history loading — run parquet converter or check yFinance."); return
    fig = make_subplots(rows=2, cols=1, shared_xaxes=True,
                        row_heights=[0.7,0.3], vertical_spacing=0.04)
    fig.add_trace(go.Scatter(x=df["date"],y=df["spread"].round(3),mode="lines",
        name="Brent–WTI",line=dict(color=COLORS["brent"],width=1.8),
        fill="tozeroy",fillcolor="rgba(55,138,221,0.08)"),row=1,col=1)
    if "roll60" in df.columns:
        fig.add_trace(go.Scatter(x=df["date"],y=df["roll60"].round(3),mode="lines",
            name="60d avg",line=dict(color="#888780",width=1,dash="dot")),row=1,col=1)
    if "zscore" in df.columns:
        zv = df["zscore"].round(3)
        fig.add_trace(go.Bar(x=df["date"],y=zv,name="Z-score",
            marker_color=["#E24B4A" if v>2 else "#1D9E75" if v<-2 else "#2d3748"
                          for v in zv]),row=2,col=1)
        fig.add_hline(y=2, line=dict(color="#E24B4A",width=1,dash="dot"),row=2,col=1)
        fig.add_hline(y=-2,line=dict(color="#1D9E75",width=1,dash="dot"),row=2,col=1)
    fig.update_layout(paper_bgcolor="rgba(0,0,0,0)",plot_bgcolor="rgba(0,0,0,0)",
        font=dict(color="#e8e8e8",size=12),height=440,margin=dict(l=55,r=20,t=40,b=45),
        legend=dict(bgcolor="rgba(0,0,0,0)"),hoverlabel=dict(bgcolor="#1e2738",font_color="#e8e8e8"),
        title=dict(text="Brent–WTI spread $/bbl (positive = Brent premium)",font=dict(size=14)))
    for ax in ["xaxis","xaxis2","yaxis","yaxis2"]:
        fig.update_layout(**{ax:dict(gridcolor="#2d3748",linecolor="#2d3748",tickcolor="#a0aec0")})
    st.plotly_chart(fig,use_container_width=True,config={"displayModeBar":True},key="spread_main")
    if live["valid"]:
        c1,c2,c3 = st.columns(3)
        c1.metric("Brent",f"${live['brent']:.3f}")
        c2.metric("WTI",  f"${live['wti']:.3f}")
        c3.metric("Spread",f"${live['spread']:+.3f}")


# ── TANKER MAP + FREIGHT ───────────────────────────────────────────────────────
def _tanker_and_freight():
    sub1, sub2 = st.tabs(["🗺️ Tanker routes", "📦 Freight rate proxies"])

    with sub1:
        routes = get_route_display_data(); chokes = get_chokepoint_risk_summary()
        risk_colors = {"HIGH":"#E24B4A","ELEVATED":"#EF9F27","MEDIUM":"#378ADD","LOW":"#1D9E75"}
        fig = go.Figure()
        for rid, route in routes.items():
            fig.add_trace(go.Scattergeo(
                lat=[route["from_lat"],route["to_lat"]],lon=[route["from_lon"],route["to_lon"]],
                mode="lines+markers",name=f"{rid}: {route['name']}",
                line=dict(width=2.5,color=route["color"]),marker=dict(size=6,color=route["color"]),
                hovertemplate=f"<b>{rid}</b><br>{route['name']}<extra></extra>"))
        for cp in chokes:
            color = risk_colors.get(cp["risk"],"#888780")
            fig.add_trace(go.Scattergeo(
                lat=[cp["lat"]],lon=[cp["lon"]],mode="markers+text",
                marker=dict(size=12,color=color,symbol="diamond",line=dict(color="#e8e8e8",width=1)),
                text=[cp["name"]],textposition="top center",
                textfont=dict(size=10,color="#e8e8e8"),
                name=f"{cp['name']} ({cp['risk']})",
                hovertemplate=f"<b>{cp['name']}</b><br>Risk: {cp['risk']}<extra></extra>"))
        fig.update_layout(paper_bgcolor="rgba(0,0,0,0)",
            geo=dict(showframe=False,showcoastlines=True,coastlinecolor="#2d3748",
                     landcolor="#1a2035",oceancolor="#0e1117",showocean=True,
                     showcountries=True,countrycolor="#2d3748",bgcolor="rgba(0,0,0,0)",
                     projection_type="natural earth"),
            height=480,margin=dict(l=0,r=0,t=30,b=0),
            legend=dict(bgcolor="rgba(14,17,23,0.85)",bordercolor="#2d3748",
                        font=dict(size=11,color="#e8e8e8")),
            title=dict(text="Crude oil tanker routes & chokepoint risk",
                       font=dict(size=14,color="#e8e8e8")))
        st.plotly_chart(fig,use_container_width=True,config={"displayModeBar":True},key="tanker_map")

        cols = st.columns(3)
        for i, cp in enumerate(chokes):
            color = risk_colors.get(cp["risk"],"#888780")
            with cols[i%3]:
                st.markdown(f"""
<div style="background:#1a2035;border:.5px solid #2d3748;border-left:3px solid {color};
     border-radius:7px;padding:8px 11px;margin-bottom:6px;">
  <div style="font-size:12px;font-weight:600;color:#e8e8e8;">{cp['name']}</div>
  <div style="font-size:11px;color:{color};font-weight:600;">{cp['risk']} RISK</div>
</div>""", unsafe_allow_html=True)

        with st.spinner("Checking live vessel positions..."):
            vessels = fetch_tanker_positions()
        if not vessels.empty:
            st.success(f"{len(vessels)} live tankers via MarineTraffic")
        else:
            st.info("Add MARINE_TRAFFIC_KEY to secrets.toml for live vessel positions.")

    with sub2:
        st.markdown("**Tanker & shipping stock proxies** — indicative freight market direction")
        st.caption("Direct Baltic Exchange rates require subscription. "
                   "These tanker/shipping stocks are free-tier proxies for freight trends.")

        period = st.radio("Period", ["3mo","6mo","1y"], index=1,
                          horizontal=True, key="freight_period")

        with st.spinner("Loading freight proxies..."):
            freight = fetch_freight_proxies(period=period)

        if not freight:
            st.info("Freight proxies loading — check yFinance connection."); return

        # Summary cards
        cols = st.columns(min(len(freight), 5))
        for col, (name, data) in zip(cols, freight.items()):
            c  = COLORS["bullish"] if data["bullish"] else COLORS["bearish"]
            ar = "▲" if data["bullish"] else "▼"
            col.markdown(f"""
<div style="background:#1a2035;border:.5px solid #2d3748;border-left:3px solid {c};
     border-radius:7px;padding:8px 10px;text-align:center;">
  <div style="font-size:10px;color:#a0aec0;">{name.split('(')[0].strip()}</div>
  <div style="font-size:14px;font-weight:700;color:{c};">${data['current']:.2f}</div>
  <div style="font-size:11px;color:{c};">{ar}{abs(data['chg_pct']):.1f}%</div>
  <div style="font-size:10px;color:#666;">3M: {data['ret_3m']:+.1f}%</div>
</div>""", unsafe_allow_html=True)

        # Combined price chart
        st.markdown("**Normalised performance (rebased to 100)**")
        fig = go.Figure()
        colors_cycle = [COLORS["brent"], COLORS["wti"], "#5DCAA5", "#EF9F27", "#7F77DD"]
        for i, (name, data) in enumerate(freight.items()):
            s = data["history"]
            if s.empty: continue
            norm = (s / s.iloc[0] * 100).round(2)
            fig.add_trace(go.Scatter(
                x=norm.index, y=norm.values,
                name=name.split("(")[0].strip(),
                mode="lines", line=dict(color=colors_cycle[i % len(colors_cycle)], width=1.8)))
        fig.add_hline(y=100, line=dict(color="#2d3748", width=1, dash="dot"))
        _apply(fig, h=340)
        fig.update_layout(
            title=dict(text="Tanker/shipping stocks — normalised (base=100 at period start)",
                       font=dict(size=13)),
            yaxis_title="Rebased price (100 = period start)")
        st.plotly_chart(fig, use_container_width=True,
                        config={"displayModeBar":True}, key="freight_chart")

        st.markdown("**Freight market context**")
        context_cols = st.columns(3)
        context_cols[0].markdown("""
**VLCC (Very Large Crude Carriers)**
- Frontline (FRO) is the world's largest VLCC operator
- Rising FRO price → higher tanker rates → tighter physical crude market
- Key routes: Middle East → Asia, WAfrica → US Gulf""")
        context_cols[1].markdown("""
**Product tankers**
- Scorpio Tankers (STNG) carries refined products
- Rising STNG → higher product freight → wider crack spreads
- Key routes: Europe ↔ US, Middle East → Asia""")
        context_cols[2].markdown("""
**Baltic Dry Index proxy**
- ZIM/Danaos proxy for container shipping sentiment
- Dry bulk rates correlate with industrial commodity demand
- Rising rates → stronger global trade activity""")


# ── DEMAND INDICATORS ─────────────────────────────────────────────────────────
def _demand_indicators():
    st.markdown("**Global oil demand indicators**")
    st.caption("Proxy indicators using publicly available market data. "
               "Direct data (IEA, JODI) requires subscription.")

    period = st.radio("Period", ["3mo","6mo","1y","2y"], index=2,
                       horizontal=True, key="demand_period")

    sub1, sub2, sub3 = st.tabs([
        "🇨🇳 China demand",
        "✈️ Aviation / jet fuel",
        "🏭 Refinery throughput",
    ])

    with sub1:
        _china_demand_tab(period)

    with sub2:
        _aviation_tab(period)

    with sub3:
        _refinery_tab(period)


def _china_demand_tab(period):
    st.markdown("**China demand proxies — ETFs & large-cap stocks**")
    st.caption("China crude imports ~16 mbbl/d (2024). "
               "MCHI/FXI ETFs track broader Chinese economic activity "
               "which correlates strongly with crude import demand.")

    with st.spinner("Loading China proxies..."):
        china = fetch_china_demand_proxies(period=period)

    if not china:
        st.info("China proxies loading — check yFinance connection."); return

    cols = st.columns(min(len(china), 3))
    for col, (name, data) in zip(cols, china.items()):
        c  = COLORS["bullish"] if data["bullish"] else COLORS["bearish"]
        ar = "▲" if data["bullish"] else "▼"
        col.markdown(f"""
<div style="background:#1a2035;border:.5px solid #2d3748;border-left:3px solid {c};
     border-radius:7px;padding:10px 12px;margin-bottom:8px;">
  <div style="font-size:10px;color:#a0aec0;">{name}</div>
  <div style="font-size:16px;font-weight:700;color:{c};">${data['current']:.2f}</div>
  <div style="font-size:12px;color:{c};">{ar}{abs(data['chg_pct']):.2f}% today</div>
  <div style="font-size:11px;color:#666;">3M: {data['ret_3m']:+.1f}% · 1Y: {data['ret_1y']:+.1f}%</div>
</div>""", unsafe_allow_html=True)

    _normalised_chart(china, "China demand proxies — normalised performance", "china_chart")

    st.markdown("**China crude import context**")
    st.markdown("""
| Indicator | Latest trend | Oil demand signal |
|---|---|---|
| MCHI rising | Stronger Chinese economy | 🟢 Bullish crude demand |
| MCHI falling | Economic slowdown | 🔴 Bearish crude demand |
| BABA/JD rising | Consumer recovery | 🟡 Lagging indicator |
| CNY strengthening | Import purchasing power up | 🟢 Mildly bullish |
""")


def _aviation_tab(period):
    st.markdown("**Aviation sector — jet fuel demand proxy**")
    st.caption("Jet fuel = ~7% of global oil demand. "
               "Airline stock performance is a leading indicator for jet fuel consumption.")

    with st.spinner("Loading airline proxies..."):
        airlines = fetch_airline_proxies(period=period)

    if not airlines:
        st.info("Airline proxies loading — check yFinance connection."); return

    cols = st.columns(min(len(airlines), 5))
    for col, (name, data) in zip(cols, airlines.items()):
        c  = COLORS["bullish"] if data["bullish"] else COLORS["bearish"]
        ar = "▲" if data["bullish"] else "▼"
        col.markdown(f"""
<div style="background:#1a2035;border:.5px solid #2d3748;border-left:3px solid {c};
     border-radius:7px;padding:8px 10px;text-align:center;">
  <div style="font-size:10px;color:#a0aec0;">{name}</div>
  <div style="font-size:14px;font-weight:700;color:{c};">${data['current']:.2f}</div>
  <div style="font-size:11px;color:{c};">{ar}{abs(data['chg_pct']):.2f}%</div>
  <div style="font-size:10px;color:#666;">3M: {data['ret_3m']:+.1f}%</div>
</div>""", unsafe_allow_html=True)

    _normalised_chart(airlines, "Airline stocks — normalised performance", "airline_chart")

    st.info("**Interpretation:** Rising airline stocks → improving travel demand → "
            "higher jet fuel consumption → bullish for refinery distillate runs. "
            "Most reliable when consistent across US, European, and Asian carriers.")


def _refinery_tab(period):
    st.markdown("**Refinery throughput proxy — major refinery stocks**")
    st.caption("Refinery margins (crack spreads) directly affect throughput levels. "
               "Refinery stock performance tracks operational profitability.")

    with st.spinner("Loading refinery proxies..."):
        refiners = fetch_refinery_proxies(period=period)

    if not refiners:
        st.info("Refinery proxies loading — check yFinance connection."); return

    cols = st.columns(min(len(refiners), 4))
    for col, (name, data) in zip(cols, refiners.items()):
        c  = COLORS["bullish"] if data["bullish"] else COLORS["bearish"]
        ar = "▲" if data["bullish"] else "▼"
        col.markdown(f"""
<div style="background:#1a2035;border:.5px solid #2d3748;border-left:3px solid {c};
     border-radius:7px;padding:8px 10px;text-align:center;">
  <div style="font-size:10px;color:#a0aec0;">{name}</div>
  <div style="font-size:14px;font-weight:700;color:{c};">${data['current']:.2f}</div>
  <div style="font-size:11px;color:{c};">{ar}{abs(data['chg_pct']):.2f}%</div>
  <div style="font-size:10px;color:#666;">3M: {data['ret_3m']:+.1f}%</div>
</div>""", unsafe_allow_html=True)

    _normalised_chart(refiners, "Refinery stocks — normalised performance", "refinery_chart")



def _normalised_chart(data_dict: dict, title: str, key: str):
    """Shared normalised performance chart for any proxy dict."""
    fig = go.Figure()
    colors_c = [COLORS["brent"], COLORS["wti"], "#5DCAA5", "#EF9F27", "#7F77DD", "#D85A30"]
    for i, (name, data) in enumerate(data_dict.items()):
        s = data.get("history", pd.Series(dtype=float))
        if s.empty or len(s) < 2: continue
        norm = (s / s.iloc[0] * 100).round(2)
        short_name = name.split("(")[0].strip()
        fig.add_trace(go.Scatter(
            x=norm.index, y=norm.values,
            name=short_name, mode="lines",
            line=dict(color=colors_c[i % len(colors_c)], width=1.8),
            hovertemplate=f"<b>{short_name}</b><br>%{{y:.1f}}<extra></extra>"))
    fig.add_hline(y=100, line=dict(color="#2d3748", width=1, dash="dot"))
    _apply(fig, h=320)
    fig.update_layout(
        title=dict(text=title, font=dict(size=13)),
        yaxis_title="Rebased (100 = period start)")
    st.plotly_chart(fig, use_container_width=True,
                    config={"displayModeBar":True}, key=key)

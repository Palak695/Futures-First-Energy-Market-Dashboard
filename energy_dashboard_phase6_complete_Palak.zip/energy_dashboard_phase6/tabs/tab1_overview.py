"""
tabs/tab1_overview.py — Single-screen layout with scrollable panels.
Correlation panel shows heatmap + macro indicators (yield curve, Fed Funds, COT signals).
"""
import streamlit as st
import plotly.graph_objects as go
import pandas as pd
import numpy as np
from datetime import datetime

from data.prices import fetch_prices, fetch_correlation_data
from data.news import fetch_news, time_ago
from data.eia import fetch_inventory_data
from data.fred import fetch_yield_curve_history, fetch_fed_funds_history
from data.cot import fetch_cot_data, get_cot_signal
from analytics.technicals import compute_indicators, compute_correlation_matrix, INDICATOR_TICKERS
from analytics.sentiment import score_headlines, aggregate_sentiment
from analytics.bias import get_ensemble_bias
from analytics.alerts import generate_alerts
from components.tradingview import render_tradingview_chart, tradingview_symbol_selector
from components.news_card import render_news_feed, render_sentiment_gauge, render_sentiment_breakdown
from components.events_panel import render_events_calendar, render_event_impact_legend
from components.bias_panel import render_bias_panel, render_alerts_panel
from config import COLORS


def _rgba(h, a=0.13):
    h = h.lstrip("#")
    return f"rgba({int(h[0:2],16)},{int(h[2:4],16)},{int(h[4:6],16)},{a})"


def _apply(fig, h=260, m=None):
    m = m or dict(l=50, r=20, t=30, b=30)
    fig.update_layout(
        paper_bgcolor="rgba(0,0,0,0)", plot_bgcolor="rgba(0,0,0,0)",
        font=dict(color="#e8e8e8", size=12),
        xaxis=dict(gridcolor="#2d3748", linecolor="#2d3748", tickcolor="#a0aec0"),
        yaxis=dict(gridcolor="#2d3748", linecolor="#2d3748", tickcolor="#a0aec0"),
        legend=dict(bgcolor="rgba(0,0,0,0)"),
        hoverlabel=dict(bgcolor="#1e2738", font_color="#e8e8e8"),
        height=h, margin=m)


@st.fragment(run_every=30)
def render_price_header():
    prices = fetch_prices()
    if not prices:
        st.warning("Price data unavailable — retrying..."); return
    st.markdown(
        f'<p style="font-size:11px;color:#666;text-align:right;margin-bottom:2px;">'
        f'Updated: {datetime.now().strftime("%H:%M:%S")} · 15min delayed</p>',
        unsafe_allow_html=True)
    cols = st.columns(len(prices))
    for col, (name, data) in zip(cols, prices.items()):
        price  = data["price"]; chg_pct = data["change_pct"]
        bullish= data["bullish"]; spark  = data["sparkline"]
        color  = COLORS["bullish"] if bullish else COLORS["bearish"]
        arrow  = "▲" if bullish else "▼"
        with col:
            if spark and len(spark) >= 3:
                mn,mx = min(spark),max(spark)
                yr = [mn-(mx-mn)*0.2,mx+(mx-mn)*0.2] if mx!=mn else [mn*0.999,mn*1.001]
                fig = go.Figure(go.Scatter(y=spark, mode="lines",
                    line=dict(color=color, width=1.5),
                    fill="tozeroy", fillcolor=_rgba(color,0.15)))
                fig.update_layout(height=48, margin=dict(l=0,r=0,t=2,b=2),
                    paper_bgcolor="rgba(0,0,0,0)", plot_bgcolor="rgba(0,0,0,0)",
                    xaxis=dict(visible=False, fixedrange=True),
                    yaxis=dict(visible=False, fixedrange=True, range=yr),
                    showlegend=False)
                st.plotly_chart(fig, use_container_width=True,
                                config={"displayModeBar":False,"staticPlot":True},
                                key=f"spark_{name}")
            st.markdown(f"""
<div style="text-align:center;margin-top:-8px;">
  <div style="font-size:11px;color:#a0aec0;font-weight:500;">{name}</div>
  <div style="font-size:16px;font-weight:700;color:{color};">{price:,.3f}</div>
  <div style="font-size:12px;color:{color};">{arrow} {abs(chg_pct):.2f}%</div>
</div>""", unsafe_allow_html=True)


def _left_panel():
    sel    = st.selectbox("Instrument", list(INDICATOR_TICKERS.keys()),
                          key="ind_ticker", label_visibility="collapsed")
    ticker = INDICATOR_TICKERS[sel]

    with st.spinner("Running ML models..."):
        bias_data = get_ensemble_bias(ticker)
    render_bias_panel(bias_data)

    with st.expander("Technical indicators", expanded=False):
        ind = bias_data.get("tech") or compute_indicators(ticker)
        if ind:
            def _f(v, fmt=".2f"):
                if v is None: return "–"
                try: return format(float(v), fmt)
                except: return str(v)
            def _rsi_l(r):
                if r is None: return "–"
                if r>70: return "Overbought ⚠️"
                if r<30: return "Oversold ⚡"
                return "Bullish" if r>55 else "Bearish" if r<45 else "Neutral"
            rows = [
                ("RSI 14",    _f(ind.get("rsi"),".1f"),            _rsi_l(ind.get("rsi"))),
                ("MACD",      _f(ind.get("macd_hist"),".4f"),       str(ind.get("macd_cross","–")).title()),
                ("BB %B",     _f(ind.get("bb_pct"),".1f")+"%",      str(ind.get("bb_signal","–")).title()),
                ("ATR",       _f(ind.get("atr"),".3f"),             _f(ind.get("atr_pct"),".2f")+"% of px"),
                ("EMA 20",    _f(ind.get("ema20"),".2f"),           "–"),
                ("EMA 50",    _f(ind.get("ema50"),".2f"),           "–"),
                ("Trend",     ind.get("trend","–").replace("_"," ").title(), "–"),
            ]
            c1, c2 = st.columns(2)
            for i, (lbl, val, ex) in enumerate(rows):
                with (c1 if i%2==0 else c2):
                    st.markdown(f"""
<div style="background:#0e1117;border:.5px solid #2d3748;border-radius:6px;
     padding:7px 9px;margin-bottom:5px;">
  <div style="font-size:10px;color:#a0aec0;">{lbl}</div>
  <div style="font-size:13px;font-weight:600;color:#e8e8e8;">{val}</div>
  <div style="font-size:10px;color:#666;">{ex}</div>
</div>""", unsafe_allow_html=True)

    st.markdown("**🔔 Live Alerts**")
    with st.spinner("Scanning..."):
        alerts = generate_alerts({"Brent":"BZ=F","WTI":"CL=F","Nat Gas":"NG=F"})
    render_alerts_panel(alerts)

    st.markdown("**🛢️ Inventory**")
    _inventory_panel()

    st.markdown("**📅 Key Events**")
    render_event_impact_legend()
    render_events_calendar(compact=True)


@st.fragment(run_every=3600)
def _inventory_panel():
    with st.spinner("Loading EIA..."):
        data = fetch_inventory_data()
    if not data:
        st.caption("EIA inventory loading — check FRED_KEY or EIA_KEY."); return
    shown = False
    for product, info in data.items():
        if info.get("current") is None: continue
        shown  = True
        change = info.get("change") or 0
        cc     = COLORS["bearish"] if change > 0 else COLORS["bullish"]
        arrow  = "▲" if change > 0 else "▼"
        st.markdown(f"""
<div style="background:#1a2035;border:.5px solid #2d3748;border-left:3px solid {cc};
     border-radius:7px;padding:8px 11px;margin-bottom:5px;">
  <div style="display:flex;justify-content:space-between;">
    <div>
      <div style="font-size:11px;color:#a0aec0;">{product}</div>
      <div style="font-size:14px;font-weight:700;color:#e8e8e8;">{info['current']:,.1f} Mbbl</div>
    </div>
    <div style="text-align:right;">
      <div style="font-size:12px;color:{cc};font-weight:600;">{arrow}{abs(change):.1f}M WoW</div>
      <div style="font-size:10px;color:#555;">{info.get('date','')}</div>
    </div>
  </div>
</div>""", unsafe_allow_html=True)
    if not shown:
        st.caption("EIA data loading...")


@st.fragment(run_every=120)
def _right_panel():
    news = fetch_news(max_items=15)
    if not news:
        st.caption("No news — check NEWS_API_KEY."); return
    with st.spinner("FinBERT scoring..."):
        scored = score_headlines(news)
    for item in scored:
        item["time_ago"] = time_ago(item["published"])
    gauge = aggregate_sentiment(scored)
    render_sentiment_gauge(gauge)
    with st.expander("By category", expanded=False):
        render_sentiment_breakdown(scored)
    render_news_feed(scored, max_display=15)


@st.fragment(run_every=3600)
def _center_panel_bottom():
    """Correlation heatmap + macro & COT indicators below the TV chart."""
    st.markdown("**📊 Market correlations & macro factors**")

    # ── Correlation heatmap ──────────────────────────────────────────────────
    window = st.select_slider("Rolling window", [30,60,90,120,252], value=60,
                               key="corr_window", label_visibility="collapsed")
    df_c = fetch_correlation_data()
    if not df_c.empty:
        corr = compute_correlation_matrix(df_c, window=window)
        if not corr.empty:
            fig = go.Figure(go.Heatmap(
                z=corr.values, x=corr.columns.tolist(), y=corr.index.tolist(),
                colorscale=[[0,"#E24B4A"],[0.5,"#2d3748"],[1,"#1D9E75"]],
                zmin=-1, zmax=1, text=corr.round(2).values,
                texttemplate="%{text}", textfont={"size":10},
                hovertemplate="%{y} vs %{x}: %{z:.3f}<extra></extra>"))
            _apply(fig, h=240, m=dict(l=65,r=10,t=20,b=65))
            fig.update_layout(title=dict(text=f"Rolling {window}d correlations",
                                         font=dict(size=12)))
            st.plotly_chart(fig, use_container_width=True,
                            config={"displayModeBar":False},
                            key="corr_heatmap_tab1")

    # ── Macro indicators row ──────────────────────────────────────────────────
    st.markdown("**🌐 Macro indicators**")
    mc1, mc2, mc3, mc4 = st.columns(4)

    # Yield curve
    try:
        yc = fetch_yield_curve_history(periods=5)
        if not yc.empty:
            val = float(yc.iloc[-1])
            color = COLORS["bearish"] if val < 0 else COLORS["bullish"]
            mc1.markdown(f"""
<div style="background:#1a2035;border:.5px solid #2d3748;border-left:3px solid {color};
     border-radius:7px;padding:8px 11px;">
  <div style="font-size:10px;color:#a0aec0;">10Y–2Y Yield Spread</div>
  <div style="font-size:16px;font-weight:700;color:{color};">{val:+.2f}%</div>
  <div style="font-size:10px;color:{color};">{'⚠ Inverted' if val<0 else '✓ Normal'}</div>
</div>""", unsafe_allow_html=True)
        else:
            mc1.markdown(_macro_card("10Y–2Y Spread","–","Set FRED_KEY"), unsafe_allow_html=True)
    except Exception:
        mc1.markdown(_macro_card("10Y–2Y Spread","–","Unavailable"), unsafe_allow_html=True)

    # Fed Funds
    try:
        ff = fetch_fed_funds_history(periods=3)
        if not ff.empty:
            val  = float(ff.iloc[-1])
            prev = float(ff.iloc[-2]) if len(ff) > 1 else val
            chg  = val - prev
            color = COLORS["bearish"] if chg > 0 else COLORS["bullish"] if chg < 0 else "#a0aec0"
            mc2.markdown(f"""
<div style="background:#1a2035;border:.5px solid #2d3748;border-left:3px solid {color};
     border-radius:7px;padding:8px 11px;">
  <div style="font-size:10px;color:#a0aec0;">Fed Funds Rate</div>
  <div style="font-size:16px;font-weight:700;color:#e8e8e8;">{val:.2f}%</div>
  <div style="font-size:10px;color:{color};">{'▲' if chg>0 else '▼' if chg<0 else '–'} {abs(chg):.2f}%</div>
</div>""", unsafe_allow_html=True)
        else:
            mc2.markdown(_macro_card("Fed Funds","–","Set FRED_KEY"), unsafe_allow_html=True)
    except Exception:
        mc2.markdown(_macro_card("Fed Funds","–","Unavailable"), unsafe_allow_html=True)

    # COT WTI
    try:
        cot_wti, _ = fetch_cot_data("WTI")
        if not cot_wti.empty:
            sig = get_cot_signal(cot_wti)
            date_str = cot_wti["date"].iloc[-1].strftime("%b %d") if not cot_wti.empty else ""
            mc3.markdown(f"""
<div style="background:#1a2035;border:.5px solid #2d3748;border-left:3px solid {sig['color']};
     border-radius:7px;padding:8px 11px;">
  <div style="font-size:10px;color:#a0aec0;">COT WTI · {date_str}</div>
  <div style="font-size:13px;font-weight:700;color:{sig['color']};">{sig['signal']}</div>
  <div style="font-size:10px;color:#a0aec0;">{sig['percentile']:.0f}th pct · Net: {sig['net']:+,}</div>
</div>""", unsafe_allow_html=True)
        else:
            mc3.markdown(_macro_card("COT WTI","–","cftc.gov (Fridays)"), unsafe_allow_html=True)
    except Exception:
        mc3.markdown(_macro_card("COT WTI","–","Unavailable"), unsafe_allow_html=True)

    # COT Brent
    try:
        cot_brent, _ = fetch_cot_data("Brent")
        if not cot_brent.empty:
            sig = get_cot_signal(cot_brent)
            date_str = cot_brent["date"].iloc[-1].strftime("%b %d") if not cot_brent.empty else ""
            mc4.markdown(f"""
<div style="background:#1a2035;border:.5px solid #2d3748;border-left:3px solid {sig['color']};
     border-radius:7px;padding:8px 11px;">
  <div style="font-size:10px;color:#a0aec0;">COT Brent · {date_str}</div>
  <div style="font-size:13px;font-weight:700;color:{sig['color']};">{sig['signal']}</div>
  <div style="font-size:10px;color:#a0aec0;">{sig['percentile']:.0f}th pct · Net: {sig['net']:+,}</div>
</div>""", unsafe_allow_html=True)
        else:
            mc4.markdown(_macro_card("COT Brent","–","cftc.gov (Fridays)"), unsafe_allow_html=True)
    except Exception:
        mc4.markdown(_macro_card("COT Brent","–","Unavailable"), unsafe_allow_html=True)


def _macro_card(label: str, value: str, note: str) -> str:
    return (f'<div style="background:#1a2035;border:.5px solid #2d3748;border-radius:7px;'
            f'padding:8px 11px;">'
            f'<div style="font-size:10px;color:#a0aec0;">{label}</div>'
            f'<div style="font-size:16px;font-weight:700;color:#555;">{value}</div>'
            f'<div style="font-size:10px;color:#555;">{note}</div>'
            f'</div>')


def render_tab1():
    st.markdown("""
<style>
section[data-testid="stMain"] > div > div > div > div[data-testid="column"]:first-child {
    height: calc(100vh - 155px) !important;
    overflow-y: auto !important; overflow-x: hidden !important;
    padding-right: 6px; scrollbar-width: thin; scrollbar-color: #2d3748 transparent;
}
section[data-testid="stMain"] > div > div > div > div[data-testid="column"]:last-child {
    height: calc(100vh - 155px) !important;
    overflow-y: auto !important; overflow-x: hidden !important;
    padding-right: 4px; scrollbar-width: thin; scrollbar-color: #2d3748 transparent;
}
[data-testid="metric-container"]>div{background:#1a2035;border-radius:8px;padding:10px;}
[data-testid="stMetricValue"]{font-size:18px !important;}
h4{font-size:14px !important;color:#e8e8e8 !important;margin-bottom:6px !important;}
.streamlit-expanderHeader{font-size:13px !important;}
</style>""", unsafe_allow_html=True)

    render_price_header()
    st.divider()

    col_left, col_center, col_right = st.columns([1, 2.5, 1.2])

    with col_left:
        _left_panel()

    with col_center:
        symbol, interval = tradingview_symbol_selector()
        render_tradingview_chart(symbol=symbol, interval=interval, height=450)
        _center_panel_bottom()

    with col_right:
        _right_panel()

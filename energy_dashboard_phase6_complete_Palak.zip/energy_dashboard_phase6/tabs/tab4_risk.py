"""tabs/tab4_risk.py — Vol & GARCH, Fair value, Correlations, Options & OVX (COT removed)"""
import streamlit as st
import plotly.graph_objects as go
import pandas as pd
import numpy as np
import yfinance as yf

from data.prices import fetch_ohlcv, fetch_correlation_data
from analytics.technicals import compute_correlation_matrix
from analytics.volatility import compute_realized_vol, fit_garch, get_vol_regime
from analytics.fair_value import compute_fair_value
from config import COLORS


def _apply(fig, h=300, m=None):
    m = m or dict(l=55, r=20, t=40, b=45)
    fig.update_layout(
        paper_bgcolor="rgba(0,0,0,0)", plot_bgcolor="rgba(0,0,0,0)",
        font=dict(color="#e8e8e8", size=12),
        xaxis=dict(gridcolor="#2d3748", linecolor="#2d3748", tickcolor="#a0aec0"),
        yaxis=dict(gridcolor="#2d3748", linecolor="#2d3748", tickcolor="#a0aec0"),
        legend=dict(bgcolor="rgba(0,0,0,0)"),
        hoverlabel=dict(bgcolor="#1e2738", font_color="#e8e8e8"),
        height=h, margin=m)


def _rgba(h, a=0.12):
    h = h.lstrip("#")
    return f"rgba({int(h[0:2],16)},{int(h[2:4],16)},{int(h[4:6],16)},{a})"


def _strip_tz(s):
    try:
        if hasattr(s.index, "tz") and s.index.tz:
            s = s.copy(); s.index = s.index.tz_convert(None)
    except Exception: pass
    return s


def render_tab4():
    t1, t2, t3, t4 = st.tabs([
        "📊 Vol & GARCH",
        "💎 Fair value",
        "🔗 Correlations",
        "📈 Options & OVX",
    ])
    with t1: _vol_tab()
    with t2: _fair_value_tab()
    with t3: _corr_tab()
    with t4: _options_tab()


def _vol_tab():
    col1, _ = st.columns([1, 3])
    with col1:
        ticker_map = {"Brent":"BZ=F","WTI":"CL=F","Nat Gas":"NG=F","HO":"HO=F"}
        sel    = st.selectbox("Asset", list(ticker_map.keys()), key="vol_asset")
        ticker = ticker_map[sel]

    with st.spinner(f"Running GARCH for {sel}..."):
        vol_data  = compute_realized_vol(ticker, windows=[10,20,60])
        garch_res = fit_garch(ticker)
        regime    = get_vol_regime(ticker)

    rc = regime["color"]
    st.markdown(f"""
<div style="background:#1a2035;border:1px solid {rc};border-radius:8px;
     padding:12px 16px;margin-bottom:12px;display:flex;
     justify-content:space-between;align-items:center;">
  <div>
    <div style="font-size:11px;color:#a0aec0;">Volatility regime</div>
    <div style="font-size:22px;font-weight:700;color:{rc};">{regime['regime']}</div>
    <div style="font-size:11px;color:#a0aec0;">{regime.get('vol_pct',0):.0f}th pct · 2yr</div>
  </div>
  <div style="text-align:right;">
    <div style="font-size:11px;color:#a0aec0;">20d vol (ann.)</div>
    <div style="font-size:24px;font-weight:700;color:{rc};">{regime.get('current_vol',0):.1f}%</div>
    <div style="font-size:11px;color:#a0aec0;">
      Mean:{regime.get('vol_mean',0):.1f}% P25:{regime.get('vol_p25',0):.1f}% P75:{regime.get('vol_p75',0):.1f}%
    </div>
  </div>
</div>""", unsafe_allow_html=True)

    if garch_res.get("forecast_1d"):
        gc = st.columns(4)
        gc[0].metric("GARCH 1d",  f"{garch_res['forecast_1d']:.1f}%")
        gc[1].metric("GARCH 5d",  f"{garch_res['forecast_5d']:.1f}%")
        p = garch_res.get("params", {})
        if p:
            gc[2].metric("α shock",   f"{p.get('alpha',0):.4f}")
            gc[3].metric("β persist.",f"{p.get('beta',0):.4f}")

    if vol_data.empty:
        st.info("Insufficient price history."); return

    fig = go.Figure()
    for w, color in {10:COLORS["brent"], 20:COLORS["wti"], 60:"#5DCAA5"}.items():
        col = f"vol_{w}d"
        if col not in vol_data.columns: continue
        fig.add_trace(go.Scatter(
            x=vol_data["date"], y=vol_data[col].round(2),
            name=f"{w}d vol", mode="lines",
            line=dict(color=color, width=2 if w==20 else 1.5)))
    cond = garch_res.get("conditional_vol")
    if cond is not None and not cond.empty:
        fig.add_trace(go.Scatter(
            x=cond.index, y=cond.round(2).values,
            name="GARCH cond.", mode="lines",
            line=dict(color="#888780", width=1.5, dash="dot")))
    fc = garch_res.get("forecast_1d")
    if fc and not vol_data.empty:
        fig.add_trace(go.Scatter(
            x=[vol_data["date"].iloc[-1]], y=[round(fc, 2)],
            mode="markers", name="GARCH forecast",
            marker=dict(size=10, color=COLORS["bearish"], symbol="diamond",
                        line=dict(color="#e8e8e8", width=1))))
    _apply(fig, h=360)
    fig.update_layout(
        title=dict(text=f"{sel} — realized vol & GARCH (annualised %)", font=dict(size=14)),
        yaxis_title="Vol % (annualised)")
    st.plotly_chart(fig, use_container_width=True, config={"displayModeBar":True}, key="vol_chart")


def _fair_value_tab():
    col1, _ = st.columns([1, 3])
    with col1:
        sel    = st.selectbox("Asset", ["Brent","WTI"], key="fv_asset")
        ticker = "BZ=F" if sel=="Brent" else "CL=F"
    with st.spinner(f"Building fair value model for {sel}..."):
        fv = compute_fair_value(ticker)
    if fv["status"] != "ok" or fv["fair_value"] is None:
        st.info("Fair value model loading — requires yFinance connection for DXY, VIX, S&P500, NatGas.")
        return
    current=fv["current"]; fair=fv["fair_value"]
    premium=fv["premium"]; pct=fv["premium_pct"]; band=fv["band"] or 0
    is_over = premium > 0
    bc = COLORS["bearish"] if is_over else COLORS["bullish"]
    label = "OVERVALUED" if is_over else "UNDERVALUED"
    st.markdown(f"""
<div style="background:#1a2035;border:1px solid {bc};border-radius:8px;
     padding:14px 18px;margin-bottom:12px;">
  <div style="display:flex;justify-content:space-between;align-items:center;">
    <div>
      <div style="font-size:11px;color:#a0aec0;">Fair value assessment</div>
      <div style="font-size:22px;font-weight:700;color:{bc};">{label}</div>
      <div style="font-size:12px;color:#666;">{fv['model']}</div>
    </div>
    <div style="text-align:right;">
      <div style="font-size:20px;font-weight:700;color:#e8e8e8;">${current:.2f} vs ${fair:.2f}</div>
      <div style="font-size:14px;color:{bc};font-weight:600;">{premium:+.2f}/bbl ({pct:+.1f}%)</div>
    </div>
  </div>
</div>""", unsafe_allow_html=True)
    contribs = fv.get("contributions", {})
    if contribs:
        names=list(contribs.keys()); values=list(contribs.values())
        fig = go.Figure(go.Bar(
            x=names, y=[round(v,2) for v in values],
            marker_color=[COLORS["bullish"] if v>0 else COLORS["bearish"] for v in values],
            text=[f"${v:+.2f}" for v in values], textposition="outside"))
        _apply(fig, h=260)
        fig.update_layout(title=dict(text="Factor attribution ($/bbl)", font=dict(size=13)),
                          yaxis_title="$/bbl contribution")
        st.plotly_chart(fig, use_container_width=True, config={"displayModeBar":False}, key="fv_bar")
    hist = fv.get("history", pd.DataFrame())
    if not hist.empty:
        fig2 = go.Figure()
        fig2.add_trace(go.Scatter(x=hist["date"], y=hist["actual"].round(2),
            name="Actual", mode="lines", line=dict(color=COLORS["brent"], width=2)))
        fig2.add_trace(go.Scatter(x=hist["date"], y=hist["fair_value"].round(2),
            name="Fair value", mode="lines", line=dict(color=COLORS["wti"], width=2, dash="dash")))
        if band > 0:
            fig2.add_trace(go.Scatter(
                x=hist["date"].tolist()+hist["date"].tolist()[::-1],
                y=(hist["fair_value"]+band).round(2).tolist()+(hist["fair_value"]-band).round(2).tolist()[::-1],
                fill="toself", fillcolor=_rgba(COLORS["wti"], 0.08),
                line=dict(color="rgba(0,0,0,0)"), name=f"±${band:.2f}"))
        _apply(fig2, h=320)
        fig2.update_layout(title=dict(text=f"{sel} — actual vs model fair value", font=dict(size=14)),
                           yaxis_title="Price ($/bbl)")
        st.plotly_chart(fig2, use_container_width=True, config={"displayModeBar":True}, key="fv_hist")
    c1,c2,c3 = st.columns(3)
    c1.metric("Fair value", f"${fair:.2f}")
    c2.metric("Premium/disc.", f"${premium:+.2f}")
    c3.metric("Model band", f"±${band:.2f}")


def _corr_tab():
    c1, _ = st.columns([1, 3])
    with c1:
        window = st.radio("Window", [30,60,90,252],
                          format_func=lambda x: f"{x}d", key="tab4_corr_window")
    pm = {30:"3mo", 60:"6mo", 90:"6mo", 252:"1y"}
    with st.spinner("Loading..."):
        df_c = fetch_correlation_data(period=pm.get(window,"1y"))
    if df_c.empty:
        st.info("Correlation data loading — check yFinance connection."); return
    corr = compute_correlation_matrix(df_c, window=window)
    if corr.empty:
        st.caption("Insufficient data."); return
    fig = go.Figure(go.Heatmap(
        z=corr.values, x=corr.columns.tolist(), y=corr.index.tolist(),
        colorscale=[[0,"#E24B4A"],[0.5,"#2d3748"],[1,"#1D9E75"]],
        zmin=-1, zmax=1, text=corr.round(2).values,
        texttemplate="%{text}", textfont={"size":11},
        hovertemplate="%{y} vs %{x}: %{z:.3f}<extra></extra>"))
    _apply(fig, h=360, m=dict(l=80, r=10, t=25, b=80))
    st.plotly_chart(fig, use_container_width=True, config={"displayModeBar":False}, key="corr_heatmap")
    cl = corr.columns.tolist()
    pairs = [(cl[i],cl[j],float(corr.iloc[i,j]))
             for i in range(len(cl)) for j in range(i+1,len(cl))]
    pairs.sort(key=lambda x: abs(x[2]), reverse=True)
    rows = [{"Asset A":a,"Asset B":b,"Correlation":f"{r:+.3f}",
             "Signal":"Strong pos" if r>0.7 else "Mod pos" if r>0.4 else
                      "Strong neg" if r<-0.7 else "Mod neg" if r<-0.4 else "Weak"}
            for a,b,r in pairs[:8]]
    st.dataframe(pd.DataFrame(rows), use_container_width=True, hide_index=True)


def _options_tab():
    st.markdown("**OVX (CBOE Oil VIX) — crude oil implied volatility**")
    try:
        ovx = _strip_tz(yf.Ticker("^OVX").history(period="2y")["Close"])
        vix = _strip_tz(yf.Ticker("^VIX").history(period="2y")["Close"])
        if not ovx.empty:
            fig = go.Figure()
            fig.add_trace(go.Scatter(x=ovx.index, y=ovx.round(2).values,
                name="OVX (oil)", mode="lines", line=dict(color=COLORS["bearish"], width=2),
                fill="tozeroy", fillcolor=_rgba(COLORS["bearish"], 0.1)))
            if not vix.empty:
                fig.add_trace(go.Scatter(x=vix.index, y=vix.round(2).values,
                    name="VIX (equity)", mode="lines",
                    line=dict(color=COLORS["neutral"], width=1.5, dash="dot")))
            _apply(fig, h=300)
            fig.update_layout(title=dict(text="OVX vs VIX", font=dict(size=14)),
                              yaxis_title="Implied vol index")
            st.plotly_chart(fig, use_container_width=True,
                            config={"displayModeBar":True}, key="ovx_chart")
            c1,c2,c3,c4 = st.columns(4)
            c1.metric("OVX current",  f"{float(ovx.iloc[-1]):.1f}")
            c2.metric("OVX 52w high", f"{float(ovx.max()):.1f}")
            c3.metric("OVX 52w low",  f"{float(ovx.min()):.1f}")
            if not vix.empty:
                ratio = float(ovx.iloc[-1]) / max(float(vix.iloc[-1]), 1)
                c4.metric("OVX/VIX ratio", f"{ratio:.2f}")
    except Exception as e:
        st.info(f"OVX loading — {str(e)[:60]}")

    st.divider()
    st.markdown("**Options vol smile — energy ETF proxy**")
    st.caption("USO/XLE/UNG available via yFinance free tier.")
    col1, _ = st.columns([1, 3])
    with col1:
        proxy = st.selectbox("Proxy",
            ["USO (US Oil Fund)","XLE (Energy ETF)","UNG (Nat Gas)"], key="opt_proxy")
    pt = {"USO (US Oil Fund)":"USO","XLE (Energy ETF)":"XLE","UNG (Nat Gas)":"UNG"}[proxy]
    try:
        t = yf.Ticker(pt); expirations = t.options
        if not expirations:
            st.info(f"No options chain for {pt}."); return
        exp = st.selectbox("Expiry", expirations[:6], key="opt_expiry")
        chain = t.option_chain(exp)
        calls = chain.calls[["strike","impliedVolatility","openInterest","volume"]].dropna()
        puts  = chain.puts [["strike","impliedVolatility","openInterest","volume"]].dropna()
        if calls.empty and puts.empty:
            st.info(f"No options data for {pt} at {exp}."); return
        try: spot = float(t.fast_info.last_price)
        except Exception: spot = float(calls["strike"].median())
        calls = calls[(calls["strike"]>=spot*0.7)&(calls["strike"]<=spot*1.3)]
        puts  = puts [(puts["strike"] >=spot*0.7)&(puts["strike"] <=spot*1.3)]
        fig = go.Figure()
        if not calls.empty:
            fig.add_trace(go.Scatter(x=calls["strike"],
                y=(calls["impliedVolatility"]*100).round(1),
                name="Call IV", mode="lines+markers",
                line=dict(color=COLORS["bullish"], width=2), marker=dict(size=5)))
        if not puts.empty:
            fig.add_trace(go.Scatter(x=puts["strike"],
                y=(puts["impliedVolatility"]*100).round(1),
                name="Put IV", mode="lines+markers",
                line=dict(color=COLORS["bearish"], width=2), marker=dict(size=5)))
        fig.add_vline(x=spot, line=dict(color="#e8e8e8", width=1.5, dash="dot"),
                      annotation_text=f"Spot ${spot:.2f}", annotation_font_color="#e8e8e8")
        _apply(fig, h=300)
        fig.update_layout(title=dict(text=f"{pt} vol smile — {exp}", font=dict(size=14)),
                          xaxis_title="Strike", yaxis_title="Implied vol (%)")
        st.plotly_chart(fig, use_container_width=True,
                        config={"displayModeBar":True}, key="opt_smile")
        pcr = int(puts["volume"].sum()) / max(int(calls["volume"].sum()), 1)
        c1,c2,c3,c4 = st.columns(4)
        c1.metric("Put/call ratio", f"{pcr:.2f}",
                  delta="Bearish" if pcr>1.2 else "Bullish" if pcr<0.8 else "Neutral")
        c2.metric("Call vol", f"{int(calls['volume'].sum()):,}")
        c3.metric("Put vol",  f"{int(puts['volume'].sum()):,}")
        c4.metric("Expiry", exp)
    except Exception as e:
        st.info(f"Options chain loading — {str(e)[:80]}")
